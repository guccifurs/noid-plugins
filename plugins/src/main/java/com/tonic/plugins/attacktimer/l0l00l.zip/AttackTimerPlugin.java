package com.tonic.plugins.attacktimer;

import com.google.inject.Inject;
import com.google.inject.Provides;
import com.tonic.Logger;
import com.tonic.Static;
import com.tonic.api.game.SkillAPI;
import com.tonic.api.game.VarAPI;
import com.tonic.api.game.GameAPI;
import com.tonic.api.entities.PlayerAPI;
import com.tonic.queries.PlayerQuery;
import com.tonic.queries.TileObjectQuery;
import com.tonic.api.entities.TileObjectAPI;
import com.tonic.data.wrappers.TileObjectEx;
import com.tonic.api.widgets.EquipmentAPI;
import com.tonic.api.widgets.InventoryAPI;
import com.tonic.api.widgets.MagicAPI;
import com.tonic.api.widgets.WidgetAPI;
import com.tonic.api.game.MovementAPI;
import com.tonic.api.widgets.PrayerAPI;
import com.tonic.api.widgets.DialogueAPI;
import com.tonic.api.widgets.TradeAPI;
import com.tonic.data.wrappers.ItemEx;
import com.tonic.data.magic.spellbooks.Ancient;
import com.tonic.services.GameManager;
import com.tonic.util.ReflectUtil;
import com.tonic.data.wrappers.PlayerEx;
import com.tonic.api.TClient;
import com.tonic.services.ClickManager;
// import com.tonic.services.ClickPacket.PacketInteractionType; // Not available in current API
import com.tonic.ui.VitaOverlay;
import net.runelite.api.Actor;
import net.runelite.api.Client;
import net.runelite.api.HitsplatID;
import net.runelite.api.Player;
import net.runelite.api.Skill;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.events.AnimationChanged;
import net.runelite.api.events.ChatMessage;
import net.runelite.api.events.GameTick;
import net.runelite.api.events.HitsplatApplied;
import net.runelite.api.events.MenuEntryAdded;
import net.runelite.api.ChatMessageType;
import net.runelite.api.MenuEntry;
import net.runelite.api.MenuAction;
import net.runelite.api.gameval.InterfaceID;
import net.runelite.api.widgets.Widget;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.ClientToolbar;
import net.runelite.client.ui.NavigationButton;
import net.runelite.client.ui.overlay.OverlayManager;
import net.runelite.client.util.ImageUtil;
import com.tonic.plugins.attacktimer.ui.AttackTimerConfigPanel;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Random;

@PluginDescriptor(
        name = "Attack Timer",
        description = "Tracks attack timers for various weapons (AGS, Claws, Tentacle, Magic, Range)",
        tags = {"combat", "timer", "pvp", "attack", "nh"}
)
public class AttackTimerPlugin extends Plugin
{
    @Inject
    private AttackTimerConfig config;

    @Inject
    private Client client;

    @Inject
    private OverlayManager overlayManager;

    @Inject
    private ClientToolbar clientToolbar;

    private VitaOverlay infoOverlay;
    
    private AttackTimerConfigPanel configPanel;
    private NavigationButton navigationButton;
    private static final BufferedImage pluginIcon = ImageUtil.loadImageResource(AttackTimerPlugin.class, "icon.png");
    
    // Duel challenge handler
    private DuelChallengeHandler duelChallengeHandler;
    
    // PID detector
    private PidDetector pidDetector;
    
    // Target spec tracker
    private TargetSpec targetSpec;

    // Animation IDs for different weapons
    // Armadyl Godsword - 6 ticks
    private static final int[] AGS_ANIMATIONS = {
        7644,  // Armadyl Godsword normal attack
        7045   // AGS wack
    };
    
    private static final int DRAGON_CLAWS_ATTACK = 7514;  // Dragon Claws
    private static final int DRAGON_CLAWS_SPEC = 7515;
    private static final int TENTACLE_ATTACK = 1658;  // Abyssal Tentacle (same as whip)
    private static final int TENTACLE_ATTACK_2 = 1659;
    
    // Ignored animations (movement, eating, etc. - not attack animations)
    private static final int[] IGNORED_ANIMATIONS = {
        1156  // Unknown animation (possibly movement or other non-attack animation)
    };
    
    // Magic animation IDs (common casting animations)
    // Ice Barrage, Ice Blitz and other ancient/standard magic spells - 5 ticks
    private static final int[] MAGIC_ANIMATIONS = {
        7855,  // Common magic casting / Ice Barrage
        7854,  // Ice Barrage variant
        7856,  // Magic casting variant
        1978,  // Ice Blitz
        1979,  // Ice Burst
        711,   // Ancient magic casting
        1167,  // Magic casting variant
        1162,  // Magic casting variant
        428,   // Magic casting variant
        763,   // Standard magic casting
        7853   // Magic casting variant
        // Note: 440 removed - it's staff bash/melee (4 ticks)
    };
    
    // Staff bash / melee attacks - 4 ticks
    private static final int[] STAFF_BASH_ANIMATIONS = {
        440    // Staff bash/melee
    };
    
    // Range animation IDs - Crossbow attacks
    private static final int[] CROSSBOW_ANIMATIONS = {
        9168,  // Crossbow attack
        9169,  // Crossbow attack variant
        9170,  // Crossbow attack variant
        7617,  // Crossbow attack (2h)
        7618,  // Crossbow attack (2h variant)
        9171,  // Crossbow attack variant
        9172,  // Crossbow attack variant
        4230,  // Crossbow rapid attack
        7615,  // Crossbow long range
        7616   // Crossbow accurate
    };
    
    // Bow animation IDs
    private static final int[] BOW_ANIMATIONS = {
        426,   // Regular bow
        7618,  // Bow variant
        7619   // Bow variant
    };

    // Freeze GFX IDs - common freeze spell graphics
    private static final int[] FREEZE_GFX_IDS = {
        369,   // Ice Barrage (most common)
        360,   // Ice Blitz
        361,   // Ice Burst
        363,   // Ice Rush
        358,   // Other freeze spells
        359,   // Other freeze spells
        143,   // Entangle (nature spell freeze)
        144    // Other entangle variants
    };

    // Timer tracking
    private AttackTimer playerTimer = null;
    private AttackTimer opponentTimer = null;
    private boolean playerTimerNewThisTick = false;
    private boolean opponentTimerNewThisTick = false;

    // Freeze timer tracking
    private FreezeTimer playerFreezeTimer = null;
    private FreezeTimer opponentFreezeTimer = null;
    
    // Track last known positions for movement detection
    private WorldPoint playerLastPosition = null;
    private WorldPoint opponentLastPosition = null;
    private boolean playerFreezeNewThisTick = false;
    private boolean opponentFreezeNewThisTick = false;
    
    // Freeze safety check: Track ticks while frozen to test if we're actually frozen
    private int frozenSafetyCheckTicks = 0; // Increment every tick while frozen, reset when not frozen

    // Combat logger for tracking opponent attacks by freeze state
    private CombatLogger combatLogger = null;

    // Random generator for weighted prayer selection
    private final Random random = new Random();
    
    // AI Prayers display data
    private AIPrayersDisplayData aiPrayersData = null;
    
    // Simplified target system - single target used for both combat automation and AI prayers
    private Player cachedTarget = null;
    private String cachedTargetRSN = null;
    
    // AI Chatbot fields
    private long lastAIChatResponseTime = 0;
    private String queuedAIChatResponse = null;
    private long queuedAIChatResponseTime = 0; // When the message was queued
    private long queuedAIChatResponseDelay = 0; // Random delay (2-5 seconds) in milliseconds
    private AIChatService aiChatService;
    private String lastUsedApiKey = null;
    
    // Discord webhook service (combat messages)
    private DiscordWebhookService discordWebhookService = null;
    private String lastUsedWebhookUrl = null;
    
    // Discord webhook service (lobby messages)
    private DiscordWebhookService lobby578WebhookService = null;
    private String lastUsedLobby578WebhookUrl = null;
    
    // Post-init AI message fields
    private long initSequenceCompletionTime = -1; // Timestamp when init sequence completed (-1 = not completed)
    private String queuedPostInitMessage = null; // AI-generated message to send 10 seconds after init
    private boolean shouldTrackDiscordMessages = false; // Track messages for Discord webhook (starts after "1" message)
    
    // Flame message timer (when varbit == 1 and no target message received)
    private long lastTargetMessageTime = -1; // Timestamp when we last received a message from target (-1 = never)
    private long lastFlameMessageTime = -1; // Timestamp when we last sent a flame message (-1 = never)
    
    private boolean aiSendingMessage = false; // Flag to prevent AI from responding to its own messages
    private CombatLogData cachedCombatData = null;
    private int previousVarbit8121 = -1;
    private int previousRegionId = -1;
    private int tickCounter = 0;
    
    // Arena exit flags (reset when entering arena - region 13363 or 13362)
    private boolean shouldClickPortal = false; // Set when we see "Oh dear, you are dead!"
    private boolean shouldClickGateway = false; // Set when we see "Unranked duel wins"
    private int gatewayClickAttempts = 0; // Track how many times we've tried to click Gateway
    private static final int MAX_GATEWAY_CLICK_ATTEMPTS = 50; // Maximum attempts before giving up
    
    // Initialization sequence state (when varbit == 1 and we see "10" message)
    private boolean initSequenceActive = false; // True when sequence is running
    private int initSequenceStep = 0; // Current step: 0=wait for "10", 1=eat angler, 2=drink bastion, 3=walk, 4=wait 4 ticks, 5=super combat, 6=wait 1 tick, 7=walk again, 8=wait for "1"
    private int initSequenceTicks = 0; // Tick counter for current step
    
    // Combat automation state tracking
    private boolean waitingForCastAnimation = false;
    private int waitingForCastAnimationTicks = 0; // Track how many ticks we've been waiting for animation
    private boolean waitingForCastXP = false;
    private int waitingForCastXPTicks = 0; // Track how many ticks we've been waiting for XP
    private int lastMagicXP = -1;
    private int lastEquipTick = -1;
    
    // Gear test state tracking
    private boolean gearTestExecuted = false;
    private boolean previousGearTestState = false;
    
    // Tank toggle state tracking
    private boolean previousTankState = false;
    
    // Range attack state tracking
    private boolean waitingForCrossbowAnimation = false;
    private int waitingForCrossbowTicks = 0; // Track how many ticks we've been waiting
    private boolean previousRangeAttackState = false;
    
    // Anglerfish tracking for timer extension
    private int ticksAtZero = 0; // Track how many ticks timer has been at 0
    private boolean anglerEatenThisTick = false; // Flag if angler was eaten this tick (set by eatAngler() method)
    
    // Spec dump mode tracking (game start detection and 75-tick timer)
    private int ticksSinceGameStart = -1; // -1 means not started, >= 0 means counting from "1" message
    private boolean specDumpModeActive = false; // Whether we're in spec dump mode (takes priority over all handlers when unfrozen)
    
    // Damage tracking
    private int totalDamageDealt = 0; // Total damage dealt to opponents in current fight
    
    // Combat state handlers
    private final CombatStateHandler targetFrozenWeUnfrozenOnPidHandler = new TargetFrozenWeUnfrozenOnPidHandler();
    private final CombatStateHandler targetFrozenWeUnfrozenOffPidHandler = new TargetFrozenWeUnfrozenOffPidHandler();
    private final CombatStateHandler weFrozenTargetUnfrozenOnPidHandler = new WeFrozenTargetUnfrozenOnPidHandler();
    private final CombatStateHandler weFrozenTargetUnfrozenOffPidHandler = new WeFrozenTargetUnfrozenOffPidHandler();
    private final CombatStateHandler bothFrozenHandler = new BothFrozenHandler();
    private final BothUnfrozenHandler bothUnfrozenHandler = new BothUnfrozenHandler();
    
    private class AIPrayersDisplayData
    {
        boolean targetFrozen;
        boolean weFrozen;
        boolean canMelee;
        String modus; // "predicting" or "guessing"
        double rangedPercent;
        double meleePercent;
        double magicPercent;
    }

    private class AttackTimer
    {
        String weaponName;
        int ticksRemaining;
        int totalTicks;

        AttackTimer(String weaponName, int totalTicks)
        {
            this.weaponName = weaponName;
            this.totalTicks = totalTicks;
            // Start at totalTicks (e.g., 4 for tentacle) and count down: 4, 3, 2, 1, 0
            // The first-tick protection ensures it shows the full value before decrementing
            this.ticksRemaining = totalTicks;
        }

        void tick()
        {
            if (ticksRemaining > 0)
            {
                ticksRemaining--;
            }
        }
        
        void addTicks(int ticks)
        {
            ticksRemaining += ticks;
        }

        boolean isExpired()
        {
            return ticksRemaining <= 0;
        }
    }

    private enum FreezeState
    {
        FROZEN,      // Currently frozen (36 ticks)
        IMMUNITY,    // Freeze immunity period (4 ticks)
        NONE         // Not frozen, no immunity
    }

    private class FreezeTimer
    {
        FreezeState state;
        int ticksRemaining;

        FreezeTimer()
        {
            this.state = FreezeState.FROZEN;
            this.ticksRemaining = 33;  // 33 tick freeze duration
        }

        void tick()
        {
            if (ticksRemaining > 0)
            {
                ticksRemaining--;
                
                // Transition from FROZEN to IMMUNITY after 33 ticks
                if (state == FreezeState.FROZEN && ticksRemaining == 0)
                {
                    state = FreezeState.IMMUNITY;
                    ticksRemaining = 4;  // 4 tick immunity period
                }
                // Transition from IMMUNITY to NONE after 4 ticks
                else if (state == FreezeState.IMMUNITY && ticksRemaining == 0)
                {
                    state = FreezeState.NONE;
                }
            }
        }

        boolean canBeFrozen()
        {
            // Can only be frozen if we're not already frozen or in immunity
            return state == FreezeState.NONE;
        }

        boolean isActive()
        {
            return state != FreezeState.NONE;
        }

        void reset()
        {
            // Reset freeze timer (e.g., if actor moves)
            state = FreezeState.NONE;
            ticksRemaining = 0;
        }
    }

    @Provides
    AttackTimerConfig provideConfig(ConfigManager configManager)
    {
        return configManager.getConfig(AttackTimerConfig.class);
    }

    @Override
    protected void startUp() throws Exception
    {
        // Overlay removed - only using panel now
        // if (infoOverlay == null)
        // {
        //     infoOverlay = new VitaOverlay();
        //     infoOverlay.setPosition(net.runelite.client.ui.overlay.OverlayPosition.TOP_RIGHT);
        // }
        // overlayManager.add(infoOverlay);
        updatePanel();
        Logger.norm("[AttackTimer] AttackTimer v2.2 - startup complete");

        // Initialize combat logger
        combatLogger = new CombatLogger(config);
        
        // Initialize and register duel challenge handler
        // Defensively unregister first in case of hot reload (old instance might still be registered)
        if (duelChallengeHandler != null)
        {
            safeUnregister(duelChallengeHandler);
            Logger.norm("[AttackTimer] Unregistered old DuelChallengeHandler instance during startup (hot reload cleanup)");
        }
        duelChallengeHandler = new DuelChallengeHandler(config);
        Static.getRuneLite().getEventBus().register(duelChallengeHandler);
        Logger.norm("[AttackTimer] DuelChallengeHandler registered (NEW FLAG-BASED VERSION)");
        
        // Initialize PID detector
        pidDetector = new PidDetector(config, client);
        Static.getRuneLite().getEventBus().register(pidDetector);
        
        // Initialize target spec tracker
        targetSpec = new TargetSpec(config, client);
        Static.getRuneLite().getEventBus().register(targetSpec);
        
        // Initialize AI chat service
        aiChatService = new AIChatService(config.aiChatbotApiKey(), config.aiChatbotModel(), config.aiChatbotProvider(), config.aiChatbotApiType(), config.aiChatbotSystemPrompt());
        
        // Initialize Discord webhook service (combat)
        if (config.discordWebhooks() && config.discordWebhookUrl() != null && !config.discordWebhookUrl().trim().isEmpty())
        {
            discordWebhookService = new DiscordWebhookService(config.discordWebhookUrl());
            lastUsedWebhookUrl = config.discordWebhookUrl();
        }
        
        // Initialize Discord webhook service (lobby)
        if (config.lobby578Webhooks() && config.lobby578WebhookUrl() != null && !config.lobby578WebhookUrl().trim().isEmpty())
        {
            lobby578WebhookService = new DiscordWebhookService(config.lobby578WebhookUrl());
            lastUsedLobby578WebhookUrl = config.lobby578WebhookUrl();
        }
        
        // Initialize config panel
        configPanel = injector.getInstance(AttackTimerConfigPanel.class);
        configPanel.setPlugin(this); // Pass plugin reference to panel
        navigationButton = NavigationButton.builder()
                .tooltip("Attack Timer")
                .icon(pluginIcon)
                .panel(configPanel)
                .build();
        clientToolbar.addNavigation(navigationButton);
        Logger.norm("[AttackTimer] Plugin initialized");
    }

    @Override
    protected void shutDown() throws Exception
    {
        // Overlay removed - no cleanup needed
        // overlayManager.remove(infoOverlay);
        
        // Unregister duel challenge handler (with try-catch to prevent errors if already unregistered)
        if (duelChallengeHandler != null)
        {
            safeUnregister(duelChallengeHandler);
            duelChallengeHandler = null;
        }
        
        // Unregister PID detector (with try-catch to prevent errors if already unregistered)
        if (pidDetector != null)
        {
            safeUnregister(pidDetector);
            pidDetector = null;
        }
        
        // Unregister target spec tracker (with try-catch to prevent errors if already unregistered)
        if (targetSpec != null)
        {
            safeUnregister(targetSpec);
            targetSpec = null;
        }
        
        // Remove navigation button
        if (navigationButton != null)
        {
            clientToolbar.removeNavigation(navigationButton);
            navigationButton = null;
        }
        
        playerTimer = null;
        opponentTimer = null;
        playerFreezeTimer = null;
        opponentFreezeTimer = null;
    }

    /**
     * Handles chat messages to detect arena exit conditions and initialization sequence
     */
    @Subscribe
    public void onChatMessage(ChatMessage event)
    {
        if (!config.enabled())
        {
            return;
        }

        String message = event.getMessage();
        if (message == null)
        {
            return;
        }
        
        // AI Chatbot: Respond to target messages during combat
        if (config.aiChatbot() && aiChatService != null)
        {
            handleAIChatbotMessage(event);
        }
        
        // Check if varbit == 1 for initialization sequence and Discord webhooks
        int currentVarbit = VarAPI.getVar(8121);
        
        // Discord Webhooks: Send messages from local player and target during combat
        // Only track after "1" message and stop when varbit != 1
        if (config.discordWebhooks() && shouldTrackDiscordMessages && currentVarbit == 1)
        {
            // Update Discord webhook service if URL changed
            String currentWebhookUrl = config.discordWebhookUrl();
            if (currentWebhookUrl != null && !currentWebhookUrl.trim().isEmpty() && 
                (discordWebhookService == null || !currentWebhookUrl.equals(lastUsedWebhookUrl)))
            {
                discordWebhookService = new DiscordWebhookService(currentWebhookUrl);
                lastUsedWebhookUrl = currentWebhookUrl;
            }
            
            if (discordWebhookService != null)
            {
                Player localPlayer = Static.invoke(client::getLocalPlayer);
                String senderName = event.getName();
                
                // Check if message is from local player
                boolean isLocalPlayerMessage = false;
                if (localPlayer != null)
                {
                    String localPlayerName = Static.invoke(localPlayer::getName);
                    if (localPlayerName != null && localPlayerName.equals(senderName))
                    {
                        isLocalPlayerMessage = true;
                    }
                }
                
                // Check if message is from target
                boolean isTargetMessage = false;
                if (cachedTargetRSN != null && cachedTargetRSN.equals(senderName))
                {
                    isTargetMessage = true;
                }
                else if (localPlayer != null)
                {
                    Actor interacting = Static.invoke(localPlayer::getInteracting);
                    if (interacting instanceof Player)
                    {
                        String targetName = Static.invoke(interacting::getName);
                        if (targetName != null && targetName.equals(senderName))
                        {
                            isTargetMessage = true;
                        }
                    }
                }
                
                // Send webhook if message is from local player or target
                if (isLocalPlayerMessage || isTargetMessage)
                {
                    final boolean isLocal = isLocalPlayerMessage;
                    final String finalSenderName = senderName != null ? senderName : "Unknown";
                    final String finalMessage = message;
                    
                    // Send asynchronously to avoid blocking
                    new Thread(() -> {
                        discordWebhookService.sendChatMessage(finalSenderName, finalMessage, isLocal);
                    }).start();
                }
            }
        }
        
        // 578Lobby Webhooks: Send ALL messages when outside combat (varbit != 1)
        if (config.lobby578Webhooks() && currentVarbit != 1)
        {
            // Update lobby webhook service if URL changed
            String currentLobbyWebhookUrl = config.lobby578WebhookUrl();
            if (currentLobbyWebhookUrl != null && !currentLobbyWebhookUrl.trim().isEmpty() && 
                (lobby578WebhookService == null || !currentLobbyWebhookUrl.equals(lastUsedLobby578WebhookUrl)))
            {
                lobby578WebhookService = new DiscordWebhookService(currentLobbyWebhookUrl);
                lastUsedLobby578WebhookUrl = currentLobbyWebhookUrl;
            }
            
            if (lobby578WebhookService != null)
            {
                // Only send public chat messages
                if (event.getType() == ChatMessageType.PUBLICCHAT || event.getType() == ChatMessageType.MODCHAT)
                {
                    Player localPlayer = Static.invoke(client::getLocalPlayer);
                    String senderName = event.getName();
                    
                    if (senderName != null)
                    {
                        // Check if message is from local player (bot)
                        boolean isLocalPlayerMessage = false;
                        if (localPlayer != null)
                        {
                            String localPlayerName = Static.invoke(localPlayer::getName);
                            if (localPlayerName != null && localPlayerName.equals(senderName))
                            {
                                isLocalPlayerMessage = true;
                            }
                        }
                        
                        // Send webhook for ALL messages
                        final boolean isLocal = isLocalPlayerMessage;
                        final String finalSenderName = senderName;
                        final String finalMessage = message;
                        
                        // Send asynchronously to avoid blocking
                        new Thread(() -> {
                            lobby578WebhookService.sendChatMessage(finalSenderName, finalMessage, isLocal);
                        }).start();
                    }
                }
            }
        }
        
        String lowerMessage = message.toLowerCase();
        
        // Check for initialization sequence: "10" message when varbit == 1
        if (currentVarbit == 1 && !initSequenceActive)
        {
            // Check if message contains "10" (could be "10" or part of "countdown: 10" etc.)
            if (message.trim().equals("10") || message.matches(".*\\b10\\b.*"))
            {
                // Check if it's from local player (name matches or it's a game message)
                Player localPlayer = Static.invoke(client::getLocalPlayer);
                boolean isLocalPlayerMessage = false;
                
                if (localPlayer != null)
                {
                    String localPlayerName = Static.invoke(localPlayer::getName);
                    if (localPlayerName != null && localPlayerName.equals(event.getName()))
                    {
                        isLocalPlayerMessage = true;
                    }
                }
                
                // Also check if it's a GAME message type (system message) that might be a countdown
                if (!isLocalPlayerMessage && event.getType() == net.runelite.api.ChatMessageType.GAMEMESSAGE)
                {
                    // Could be a countdown message, check if it contains just "10"
                    if (message.trim().equals("10") || message.matches(".*\\b10\\b.*"))
                    {
                        isLocalPlayerMessage = true; // Treat as valid
                    }
                }
                
                if (isLocalPlayerMessage)
                {
                    initSequenceActive = true;
                    initSequenceStep = 1; // Start at step 1 (tank gear + angler)
                    initSequenceTicks = 0;
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Detected '10' message - starting initialization sequence");
                    }
                }
            }
        }
        
        // Check for initialization sequence: "3" or "2" message when sequence is active (before "1" check)
        // These trigger movement of 6 tiles
        if (initSequenceActive)
        {
            Player localPlayer = Static.invoke(client::getLocalPlayer);
            boolean isLocalPlayerMessage = false;
            
            if (localPlayer != null)
            {
                String localPlayerName = Static.invoke(localPlayer::getName);
                if (localPlayerName != null && localPlayerName.equals(event.getName()))
                {
                    isLocalPlayerMessage = true;
                }
            }
            
            if (!isLocalPlayerMessage && event.getType() == net.runelite.api.ChatMessageType.GAMEMESSAGE)
            {
                // Could be a game/system message
                isLocalPlayerMessage = true;
            }
            
            if (isLocalPlayerMessage)
            {
                // Check for "3" message - move 6 tiles
                if (message.trim().equals("3") || message.matches(".*\\b3\\b.*"))
                {
                    WorldPoint playerPos = localPlayer.getWorldLocation();
                    // Generate random offsets (up to 6 tiles in any direction)
                    int offsetX = random.nextInt(13) - 6; // -6 to +6
                    int offsetY = random.nextInt(13) - 6; // -6 to +6
                    WorldPoint randomTile = new WorldPoint(
                        playerPos.getX() + offsetX,
                        playerPos.getY() + offsetY,
                        playerPos.getPlane()
                    );
                    MovementAPI.walkToWorldPoint(randomTile);
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Detected '3' message - moving 6 tiles to (" + randomTile.getX() + ", " + randomTile.getY() + ")");
                    }
                }
                // Check for "2" message - move 6 tiles
                else if (message.trim().equals("2") || message.matches(".*\\b2\\b.*"))
                {
                    WorldPoint playerPos = localPlayer.getWorldLocation();
                    // Generate random offsets (up to 6 tiles in any direction)
                    int offsetX = random.nextInt(13) - 6; // -6 to +6
                    int offsetY = random.nextInt(13) - 6; // -6 to +6
                    WorldPoint randomTile = new WorldPoint(
                        playerPos.getX() + offsetX,
                        playerPos.getY() + offsetY,
                        playerPos.getPlane()
                    );
                    MovementAPI.walkToWorldPoint(randomTile);
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Detected '2' message - moving 6 tiles to (" + randomTile.getX() + ", " + randomTile.getY() + ")");
                    }
                }
                // Check for initialization sequence end: "1" message when sequence is active
                else if (initSequenceStep == 8 && (message.trim().equals("1") || message.matches(".*\\b1\\b.*")))
                {
                    initSequenceActive = false;
                    initSequenceStep = 0;
                    initSequenceTicks = 0;
                    // Start/reset spec dump timer from "1" message (resets timer even if already running from previous game)
                    ticksSinceGameStart = 0;
                    specDumpModeActive = false; // Reset spec dump mode (will activate at 75 ticks if spec is 100%)
                    
                    // Start tracking Discord messages after "1" message
                    shouldTrackDiscordMessages = true;
                    
                    // Queue AI message to send 10 seconds after init completion
                    if (config.aiChatbot() && aiChatService != null)
                    {
                        initSequenceCompletionTime = System.currentTimeMillis();
                        queuedPostInitMessage = null; // Clear any previous message
                        
                        // Generate AI message asynchronously
                        new Thread(() -> {
                            try
                            {
                                AIChatService service = getAIChatService();
                                if (service != null)
                                {
                                    // Generate a flame message about PK'ing in OSRS (up to 6 words)
                                    String prompt = "Send a short flame insult about PK'ing in Old School RuneScape. Examples: 'shit pker', 'ur so bad', 'you suck kid', 'get rekt noob'. Keep it up to 6 words maximum, under 50 characters, and be trash talk.";
                                    String aiMessage = service.getResponse(prompt);
                                    if (aiMessage != null && !aiMessage.trim().isEmpty())
                                    {
                                        queuedPostInitMessage = aiMessage;
                                        if (config.debug())
                                        {
                                            Logger.norm("[AI Chatbot] Generated post-init message: " + aiMessage);
                                        }
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Logger.norm("[AI Chatbot] Error generating post-init message: " + e.getMessage());
                            }
                        }).start();
                    }
                    
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Detected '1' message - ending initialization sequence, resuming normal combat, starting/resetting spec dump timer");
                    }
                }
            }
        }

        // Check for "Oh dear, you are dead!" - we died, need to click Portal
        if (lowerMessage.contains("oh dear") && lowerMessage.contains("you are dead"))
        {
            shouldClickPortal = true;
            shouldClickGateway = false; // Clear gateway flag if set
            Logger.norm("[Arena Exit] Detected 'Oh dear, you are dead!' - will click Portal until varbit != 1");
        }
        // Check for "Unranked duel wins" - we won, need to click Gateway
        else if (lowerMessage.contains("unranked duel wins"))
        {
            shouldClickGateway = true;
            shouldClickPortal = false; // Clear portal flag if set
            gatewayClickAttempts = 0; // Reset attempt counter
            
            // Clear target when we win
            cachedTarget = null;
            cachedTargetRSN = null;
            cachedCombatData = null;
            
            Logger.norm("[Arena Exit] Detected 'Unranked duel wins' - cleared target, will click Gateway until varbit != 1");
        }
        // Check for "You can leave" - we won, need to click Gateway
        else if (lowerMessage.contains("you can leave"))
        {
            shouldClickGateway = true;
            shouldClickPortal = false; // Clear portal flag if set
            gatewayClickAttempts = 0; // Reset attempt counter
            
            // Clear target when we win
            cachedTarget = null;
            cachedTargetRSN = null;
            cachedCombatData = null;
            
            Logger.norm("[Arena Exit] Detected 'You can leave' - cleared target, will click Gateway until varbit != 1");
        }
    }
    
    /**
     * Gets or creates the AI chat service with current API key
     */
    private AIChatService getAIChatService()
    {
        String currentApiKey = config.aiChatbotApiKey();
        String currentModel = config.aiChatbotModel();
        String currentProvider = config.aiChatbotProvider();
        String currentApiType = config.aiChatbotApiType();
        String currentSystemPrompt = config.aiChatbotSystemPrompt();
        // Recreate service if API key, model, provider, API type, or system prompt changed, or service doesn't exist
        if (aiChatService == null || 
            (currentApiKey != null && !currentApiKey.equals(lastUsedApiKey)) ||
            (currentModel != null && !currentModel.equals(aiChatService.getModelId())) ||
            (currentProvider != null && !currentProvider.equals(aiChatService.getProvider())) ||
            (currentSystemPrompt != null && !currentSystemPrompt.equals(aiChatService.getSystemPrompt())))
        {
            aiChatService = new AIChatService(currentApiKey, currentModel, currentProvider, currentApiType, currentSystemPrompt);
            lastUsedApiKey = currentApiKey;
        }
        return aiChatService;
    }
    
    /**
     * Gets a random prompt for lobby messages (when varbit != 1)
     */
    private String getRandomLobbyPrompt()
    {
        String[] prompts = {
            "I m the fastest nher I click faster than 1013, I own people on osrs, 1 ticks is all you. you are insanely fast. Every message u send is between 1 and 8 words max.",
            "You are a humble gamer and you are looking for NH fights. ask around if anyone want to nh with you. You are ready for some hands. asak them to Pk or challenge for a 1v1 Every message u send is between 1 and 8 words max.",
            "u are a rage baiter. u try to get the worst out of people Every message u send is between 1 and 8 words max.",
            "Everyone is a noob but u dont care u are glad to help them. Every message u send is between 1 and 8 words max.",
            "u are annoyed with the bots and ai, everything around u is a bot its frustrating. Every message u send is between 1 and 8 words max."
        };
        int randomIndex = (int)(Math.random() * prompts.length);
        return prompts[randomIndex];
    }
    
    /**
     * Handles AI chatbot message processing - detects messages and queues responses
     * When varbit == 1: Only responds to target (5 second cooldown)
     * When varbit != 1: Responds to everyone (30 second cooldown after any message)
     */
    private void handleAIChatbotMessage(ChatMessage event)
    {
        int currentVarbit = VarAPI.getVar(8121);
        
        // Ignore messages if AI is currently sending a message (prevents self-response)
        if (aiSendingMessage)
        {
            if (config.debug())
            {
                Logger.norm("[AI Chatbot] Ignoring message - AI is currently sending a message");
            }
            return;
        }
        
        // Only respond to public chat messages
        if (event.getType() != ChatMessageType.PUBLICCHAT && event.getType() != ChatMessageType.MODCHAT)
        {
            return;
        }
        
        String senderName = event.getName();
        String message = event.getMessage();
        if (senderName == null || message == null || message.trim().isEmpty())
        {
            return;
        }
        
        // Get local player to check if message is from us (don't respond to our own messages)
        Player localPlayer = Static.invoke(client::getLocalPlayer);
        if (localPlayer != null)
        {
            String localPlayerName = Static.invoke(localPlayer::getName);
            if (localPlayerName != null && localPlayerName.equals(senderName))
            {
                return; // Don't respond to our own messages
            }
        }
        
        // When varbit != 1: Can respond to everyone, but with 30 second cooldown
        if (currentVarbit != 1)
        {
            // Check 30 second cooldown (resets every time a message is received)
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAIChatResponseTime < 30000)
            {
                return; // Still on cooldown
            }
            
            // Update cooldown timer whenever we receive a message (30 seconds from now)
            lastAIChatResponseTime = currentTime;
        }
        // When varbit == 1: Only respond to target, with 5 second cooldown
        else
        {
            // Check if message is from our target
            if (cachedTargetRSN == null || !senderName.equals(cachedTargetRSN))
            {
                return;
            }
            
            // Update last target message time when we receive a message from target
            lastTargetMessageTime = System.currentTimeMillis();
            
            // Check cooldown (5 seconds)
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAIChatResponseTime < 5000)
            {
                return;
            }
        }
        
        // Don't queue if there's already a response queued
        if (queuedAIChatResponse != null)
        {
            return;
        }
        
        // Get AI service (will create/update if needed)
        AIChatService service = getAIChatService();
        if (service == null)
        {
            return;
        }
        
        // Get AI response asynchronously (queue it to be processed)
        // We'll call the API in a separate thread to avoid blocking
        final String messageToRespond = message;
        final int varbitValue = currentVarbit;
        final String senderNameFinal = senderName;
        
        // When varbit != 1, use a random prompt instead of responding to the message
        final String promptToUse;
        if (currentVarbit != 1)
        {
            promptToUse = getRandomLobbyPrompt();
        }
        else
        {
            promptToUse = messageToRespond;
        }
        
        new Thread(() -> {
            try
            {
                String aiResponse = service.getResponse(promptToUse);
                if (aiResponse != null && !aiResponse.trim().isEmpty())
                {
                    queuedAIChatResponse = aiResponse;
                    queuedAIChatResponseTime = System.currentTimeMillis();
                    // Random delay between 2-5 seconds (2000-5000ms)
                    queuedAIChatResponseDelay = 2000 + (long)(Math.random() * 3000);
                    lastAIChatResponseTime = System.currentTimeMillis();
                    
                    if (config.debug())
                    {
                        String targetName = varbitValue == 1 && cachedTargetRSN != null ? cachedTargetRSN : senderNameFinal;
                        Logger.norm("[AI Chatbot] Queued response for '" + targetName + "' (delay: " + queuedAIChatResponseDelay + "ms): " + aiResponse);
                    }
                }
            }
            catch (Exception e)
            {
                Logger.norm("[AI Chatbot] Error getting AI response: " + e.getMessage());
            }
        }).start();
    }

    @Subscribe
    public void onGameTick(GameTick event)
    {
        if (!config.enabled())
        {
            return;
        }
        
        // Verify plugin is running (log once every 50 ticks to avoid spam)
        if (tickCounter % 50 == 0)
        {
            Logger.norm("[AttackTimer] Plugin is running - Tick: " + tickCounter);
        }
        tickCounter++;

        Player localPlayer = Static.invoke(client::getLocalPlayer);
        if (localPlayer == null)
        {
            return;
        }

        // Update target spec tracker
        if (targetSpec != null)
        {
            targetSpec.onGameTick();
        }
        
        // Track how long timer has been at 0
        if (playerTimer != null && playerTimer.ticksRemaining <= 0)
        {
            ticksAtZero++;
        }
        else
        {
            ticksAtZero = 0; // Reset counter when timer is not at 0
        }
        
        // If anglerfish was eaten (flag set by eatAngler() method) and timer hasn't been at 0 for more than 3 ticks, add +3 ticks (capped at 8)
        if (anglerEatenThisTick && playerTimer != null && ticksAtZero <= 3)
        {
            int currentTicks = playerTimer.ticksRemaining;
            int ticksToAdd = 3;
            
            // Cap the timer at 8 ticks
            if (currentTicks + ticksToAdd > 8)
            {
                ticksToAdd = 8 - currentTicks;
            }
            
            if (ticksToAdd > 0)
            {
                playerTimer.addTicks(ticksToAdd);
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Anglerfish eaten - added +" + ticksToAdd + " ticks to timer (capped at 8). Ticks at zero: " + ticksAtZero + ", New timer: " + playerTimer.ticksRemaining);
                }
            }
            ticksAtZero = 0; // Reset counter since timer is no longer at 0
        }
        
        // Reset angler flag after processing (so it's only true for one tick)
        anglerEatenThisTick = false;
        
        // Send queued AI chatbot response (after random delay)
        if (config.aiChatbot() && queuedAIChatResponse != null)
        {
            long currentTime = System.currentTimeMillis();
            long elapsedTime = currentTime - queuedAIChatResponseTime;
            
            // Only send if the random delay has elapsed
            if (elapsedTime >= queuedAIChatResponseDelay)
            {
                try
                {
                    aiSendingMessage = true;
                    com.tonic.util.MessageUtil.sendPublicChatMessage(queuedAIChatResponse);
                    
                    if (config.debug())
                    {
                        Logger.norm("[AI Chatbot] Sent response (after " + elapsedTime + "ms delay): " + queuedAIChatResponse);
                    }
                }
                catch (Exception e)
                {
                    Logger.norm("[AI Chatbot] Error sending message: " + e.getMessage());
                }
                finally
                {
                    aiSendingMessage = false;
                    queuedAIChatResponse = null; // Clear after sending
                    queuedAIChatResponseTime = 0;
                    queuedAIChatResponseDelay = 0;
                }
            }
        }
        

        // Decrement attack timers each tick (but not on the first tick they're created)
        // If a timer was just created this tick, skip decrementing it until next tick
        if (playerTimer != null)
        {
            if (!playerTimerNewThisTick)
            {
                playerTimer.tick();
            }
            else
            {
                playerTimerNewThisTick = false;
            }
            
            if (playerTimer.isExpired())
            {
                playerTimer = null;
            }
        }

        if (opponentTimer != null)
        {
            if (!opponentTimerNewThisTick)
            {
                opponentTimer.tick();
            }
            else
            {
                opponentTimerNewThisTick = false;
            }
            
            if (opponentTimer.isExpired())
            {
                opponentTimer = null;
            }
        }

        // Get current region ID (for logging/debugging)
        WorldPoint playerLocation = localPlayer.getWorldLocation();
        int currentRegionId = ((playerLocation.getX() >> 6) << 8) | (playerLocation.getY() >> 6);
        boolean inArena = (currentRegionId == 13363 || currentRegionId == 13362);
        
        // Arena spawn tile: 39:7:0 in region 13363
        // Convert region-local coordinates to world coordinates
        // Region 13363: regionX = 13363 >> 8 = 52, regionY = 13363 & 0xFF = 51
        // World X = 52 * 64 + 39 = 3367, World Y = 51 * 64 + 7 = 3271
        WorldPoint arenaSpawnTile = new WorldPoint(3367, 3271, 0);
        
        // If in arena and not on spawn tile, walk to it (check every 5 ticks to avoid spam)
        if (inArena && !playerLocation.equals(arenaSpawnTile) && tickCounter % 5 == 0)
        {
            // Check if we're already moving to avoid spamming walk commands
            boolean isMoving = Static.invoke(() -> {
                return MovementAPI.isMoving();
            });
            
            if (!isMoving)
            {
                MovementAPI.walkToWorldPoint(arenaSpawnTile);
                if (config.debug())
                {
                    Logger.norm("[Arena] Not on spawn tile (39:7:0) - walking to " + arenaSpawnTile);
                }
            }
        }
        
        // Track varbit 8121 - this is the PRIMARY indicator for combat-ready state
        int currentVarbit = VarAPI.getVar(8121);
        
        // Log varbit and region only when varbit == 1 (combat state) and it changes or in debug mode
        if (currentVarbit == 1 && (config.debug() || currentVarbit != previousVarbit8121 || currentRegionId != previousRegionId))
        {
            if (config.targetSystemLogging() || config.debug())
            {
                Logger.norm("[Target System] Region ID: " + currentRegionId + ", Varbit 8121: " + currentVarbit + ", Previous Varbit: " + previousVarbit8121 + ", Cached Target: " + (cachedTarget != null ? cachedTargetRSN : "null"));
            }
        }
        
        // Send post-init AI message (10 seconds after init sequence completion)
        if (config.aiChatbot() && initSequenceCompletionTime > 0 && queuedPostInitMessage != null && currentVarbit == 1)
        {
            long currentTime = System.currentTimeMillis();
            long elapsedTime = currentTime - initSequenceCompletionTime;
            
            // Send after 10 seconds (10000ms)
            if (elapsedTime >= 10000)
            {
                try
                {
                    aiSendingMessage = true;
                    com.tonic.util.MessageUtil.sendPublicChatMessage(queuedPostInitMessage);
                    
                    if (config.debug())
                    {
                        Logger.norm("[AI Chatbot] Sent post-init message (after " + elapsedTime + "ms): " + queuedPostInitMessage);
                    }
                }
                catch (Exception e)
                {
                    Logger.norm("[AI Chatbot] Error sending post-init message: " + e.getMessage());
                }
                finally
                {
                    aiSendingMessage = false;
                    queuedPostInitMessage = null; // Clear after sending
                    initSequenceCompletionTime = -1; // Reset completion time
                    // Set last flame message time after sending post-init message
                    lastFlameMessageTime = System.currentTimeMillis();
                }
            }
        }
        
        // Periodic flame messages: Send every 45 seconds when varbit == 1 and no target message received
        if (config.aiChatbot() && currentVarbit == 1 && cachedTargetRSN != null)
        {
            long currentTime = System.currentTimeMillis();
            boolean shouldSendFlame = false;
            
            // Check if we should send a flame message:
            // - 45 seconds since last target message (if we ever received one), OR
            // - 45 seconds since last flame message (if we never received a target message or if last message was a flame)
            if (lastTargetMessageTime == -1)
            {
                // Never received a message from target - check if 45 seconds since last flame
                if (lastFlameMessageTime == -1 || (currentTime - lastFlameMessageTime >= 45000))
                {
                    shouldSendFlame = true;
                }
            }
            else
            {
                // Received a message from target before - check if 45 seconds since that message
                if (currentTime - lastTargetMessageTime >= 45000)
                {
                    // Also check if we haven't sent a flame in the last 45 seconds (to avoid spam)
                    if (lastFlameMessageTime == -1 || (currentTime - lastFlameMessageTime >= 45000))
                    {
                        shouldSendFlame = true;
                    }
                }
            }
            
            if (shouldSendFlame)
            {
                // Don't queue if there's already a response queued
                if (queuedAIChatResponse == null)
                {
                    // Generate flame message asynchronously
                    AIChatService service = getAIChatService();
                    if (service != null)
                    {
                        new Thread(() -> {
                            try
                            {
                                // Generate a silly question about RuneScape (max 7 words)
                                String prompt = "Ask silly questions about runescape, sometimes ask what color socks are u wearing? ask questions Pk related? ask dumb questions. and be super silly in general, every message is max 7 words";
                                String aiMessage = service.getResponse(prompt);
                                if (aiMessage != null && !aiMessage.trim().isEmpty())
                                {
                                    queuedAIChatResponse = aiMessage;
                                    queuedAIChatResponseTime = System.currentTimeMillis();
                                    // Random delay between 2-5 seconds (2000-5000ms)
                                    queuedAIChatResponseDelay = 2000 + (long)(Math.random() * 3000);
                                    lastFlameMessageTime = System.currentTimeMillis(); // Update flame message time
                                    
                                    if (config.debug())
                                    {
                                        Logger.norm("[AI Chatbot] Queued periodic flame message (delay: " + queuedAIChatResponseDelay + "ms): " + aiMessage);
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Logger.norm("[AI Chatbot] Error generating periodic flame message: " + e.getMessage());
                            }
                        }).start();
                    }
                }
            }
        }
        
        // Reset flame message timers when varbit != 1
        if (currentVarbit != 1)
        {
            if (lastTargetMessageTime != -1 || lastFlameMessageTime != -1)
            {
                lastTargetMessageTime = -1;
                lastFlameMessageTime = -1;
            }
        }
        
        // Reset arena exit flags when entering arena (region 13363 or 13362)
        if (inArena && (previousRegionId != 13363 && previousRegionId != 13362))
        {
            shouldClickPortal = false;
            shouldClickGateway = false;
            gatewayClickAttempts = 0; // Reset attempt counter
            Logger.norm("[Arena Exit] Entered arena - reset exit flags");
        }
        
        // PID Status Management: Reset when varbit changes (entering/exiting combat state)
        if (currentVarbit != previousVarbit8121)
        {
            // Reset damage counter on any varbit change
            totalDamageDealt = 0;
            if (configPanel != null)
            {
                configPanel.setTotalDamage(0);
            }
            
            if (pidDetector != null)
            {
                pidDetector.onVarbit8121Changed(currentVarbit);
            }
            if (targetSpec != null)
            {
                targetSpec.onVarbit8121Changed(currentVarbit);
            }
            updatePanel();
        }
        
        // NEW SIMPLIFIED TARGET SYSTEM
        // Flow: Clear target when varbit becomes 1 (entering combat), then set closest player as target
        // Use varbit 8121 as the primary indicator (not region ID)
        
        // Clear target when varbit transitions to 1 (entering combat state)
        if (currentVarbit == 1 && previousVarbit8121 != 1)
        {
            cachedTarget = null;
            cachedTargetRSN = null;
            cachedCombatData = null;
            
            // Clear PID detector target
            if (pidDetector != null)
            {
                pidDetector.setCurrentTarget(null);
            }
            
            // Clear target spec tracker target
            if (targetSpec != null)
            {
                targetSpec.setCurrentTarget(null);
            }
            
            if (config.targetSystemLogging() || config.debug())
            {
                Logger.norm("[Target System] Varbit 8121 became 1 - cleared target (entering combat)");
            }
        }
        
        // If varbit 8121 == 1, set closest player as target
        if (currentVarbit == 1)
        {
            if (config.targetSystemLogging() || config.debug())
            {
                Logger.norm("[Target System] ✓ Varbit 8121 == 1 - checking for target...");
            }
                
                // If we don't have a target, find and set it
                if (cachedTarget == null)
                {
                    if (config.targetSystemLogging() || config.debug())
                    {
                        Logger.norm("[Target System] No cached target - finding nearest player...");
                    }
                    Player nearestPlayer = findNearestPlayer(localPlayer);
                    
                    if (nearestPlayer != null)
                    {
                        String targetName = Static.invoke(nearestPlayer::getName);
                        
                        if (targetName != null && !targetName.isEmpty())
                        {
                            cachedTarget = nearestPlayer;
                            cachedTargetRSN = targetName;
                            
                            // Update PID detector with new target
                            if (pidDetector != null)
                            {
                                pidDetector.setCurrentTarget(cachedTarget);
                                if (config.debug())
                                {
                                    Logger.norm("[PID Detector] Updated target: " + cachedTargetRSN);
                                }
                            }
                            
                            // Update target spec tracker with new target
                            if (targetSpec != null)
                            {
                                targetSpec.setCurrentTarget(cachedTarget);
                            }
                            
                            // Initialize combat log data for AI Prayers if enabled
                            if (config.aiPrayers() && combatLogger != null)
                            {
                                cachedCombatData = combatLogger.getLogDataForTarget(cachedTargetRSN);
                            }
                            
                            if (config.targetSystemLogging() || config.debug())
                            {
                                Logger.norm("[Target System] ✓ Varbit 8121 == 1 - Set target: " + cachedTargetRSN);
                            }
                            updatePanel();
                        }
                    }
                }
                
                // If we have a target name but Player object is null, try to refresh it
                // Only check every 10 ticks to reduce performance impact
                if (cachedTarget == null && cachedTargetRSN != null && tickCounter % 10 == 0)
                {
                    try
                    {
                        // Try to find the player by name to refresh the Player object
                        List<PlayerEx> players = GameManager.playerList();
                        for (PlayerEx pEx : players)
                        {
                            if (pEx == null) continue;
                            Player p = pEx.getPlayer();
                            if (p != null && p != localPlayer)
                            {
                                String pName = Static.invoke(p::getName);
                                if (pName != null && pName.equals(cachedTargetRSN))
                                {
                                    cachedTarget = p;
                                    
                                    // Update PID detector with refreshed target
                                    if (pidDetector != null)
                                    {
                                        pidDetector.setCurrentTarget(cachedTarget);
                                    }
                                    
                                    // Update target spec tracker with refreshed target
                                    if (targetSpec != null)
                                    {
                                        targetSpec.setCurrentTarget(cachedTarget);
                                    }
                                    
                                    if (config.targetSystemLogging() || config.debug())
                                    {
                                        Logger.norm("[Target System] Refreshed target Player object for: " + cachedTargetRSN);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        // Player object is invalid, try to find by name
                        List<PlayerEx> players = GameManager.playerList();
                        for (PlayerEx pEx : players)
                        {
                            if (pEx == null) continue;
                            Player p = pEx.getPlayer();
                            if (p != null && p != localPlayer)
                            {
                                String pName = Static.invoke(p::getName);
                                if (pName != null && pName.equals(cachedTargetRSN))
                                {
                                    cachedTarget = p;
                                    if (config.targetSystemLogging() || config.debug())
                                    {
                                        Logger.norm("[Target System] Refreshed target Player object (from exception) for: " + cachedTargetRSN);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
        }
        // If varbit is not 1, clear target and stop tracking Discord messages
        else
        {
            // Stop tracking Discord messages when varbit != 1
            if (shouldTrackDiscordMessages)
            {
                shouldTrackDiscordMessages = false;
            }
            
            if (cachedTarget != null || cachedTargetRSN != null)
            {
                cachedTarget = null;
                cachedTargetRSN = null;
                cachedCombatData = null;
                
                // Clear PID detector target
                if (pidDetector != null)
                {
                    pidDetector.setCurrentTarget(null);
                }
                
                // Clear target spec tracker target
                if (targetSpec != null)
                {
                    targetSpec.setCurrentTarget(null);
                }
                
                if (config.targetSystemLogging() || config.debug())
                {
                    Logger.norm("[Target System] Varbit 8121 != 1 - Cleared target");
                }
                updatePanel();
            }
        }
        
        // Store current varbit and region ID values for next tick
        previousVarbit8121 = currentVarbit;
        previousRegionId = currentRegionId;
        
        // AI Prayers: Only runs when varbit 8121 == 1 and we have a target
        // Only log when varbit == 1
        if (currentVarbit == 1 && config.debug())
        {
            Logger.norm("[AI Prayers] Check - Enabled: " + config.aiPrayers() + ", Varbit: " + currentVarbit + ", Has Target: " + (cachedTarget != null));
        }
        
        if (config.aiPrayers() && currentVarbit == 1 && cachedTarget != null)
        {
            if (config.aiPrayersLogging())
            {
                Logger.norm("[AI Prayers] ✓ Running - Varbit: " + currentVarbit + ", Target: " + cachedTargetRSN);
            }
            
            // Update display data for infobox
            updateAIPrayersDisplayData(localPlayer);
            
            // Activate prayers (varbit == 1 is sufficient check)
            // When timer is null (no timer or expired) OR timer is at 0, spam weighted prayers every tick (guessing mode)
            if (opponentTimer == null || opponentTimer.ticksRemaining == 0)
            {
                // Weighted guessing mode - spam weighted prayers every tick based on JSON data
                handleAIPrayers(localPlayer);
            }
            // When timer is at 1, use data-based prayer selection (predicting mode)
            else if (opponentTimer.ticksRemaining == 1)
            {
                handleAIPrayers(localPlayer);
            }
        }
        else
        {
            // AI Prayers disabled - clear display data
            aiPrayersData = null;
        }

        // Arena Exit Logic: Click Portal/Gateway to exit arena
        // Portal: Click when flag is set AND varbit != 1 AND not in arena (we died, need to leave)
        // Gateway: Click when flag is set (keep clicking until we leave arena region)
        
        // Check if we successfully left the arena REGION (not just varbit change)
        // Only clear the flag when we're actually outside the arena
        boolean wasInArena = (previousRegionId == 13363 || previousRegionId == 13362);
        if (shouldClickGateway && wasInArena && !inArena)
        {
            Logger.norm("[Arena Exit] Successfully left arena via Gateway (region changed from " + previousRegionId + " to " + currentRegionId + ")");
            shouldClickGateway = false;
            gatewayClickAttempts = 0;
        }
        
        // If we died - click Portal (even when varbit != 1, as long as we're not in arena)
        // Only search every 3 ticks to reduce performance impact
        if (shouldClickPortal && currentVarbit != 1 && !inArena && tickCounter % 3 == 0)
        {
            TileObjectEx portal = new TileObjectQuery()
                .withName("Portal")
                .first();
            
            if (portal != null)
            {
                TileObjectAPI.interact(portal, 0);
                if (config.debug())
                {
                    Logger.norm("[Arena Exit] Clicking Portal (died - varbit: " + currentVarbit + ", region: " + currentRegionId + ")");
                }
            }
        }
        // If we won - click Gateway (ROBUST: try every tick until we leave arena region)
        else if (shouldClickGateway && inArena && gatewayClickAttempts < MAX_GATEWAY_CLICK_ATTEMPTS)
        {
            // Always try to click Gateway if we're still in arena and flag is set
            // Don't care about varbit - just keep clicking until we leave the region
            gatewayClickAttempts++; // Increment attempt counter
            
            TileObjectEx gateway = new TileObjectQuery()
                .withName("Gateway")
                .first();
            
            if (gateway != null)
            {
                // Try interacting with Gateway
                TileObjectAPI.interact(gateway, 0);
                
                if (config.debug() || gatewayClickAttempts % 10 == 0) // Log every 10 attempts to avoid spam
                {
                    Logger.norm("[Arena Exit] Clicking Gateway (attempt " + gatewayClickAttempts + "/" + MAX_GATEWAY_CLICK_ATTEMPTS + 
                               " - varbit: " + currentVarbit + ", region: " + currentRegionId + ", inArena: " + inArena + ")");
                }
            }
            else
            {
                // Fallback: try common alternative names
                TileObjectEx alt = new TileObjectQuery()
                    .withName("Exit")
                    .first();
                if (alt == null)
                {
                    alt = new TileObjectQuery()
                        .withName("Portal")
                        .first();
                }
                if (alt != null)
                {
                    TileObjectAPI.interact(alt, 0);
                    if (config.debug() || gatewayClickAttempts % 10 == 0)
                    {
                        Logger.norm("[Arena Exit] Gateway not found, clicked alternative '" + alt.getName() + "' (attempt " + gatewayClickAttempts + ")");
                    }
                }
                else if (gatewayClickAttempts % 10 == 0) // Log every 10 attempts
                {
                    Logger.norm("[Arena Exit] Gateway not found (attempt " + gatewayClickAttempts + "/" + MAX_GATEWAY_CLICK_ATTEMPTS + 
                               " - varbit: " + currentVarbit + ", region: " + currentRegionId + ")");
                }
            }
            
            // If we've exceeded max attempts, give up and log warning
            if (gatewayClickAttempts >= MAX_GATEWAY_CLICK_ATTEMPTS)
            {
                Logger.norm("[Arena Exit] WARNING: Exceeded max Gateway click attempts (" + MAX_GATEWAY_CLICK_ATTEMPTS + 
                           ") - giving up. Varbit: " + currentVarbit + ", Region: " + currentRegionId);
                shouldClickGateway = false;
                gatewayClickAttempts = 0;
            }
        }
        
        // Note: Arena entry flag clearing is handled earlier in onGameTick (line ~1321)
        // when we detect entering arena region for the first time

        // Initialization Sequence Handler (when varbit == 1 and sequence is active)
        if (initSequenceActive && currentVarbit == 1)
        {
            initSequenceTicks++;
            
            switch (initSequenceStep)
            {
                case 1: // Step 1: Put on tank gear, eat anglerfish (same tick)
                    equipGearFromConfig(config.tankGear());
                    // Eat anglerfish
                    List<ItemEx> inventoryItems = InventoryAPI.getItems();
                    for (ItemEx item : inventoryItems)
                    {
                        if (item != null && item.getName() != null && item.getName().toLowerCase().contains("angler"))
                        {
                            String[] actions = item.getActions();
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase("Eat"))
                                {
                                    InventoryAPI.interact(item, "Eat");
                                    anglerEatenThisTick = true;
                                    break;
                                }
                            }
                        }
                    }
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Step 1: Put on tank gear and ate anglerfish");
                    }
                    initSequenceStep = 2; // Move to next step
                    initSequenceTicks = 0;
                    break;
                    
                case 2: // Step 2: Next tick - drink bastion potion
                    List<ItemEx> bastionItems = InventoryAPI.getItems();
                    boolean bastionDrank = false;
                    for (ItemEx item : bastionItems)
                    {
                        if (item != null && item.getName() != null)
                        {
                            String itemName = item.getName();
                            if (itemName.toLowerCase().startsWith("bastion"))
                            {
                                String[] actions = item.getActions();
                                for (String action : actions)
                                {
                                    if (action != null && action.equalsIgnoreCase("Drink"))
                                    {
                                        InventoryAPI.interact(item, "Drink");
                                        bastionDrank = true;
                                        break;
                                    }
                                }
                            }
                            if (bastionDrank) break;
                        }
                    }
                    if (bastionDrank)
                    {
                        if (config.combatAutomationLogging())
                        {
                            Logger.norm("[Init Sequence] Step 2: Drank bastion potion");
                        }
                        initSequenceStep = 3; // Move to next step
                        initSequenceTicks = 0;
                    }
                    break;
                    
                case 3: // Step 3: Walk to random tile up to 6 tiles
                    WorldPoint playerPos = localPlayer.getWorldLocation();
                    // Generate random offsets (up to 6 tiles in any direction)
                    int offsetX = random.nextInt(13) - 6; // -6 to +6
                    int offsetY = random.nextInt(13) - 6; // -6 to +6
                    WorldPoint randomTile = new WorldPoint(
                        playerPos.getX() + offsetX,
                        playerPos.getY() + offsetY,
                        playerPos.getPlane()
                    );
                    MovementAPI.walkToWorldPoint(randomTile);
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Step 3: Walking to random tile (" + randomTile.getX() + ", " + randomTile.getY() + ")");
                    }
                    initSequenceStep = 4; // Move to next step
                    initSequenceTicks = 0;
                    break;
                    
                case 4: // Step 4: Wait 4 ticks
                    if (initSequenceTicks >= 4)
                    {
                        if (config.combatAutomationLogging())
                        {
                            Logger.norm("[Init Sequence] Step 4: Waited 4 ticks");
                        }
                        initSequenceStep = 5; // Move to next step
                        initSequenceTicks = 0;
                    }
                    break;
                    
                case 5: // Step 5: Eat super combat potion
                    List<ItemEx> superCombatItems = InventoryAPI.getItems();
                    boolean superCombatDrank = false;
                    for (ItemEx item : superCombatItems)
                    {
                        if (item != null && item.getName() != null)
                        {
                            String itemName = item.getName();
                            if (itemName.toLowerCase().startsWith("super combat"))
                            {
                                String[] actions = item.getActions();
                                for (String action : actions)
                                {
                                    if (action != null && action.equalsIgnoreCase("Drink"))
                                    {
                                        InventoryAPI.interact(item, "Drink");
                                        superCombatDrank = true;
                                        break;
                                    }
                                }
                            }
                            if (superCombatDrank) break;
                        }
                    }
                    if (superCombatDrank)
                    {
                        if (config.combatAutomationLogging())
                        {
                            Logger.norm("[Init Sequence] Step 5: Drank super combat potion");
                        }
                        initSequenceStep = 6; // Move to next step
                        initSequenceTicks = 0;
                    }
                    break;
                    
                case 6: // Step 6: Wait 1 tick
                    if (initSequenceTicks >= 1)
                    {
                        if (config.combatAutomationLogging())
                        {
                            Logger.norm("[Init Sequence] Step 6: Waited 1 tick");
                        }
                        initSequenceStep = 7; // Move to next step
                        initSequenceTicks = 0;
                    }
                    break;
                    
                case 7: // Step 7: Walk to random tile up to 6 tiles again
                    WorldPoint playerPos2 = localPlayer.getWorldLocation();
                    // Generate random offsets (up to 6 tiles in any direction)
                    int offsetX2 = random.nextInt(13) - 6; // -6 to +6
                    int offsetY2 = random.nextInt(13) - 6; // -6 to +6
                    WorldPoint randomTile2 = new WorldPoint(
                        playerPos2.getX() + offsetX2,
                        playerPos2.getY() + offsetY2,
                        playerPos2.getPlane()
                    );
                    MovementAPI.walkToWorldPoint(randomTile2);
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Init Sequence] Step 7: Walking to random tile (" + randomTile2.getX() + ", " + randomTile2.getY() + ")");
                    }
                    initSequenceStep = 8; // Move to final step (wait for "1" message)
                    initSequenceTicks = 0;
                    break;
                    
                case 8: // Step 8: Wait for "1" message (handled in onChatMessage)
                    // Do nothing here - waiting for chat message
                    break;
            }
        }
        
        // Reset initialization sequence if varbit != 1
        if (initSequenceActive && currentVarbit != 1)
        {
            if (config.combatAutomationLogging())
            {
                Logger.norm("[Init Sequence] Varbit != 1, resetting sequence");
            }
            initSequenceActive = false;
            initSequenceStep = 0;
            initSequenceTicks = 0;
        }
        
        // Spec Dump Mode: Increment timer and check for activation
        if (currentVarbit == 1 && ticksSinceGameStart >= 0)
        {
            ticksSinceGameStart++;
            
            // Check for early game activation: 75 ticks elapsed AND spec is 100%
            if (ticksSinceGameStart == 75 && !specDumpModeActive)
            {
                int specEnergy = com.tonic.api.game.CombatAPI.getSpecEnergy();
                if (specEnergy >= 100)
                {
                    specDumpModeActive = true;
                    Logger.norm("[Spec Dump] Early game activation - 75 ticks elapsed, spec is " + specEnergy + "%, entering spec dump mode");
                }
            }
        }
        else if (currentVarbit != 1)
        {
            // Reset timer when leaving combat
            ticksSinceGameStart = -1;
            specDumpModeActive = false;
        }
        
        // Check for late-game activation: Low food + spec >= 50% (no timer needed, just check conditions every tick)
        if (currentVarbit == 1 && !specDumpModeActive)
        {
            // Count anglers and brews
            int anglerCount = 0;
            int brewCount = InventoryAPI.count("Saradomin brew(4)", "Saradomin brew(3)", "Saradomin brew(2)", "Saradomin brew(1)");
            for (ItemEx item : InventoryAPI.getItems())
            {
                if (item != null && item.getName() != null && item.getName().toLowerCase().contains("angler"))
                {
                    anglerCount += item.getQuantity();
                }
            }
            
            // Late-game conditions: anglers < 4 AND brews <= 2 AND spec >= 50% (no timer requirement)
            if (anglerCount < 4 && brewCount <= 2)
            {
                int specEnergy = com.tonic.api.game.CombatAPI.getSpecEnergy();
                if (specEnergy >= 50)
                {
                    specDumpModeActive = true;
                    Logger.norm("[Spec Dump] Late-game activation - Low food (anglers: " + anglerCount + ", brews: " + brewCount + "), spec is " + specEnergy + "%, entering spec dump mode");
                }
            }
        }
        
        // Check for damage-based activation: totalDamageDealt >= 465 + spec >= 50% + we are unfrozen
        if (currentVarbit == 1 && !specDumpModeActive)
        {
            // Check if we're unfrozen
            boolean weFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
            
            if (!weFrozen && totalDamageDealt >= 465)
            {
                int specEnergy = com.tonic.api.game.CombatAPI.getSpecEnergy();
                if (specEnergy >= 50)
                {
                    specDumpModeActive = true;
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Spec Dump] Damage-based activation - Total damage: " + totalDamageDealt + ", spec is " + specEnergy + "%, we are unfrozen, entering spec dump mode");
                    }
                }
            }
        }
        
        // Check for exit conditions: Spec drops below threshold (50% for late-game)
        // Note: Early game spec dump mode is automatically turned off after executing one spec
        // Late game mode will reactivate automatically if conditions are met again
        if (specDumpModeActive)
        {
            int specEnergy = com.tonic.api.game.CombatAPI.getSpecEnergy();
            // Exit if spec drops below 50% (late game exit condition)
            if (specEnergy < 50)
            {
                specDumpModeActive = false;
                if (config.combatAutomationLogging())
                {
                    Logger.norm("[Spec Dump] Exiting spec dump mode - spec dropped below 50% (now: " + specEnergy + "%)");
                }
            }
        }
        
        // Combat Automation - Both Unfrozen state (only when varbit 8121 == 1)
        // Only log when varbit == 1
        if (currentVarbit == 1 && config.debug())
        {
            Logger.norm("[Combat Automation] Check - Enabled: " + config.combatAutomation() + ", Varbit: " + currentVarbit);
        }
        
        if (config.combatAutomation())
        {
            // Only run combat automation when varbit 8121 == 1 AND initialization sequence is NOT active
            if (currentVarbit == 1 && !initSequenceActive)
            {
                if (config.combatAutomationLogging())
                {
                    Logger.norm("[Combat Automation] ✓ Running - Varbit: " + currentVarbit + ", Target: " + (cachedTarget != null ? cachedTargetRSN : "null"));
                }
                
                // Track magic XP for cast detection
                int currentMagicXP = SkillAPI.getExperience(Skill.MAGIC);
                
                // Debug: Always log current XP state if waiting for XP
                if (config.debug() && waitingForCastXP)
                {
                    Logger.norm("[Magic XP Debug] Waiting for XP - Last: " + lastMagicXP + ", Current: " + currentMagicXP + 
                             (lastMagicXP != -1 ? (currentMagicXP > lastMagicXP ? " (INCREASED!)" : " (no change)") : " (first check)"));
                }
                
                // Debug: Log if XP changed even when not waiting (for general tracking)
                if (config.debug() && lastMagicXP != -1 && currentMagicXP > lastMagicXP && !waitingForCastXP)
                {
                    Logger.norm("[Magic XP Debug] XP increased but NOT waiting for cast - Last: " + lastMagicXP + ", Current: " + currentMagicXP + 
                             " (XP gain: " + (currentMagicXP - lastMagicXP) + ")");
                }
                
                if (waitingForCastXP)
                {
                    // Increment tick counter
                    waitingForCastXPTicks++;
                    
                    // Timeout after 1 tick - XP should increase immediately
                    if (waitingForCastXPTicks > 1)
                    {
                        Logger.norm("[Magic XP Debug] Timeout after " + waitingForCastXPTicks + " ticks - clearing cast XP flag");
                        waitingForCastXP = false;
                        waitingForCastXPTicks = 0;
                        waitingForCastAnimation = false;
                        waitingForCastAnimationTicks = 0;
                        equipGearFromConfig(config.tankGear());
                    }
                    else if (lastMagicXP != -1 && currentMagicXP > lastMagicXP)
                    {
                        int xpGain = currentMagicXP - lastMagicXP;
                        // XP gained - spell was cast
                        if (config.debug())
                        {
                            Logger.norm("[Magic XP Debug] ✓ MAGIC XP DETECTED! Last: " + lastMagicXP + ", Current: " + currentMagicXP + 
                                     " (XP gain: " + xpGain + ")");
                        }
                        
                        waitingForCastXP = false;
                        waitingForCastXPTicks = 0;
                        waitingForCastAnimation = false;
                        waitingForCastAnimationTicks = 0;
                    
                    // If we got XP but didn't see animation, still create/update timer (+5 ticks)
                    // This handles cases where animation doesn't show but spell was still cast
                    // Check if animation was already detected (playerTimer is already a Magic timer created this tick)
                    boolean animationAlreadyDetected = (playerTimer != null && "Magic".equals(playerTimer.weaponName) && playerTimerNewThisTick);
                    
                    if (!animationAlreadyDetected)
                    {
                        // Animation wasn't detected, but XP was - create or update timer
                        if (playerTimer == null || !"Magic".equals(playerTimer.weaponName))
                        {
                            // Create new magic timer
                            playerTimer = new AttackTimer("Magic", 5);
                            playerTimerNewThisTick = true;
                            if (config.debug())
                            {
                                Logger.norm("[Magic XP Debug] Detected magic XP gain without animation - created magic timer (+5 ticks). Timer: " + playerTimer.ticksRemaining);
                            }
                        }
                        else
                        {
                            // Timer already exists and is magic timer - add 5 ticks
                            playerTimer.addTicks(5);
                            if (config.debug())
                            {
                                Logger.norm("[Magic XP Debug] Detected magic XP gain without animation - added +5 ticks. Timer: " + playerTimer.ticksRemaining);
                            }
                        }
                    }
                    else
                    {
                        // Animation was already detected, so timer was already created - just log
                        if (config.debug())
                        {
                            Logger.norm("[Magic XP Debug] Detected magic XP gain with animation already detected - timer already set. Timer: " + playerTimer.ticksRemaining);
                        }
                    }
                    
                        // After XP/animation: Equip tank gear (loadout 1)
                        equipGearFromConfig(config.tankGear());
                        if (config.debug())
                        {
                            Logger.norm("[Magic XP Debug] Detected magic XP gain - equipping tank gear (loadout 1)");
                        }
                        updatePanel(); // Force overlay update
                    }
                }
                lastMagicXP = currentMagicXP;
                
                // Auto-accept duel requests are now handled directly in DuelChallengeHandler.onChatMessage()
                // by calling PlayerAPI.interact(player, "Challenge") when a challenge message is received
                // No need to check trade windows anymore - disabled to prevent conflicts
                // if (config.autoAcceptDuel() && inArena && tickCounter % 5 == 0)
                // {
                //     autoAcceptDuelRequest();
                // }
                
                // Target is managed in the main target system above
                // Just call handleCombatAutomation - it will use cachedTarget
                handleCombatAutomation(localPlayer);
            }
            else
            {
                // Not in arena or varbit is false - reset state
                waitingForCastAnimation = false;
                waitingForCastXP = false;
            }
        }
        else
        {
            // Reset combat automation state when disabled
            waitingForCastAnimation = false;
            waitingForCastXP = false;
            lastMagicXP = -1;
        }
        
        // Send challenge back if needed (bulletproof: one challenge per flag)
        // This must be outside combatAutomation and inArena checks
        // Check both enabled and autoAcceptDuel to prevent processing when plugin is disabled
        if (config.enabled() && config.autoAcceptDuel() && duelChallengeHandler != null)
        {
            duelChallengeHandler.sendChallengeBackIfNeeded();
        }
        
        // Handle confirmation screen regardless of arena state (screen can appear before entering)
        // This must be outside combatAutomation and inArena checks
        // Check both enabled and autoAcceptDuel to prevent processing when plugin is disabled
        if (config.enabled() && config.autoAcceptDuel() && duelChallengeHandler != null)
        {
            duelChallengeHandler.handleDuelConfirmation();
        }

        // Gear Test - Debug/Test feature: equip tank gear directly from inventory
        boolean currentGearTestState = config.gearTest();
        if (currentGearTestState && !previousGearTestState)
        {
            // Toggle just turned on - execute gear test once
            handleGearTest();
            gearTestExecuted = true;
        }
        else if (!currentGearTestState)
        {
            // Toggle turned off - reset state
            gearTestExecuted = false;
        }
        previousGearTestState = currentGearTestState;
        
        // Tank toggle - equip tank gear and activate Augury (continuously while enabled)
        if (config.tank())
        {
            equipTankGearAndPrayer();
        }
        
        // Range Attack - equip ranged gear and attack target, then switch to tank after animation (run once per toggle)
        boolean currentRangeAttackState = config.rangeAttack();
        
        if (currentRangeAttackState && !previousRangeAttackState && !waitingForCrossbowAnimation)
        {
            // Toggle just turned on - execute ranged attack sequence
            if (config.debug())
            {
                Logger.norm("[Range Attack Toggle] Toggle turned ON - triggering handleRangeAttack");
            }
            handleRangeAttack(localPlayer);
        }
        else if (!currentRangeAttackState && previousRangeAttackState)
        {
            // Toggle just turned off - reset state (only when it was previously on)
            if (config.debug())
            {
                Logger.norm("[Range Attack Toggle] Toggle turned OFF - resetting state");
            }
            waitingForCrossbowAnimation = false;
        }
        previousRangeAttackState = currentRangeAttackState;

        // Debug diagonal detection toggle
        if (config.debugDiagonal())
        {
            // Get target - prioritize cached target if in arena, otherwise use interacting target
            Player target = null;
            WorldPoint playerLoc = localPlayer.getWorldLocation();
            int regionId = ((playerLoc.getX() >> 6) << 8) | (playerLoc.getY() >> 6);
            boolean inArenaCheck = (regionId == 13363 || regionId == 13362);
            
            if (cachedTarget != null)
            {
                // Use cached target (only exists when varbit 8121 == 1)
                target = cachedTarget;
            }
            else
            {
                // Check current interacting target
                Actor interactingTarget = Static.invoke(localPlayer::getInteracting);
                if (interactingTarget instanceof Player)
                {
                    target = (Player) interactingTarget;
                }
            }
            
            if (target != null)
            {
                WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                WorldPoint targetPos = Static.invoke(target::getWorldLocation);
                
                int dx = Math.abs(playerPos.getX() - targetPos.getX());
                int dy = Math.abs(playerPos.getY() - targetPos.getY());
                int distance = dx + dy; // Manhattan distance
                
                // Target is diagonal if both dx and dy are > 0 (diagonal position)
                // This means they're 1 tile away diagonally (Manhattan distance = 2) and can't be meleed
                boolean isDiagonal = (dx > 0 && dy > 0);
                boolean canMelee = distance <= 1;
                
                Logger.norm("[Diagonal Debug] Target: " + Static.invoke(target::getName) + 
                           ", dx: " + dx + ", dy: " + dy + 
                           ", Manhattan distance: " + distance + 
                           ", isDiagonal: " + isDiagonal + 
                           ", canMelee: " + canMelee + 
                           " (diagonal = 1 tile away but can't melee)");
            }
            else
            {
                Logger.norm("[Diagonal Debug] No target found (interacting: " + (Static.invoke(localPlayer::getInteracting) != null) + 
                           ", cached: " + (cachedTarget != null) + ", varbit: " + currentVarbit + ")");
            }
        }
        
        // Check for freeze GFX and handle freeze timers
        checkFreezeStatus(localPlayer);

        // Decrement freeze timers (but not on the first tick they're created)
        if (playerFreezeTimer != null)
        {
            if (!playerFreezeNewThisTick)
            {
                playerFreezeTimer.tick();
            }
            else
            {
                playerFreezeNewThisTick = false;
                // Don't tick on first tick - just mark as no longer new
            }
            
            // Only clear if truly expired (state is NONE)
            if (!playerFreezeTimer.isActive())
            {
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Player freeze timer expired - clearing. State: " + playerFreezeTimer.state + ", Ticks: " + playerFreezeTimer.ticksRemaining);
                }
                playerFreezeTimer = null;
            }
            else if (config.debug())
            {
                Logger.norm("[AttackTimer] Player freeze timer still active - State: " + playerFreezeTimer.state + ", Ticks: " + playerFreezeTimer.ticksRemaining);
            }
        }

        if (opponentFreezeTimer != null)
        {
            if (!opponentFreezeNewThisTick)
            {
                opponentFreezeTimer.tick();
            }
            else
            {
                opponentFreezeNewThisTick = false;
                // Don't tick on first tick - just mark as no longer new
            }
            
            // Only clear if truly expired (state is NONE)
            if (!opponentFreezeTimer.isActive())
            {
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Opponent freeze timer expired - clearing. State: " + opponentFreezeTimer.state + ", Ticks: " + opponentFreezeTimer.ticksRemaining);
                }
                opponentFreezeTimer = null;
            }
            else if (config.debug())
            {
                Logger.norm("[AttackTimer] Opponent freeze timer still active - State: " + opponentFreezeTimer.state + ", Ticks: " + opponentFreezeTimer.ticksRemaining);
            }
        }
        
        // FREEZE SAFETY CHECK: While frozen, click a random tile to verify we're actually frozen
        // Only do this if our attack timer is > 3 (we have time, not about to attack)
        // If we move, the existing movement detection will reset the freeze timer automatically
        boolean weAreFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
        if (weAreFrozen)
        {
            // Check if attack timer is > 3 (we have time to test freeze)
            int attackTimerTicks = (playerTimer != null) ? playerTimer.ticksRemaining : -1;
            
            if (attackTimerTicks > 3)
            {
                // Click a random tile within 6 tiles of current position to test if we're actually frozen
                WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                int offsetX = random.nextInt(13) - 6; // -6 to +6
                int offsetY = random.nextInt(13) - 6; // -6 to +6
                WorldPoint randomTile = new WorldPoint(
                    playerPos.getX() + offsetX,
                    playerPos.getY() + offsetY,
                    playerPos.getPlane()
                );
                
                MovementAPI.walkToWorldPoint(randomTile);
                
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Freeze safety check: Clicked random tile at (" + randomTile.getX() + ", " + randomTile.getY() + ") to verify freeze status (attack timer: " + attackTimerTicks + ")");
                }
            }
        }
        else
        {
            // Not frozen - reset the counter (though we don't use it anymore, keeping for potential future use)
            frozenSafetyCheckTicks = 0;
        }

        updatePanel();
    }

    private void checkFreezeStatus(Player localPlayer)
    {
        // Check player freeze status
        int playerGraphic = Static.invoke(localPlayer::getGraphic);
        WorldPoint playerPosition = Static.invoke(localPlayer::getWorldLocation);
        
        // Store previous position BEFORE any updates
        WorldPoint previousPlayerPosition = playerLastPosition;
        
        // Check for freeze GFX FIRST (before movement check)
        // This way we can set position correctly when freeze is detected
        boolean playerFreezeDetectedThisTick = false;
        if (isFreezeGraphic(playerGraphic))
        {
            // If no freeze timer exists OR if current timer allows being frozen, create new freeze
            if (playerFreezeTimer == null || playerFreezeTimer.canBeFrozen())
            {
                // Create new freeze timer
                playerFreezeTimer = new FreezeTimer();
                playerFreezeNewThisTick = true;
                playerFreezeDetectedThisTick = true;
                
                // CRITICAL: Set position tracking to current position when freeze is detected
                // This ensures movement check on next tick compares freeze position to itself (no movement)
                playerLastPosition = playerPosition;
                
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Player freeze detected - GFX: " + playerGraphic + ", Position: " + playerPosition + ", Timer state: " + playerFreezeTimer.state + ", Ticks: " + playerFreezeTimer.ticksRemaining);
                }
                
                // Force overlay update immediately to show the freeze timer
                updatePanel();
            }
            else if (config.debug())
            {
                Logger.norm("[AttackTimer] Player freeze GFX detected (" + playerGraphic + ") but cannot freeze - current state: " + playerFreezeTimer.state + ", ticks: " + playerFreezeTimer.ticksRemaining);
            }
        }
        
        // Check if player moved during freeze (only if they're currently frozen AND freeze wasn't just detected this tick)
        // This check MUST come BEFORE updating playerLastPosition to compare old position to current position
        if (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN && !playerFreezeDetectedThisTick)
        {
            // Only check for movement if we have a valid previous position AND it's different
            if (previousPlayerPosition != null && !previousPlayerPosition.equals(playerPosition))
            {
                // Calculate actual distance moved (in tiles)
                int dx = Math.abs(playerPosition.getX() - previousPlayerPosition.getX());
                int dy = Math.abs(playerPosition.getY() - previousPlayerPosition.getY());
                int dz = Math.abs(playerPosition.getPlane() - previousPlayerPosition.getPlane());
                
                // Only reset if player actually moved to a different tile
                if (dx > 0 || dy > 0 || dz > 0)
                {
                    // Player moved while frozen - reset freeze timer
                    if (config.debug())
                    {
                        Logger.norm("[AttackTimer] Player moved while frozen - resetting freeze timer. Old: " + previousPlayerPosition + ", New: " + playerPosition + " (dx=" + dx + ", dy=" + dy + ", dz=" + dz + ")");
                    }
                    playerFreezeTimer.reset();
                    playerFreezeTimer = null;
                    // After resetting freeze timer, still update position tracking
                    playerLastPosition = playerPosition;
                    return; // Early return since we've handled movement
                }
            }
        }
        
        // Update position tracking (unless we just set it above due to freeze detection)
        // This comes AFTER movement check so we can compare old vs new position correctly
        if (!playerFreezeDetectedThisTick)
        {
            playerLastPosition = playerPosition;
        }
        
        // Debug logging for player freeze timer
        if (config.debug() && playerFreezeTimer != null)
        {
            Logger.norm("[AttackTimer] Player freeze timer - State: " + playerFreezeTimer.state + ", Ticks: " + playerFreezeTimer.ticksRemaining + ", Position: " + playerPosition + ", Last Position: " + playerLastPosition);
        }

        // Check opponent freeze status - check both:
        // 1. Actor we're attacking (localPlayer.getInteracting() == actor)
        // 2. Actor attacking us (actor.getInteracting() == localPlayer)
        Actor ourTarget = Static.invoke(localPlayer::getInteracting);
        Player opponent = null;
        
        // First, check if we have a target we're attacking
        if (ourTarget != null && ourTarget instanceof Player)
        {
            opponent = (Player) ourTarget;
        }
        else
        {
            // No target currently - but DON'T clear the freeze timer!
            // The opponent might still be frozen even if we're not interacting
            // Only clear if the timer expires naturally or opponent moves
            // We just won't be able to track new freezes or movement until we have a target again
            if (config.debug() && opponentFreezeTimer != null)
            {
                Logger.norm("[AttackTimer] No opponent target but freeze timer still active - keeping it. State: " + opponentFreezeTimer.state + ", Ticks: " + opponentFreezeTimer.ticksRemaining);
            }
            // Don't reset position tracking if freeze timer is active - we might need it for movement detection
            // Only reset if no freeze timer exists
            if (opponentFreezeTimer == null)
            {
                opponentLastPosition = null;  // Reset position tracking only when no freeze timer
            }
        }
        
        if (opponent != null)
        {
            int opponentGraphic = Static.invoke(opponent::getGraphic);
            WorldPoint opponentPosition = Static.invoke(opponent::getWorldLocation);
            
            // Store previous position BEFORE any updates
            // Initialize opponentLastPosition if it's null (first time seeing this opponent)
            if (opponentLastPosition == null)
            {
                opponentLastPosition = opponentPosition;
                if (config.debug())
                {
                    Logger.norm("[AttackTimer] Initialized opponent position tracking: " + opponentPosition);
                }
            }
            
            WorldPoint previousOpponentPosition = opponentLastPosition;
            
            // Check for freeze GFX FIRST (before movement check)
            // This way we can set position correctly when freeze is detected
            boolean freezeDetectedThisTick = false;
            if (isFreezeGraphic(opponentGraphic))
            {
                // If no freeze timer exists OR if current timer allows being frozen, create new freeze
                if (opponentFreezeTimer == null || opponentFreezeTimer.canBeFrozen())
                {
                    // Create new freeze timer
                    opponentFreezeTimer = new FreezeTimer();
                    opponentFreezeNewThisTick = true;
                    freezeDetectedThisTick = true;
                    
                    // CRITICAL: Set position tracking to current position when freeze is detected
                    // This ensures movement check on next tick compares freeze position to itself (no movement)
                    opponentLastPosition = opponentPosition;
                    
                    if (config.debug())
                    {
                        Logger.norm("[AttackTimer] Opponent freeze detected - GFX: " + opponentGraphic + ", Position: " + opponentPosition + ", Timer state: " + opponentFreezeTimer.state + ", Ticks: " + opponentFreezeTimer.ticksRemaining);
                    }
                    
                    // Force overlay update immediately to show the freeze timer
                    updatePanel();
                }
                else if (config.debug())
                {
                    Logger.norm("[AttackTimer] Opponent freeze GFX detected (" + opponentGraphic + ") but cannot freeze - current state: " + opponentFreezeTimer.state + ", ticks: " + opponentFreezeTimer.ticksRemaining);
                }
            }
            
            // Check if opponent moved during freeze (only if they're currently frozen AND freeze wasn't just detected this tick)
            // This check MUST come BEFORE updating opponentLastPosition to compare old position to current position
            boolean opponentMovedWhileFrozen = false;
            if (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN && !freezeDetectedThisTick)
            {
                // Check for movement if we have a valid previous position
                // Note: previousOpponentPosition should never be null here since we initialize it above
                if (previousOpponentPosition != null)
                {
                    // Check if position changed (even slightly)
                    if (!previousOpponentPosition.equals(opponentPosition))
                    {
                        // Calculate actual distance moved (in tiles)
                        int dx = Math.abs(opponentPosition.getX() - previousOpponentPosition.getX());
                        int dy = Math.abs(opponentPosition.getY() - previousOpponentPosition.getY());
                        int dz = Math.abs(opponentPosition.getPlane() - previousOpponentPosition.getPlane());
                        
                        // Only reset if opponent actually moved to a different tile
                        if (dx > 0 || dy > 0 || dz > 0)
                        {
                            // Opponent moved while frozen - reset freeze timer
                            if (config.debug())
                            {
                                Logger.norm("[AttackTimer] Opponent moved while frozen - resetting freeze timer. Old: " + previousOpponentPosition + ", New: " + opponentPosition + " (dx=" + dx + ", dy=" + dy + ", dz=" + dz + ")");
                            }
                            opponentFreezeTimer.reset();
                            opponentFreezeTimer = null;
                            opponentMovedWhileFrozen = true;
                            // After resetting freeze timer, still update position tracking
                            opponentLastPosition = opponentPosition;
                        }
                        else if (config.debug())
                        {
                            Logger.norm("[AttackTimer] Opponent position changed but same tile? Old: " + previousOpponentPosition + ", New: " + opponentPosition);
                        }
                    }
                }
                else if (config.debug())
                {
                    Logger.norm("[AttackTimer] Opponent is frozen but previous position is null - cannot detect movement");
                }
            }
            
            // Update position tracking (unless we just set it above due to freeze detection or movement reset)
            // This comes AFTER movement check so we can compare old vs new position correctly
            if (!freezeDetectedThisTick && !opponentMovedWhileFrozen)
            {
                opponentLastPosition = opponentPosition;
            }
            
            // Debug logging for opponent graphics
            if (!freezeDetectedThisTick && config.debug() && opponentGraphic != -1)
            {
                // Debug: log non-freeze graphics to help identify correct GFX IDs
                Logger.norm("[AttackTimer] Opponent graphic: " + opponentGraphic + " (not a freeze GFX)");
            }
            
            // Debug: log freeze timer state each tick if active
            if (config.debug() && opponentFreezeTimer != null)
            {
                Logger.norm("[AttackTimer] Opponent freeze timer - State: " + opponentFreezeTimer.state + ", Ticks: " + opponentFreezeTimer.ticksRemaining + ", Position: " + opponentPosition + ", Last Position: " + opponentLastPosition);
            }
        }
    }

    private boolean isFreezeGraphic(int graphicId)
    {
        if (graphicId == -1)
        {
            return false;
        }
        
        for (int freezeGfx : FREEZE_GFX_IDS)
        {
            if (graphicId == freezeGfx)
            {
                return true;
            }
        }
        
        return false;
    }


    @Subscribe
    public void onHitsplatApplied(HitsplatApplied event)
    {
        if (!config.enabled())
        {
            return;
        }

        Player localPlayer = Static.invoke(client::getLocalPlayer);
        if (localPlayer == null)
        {
            return;
        }

        // Note: PID detection is now handled by PidDetector
        // This onHitsplatApplied is for damage tracking
        
        // Track damage dealt to opponents
        Actor actor = event.getActor();
        if (actor != null && actor != localPlayer && actor instanceof Player)
        {
            // Check if this is damage we dealt (hitsplat on opponent)
            // Use cached target or current interacting target
            Player target = cachedTarget;
            if (target == null)
            {
                Actor ourTarget = Static.invoke(localPlayer::getInteracting);
                if (ourTarget instanceof Player)
                {
                    target = (Player) ourTarget;
                }
            }
            
            // Check if actor matches our target
            boolean isOurTarget = (target != null && actor == target);
            
            // Also check by name in case Player object reference changed
            if (!isOurTarget && target != null && cachedTargetRSN != null)
            {
                String actorName = Static.invoke(actor::getName);
                if (actorName != null && actorName.equals(cachedTargetRSN))
                {
                    isOurTarget = true;
                }
            }
            
            if (isOurTarget)
            {
                int hitsplatType = event.getHitsplat().getHitsplatType();
                
                // Always try to get damage amount first, regardless of type
                try
                {
                    int damage = event.getHitsplat().getAmount();
                    
                    // Count any hitsplat with damage > 0, regardless of type
                    // Type 16 = DAMAGE_OTHER (standard damage)
                    // Type 12 = BLOCK_ME (0 damage blocks)
                    if (damage > 0)
                    {
                        totalDamageDealt += damage;
                        if (configPanel != null)
                        {
                            configPanel.setTotalDamage(totalDamageDealt);
                        }
                        if (config.damageTrackerLogging())
                        {
                            Logger.norm("[Damage Tracker] ✓ Added " + damage + " damage (Type: " + hitsplatType + ", Total: " + totalDamageDealt + ")");
                        }
                    }
                    else if (damage == 0)
                    {
                        // 0 damage blocks - just log, don't count
                        if (config.debug())
                        {
                            Logger.norm("[Damage Tracker] Blocked hit (0 damage, Type: " + hitsplatType + ") - not adding to total");
                        }
                    }
                    else
                    {
                        Logger.norm("[Damage Tracker] Negative damage? (" + damage + ", Type: " + hitsplatType + ") - ignoring");
                    }
                }
                catch (Exception e)
                {
                    // Log error for debugging
                    Logger.norm("[Damage Tracker] Error getting damage amount: " + e.getMessage() + 
                               " (Type: " + hitsplatType + ", Exception: " + e.getClass().getSimpleName() + ")");
                    // Print stack trace for more details
                    e.printStackTrace();
                }
            }
            else if (config.debug())
            {
                String actorName = actor != null ? Static.invoke(actor::getName) : "null";
                String targetName = target != null ? (cachedTargetRSN != null ? cachedTargetRSN : "null") : "null";
                Logger.norm("[Damage Tracker] Hitsplat ignored - wrong target (Actor: " + actorName + ", Target: " + targetName + ")");
            }
        }
    }

    @Subscribe
    public void onAnimationChanged(AnimationChanged event)
    {
        if (!config.enabled())
        {
            return;
        }

        Actor actor = event.getActor();
        if (actor == null)
        {
            return;
        }

        Player localPlayer = Static.invoke(client::getLocalPlayer);
        
        if (localPlayer == null)
        {
            return;
        }

        int animationId = Static.invoke(actor::getAnimation);
        
        // Debug: Log animation IDs for both player and opponent (only log if not -1 and not 0, common idle animations)
        if (config.debug() && animationId != -1 && animationId != 0)
        {
            String actorName = (actor == localPlayer) ? "Player" : "Opponent";
            Actor interacting = Static.invoke(localPlayer::getInteracting);
            String context = "";
            if (actor == localPlayer)
            {
                context = " (Local Player)";
            }
            else if (interacting != null && interacting == actor)
            {
                context = " (Your Target)";
            }
            else
            {
                context = " (Other Actor)";
            }
            
            AttackTimer detected = detectWeapon(animationId);
            String detectedStr = detected != null ? " -> DETECTED: " + detected.weaponName : " -> NOT DETECTED";
            
            Logger.norm("[AttackTimer] " + actorName + context + " Animation ID: " + animationId + detectedStr);
        }
        
        AttackTimer detectedTimer = detectWeapon(animationId);
        
        // Check if it's the local player
        if (actor == localPlayer)
        {
            // Check for whip attack animations for tank gear equipping
            // Note: PID detection is now handled by PidDetector
            if (animationId == TENTACLE_ATTACK || animationId == TENTACLE_ATTACK_2)
            {
                // After melee attack animation: Equip tank gear (for target frozen state)
                // Only if combat automation is enabled AND varbit 8121 is true
                if (config.combatAutomation() && VarAPI.getVar(8121) == 1)
                {
                    equipGearFromConfig(config.tankGear());
                    if (config.debug())
                    {
                        Logger.norm("[Combat Automation] Detected melee attack animation (" + animationId + ") - equipping tank gear");
                    }
                }
                
                // Notify BothUnfrozenHandler that melee animation was detected
                bothUnfrozenHandler.onMeleeAnimationDetected(config);
                
                // IMPORTANT: Ensure timer is set for melee attacks - check if detectedTimer was set correctly
                if (detectedTimer == null)
                {
                    // detectedTimer should have been set, but if it wasn't, create it now
                    detectedTimer = new AttackTimer("Tentacle", 4);
                    Logger.norm("[AttackTimer] WARNING: detectedTimer was null for melee animation " + animationId + " - created manually");
                }
            }
            else if (animationId != -1 && animationId != 0 && animationId != 65535 && detectedTimer == null)
            {
                // Unknown animation detected (not a recognized attack animation)
                // If we're waiting for melee animation, this might be a non-attack animation (movement, eating, etc.)
                // Clear the melee wait flag to prevent blocking - the actual melee animation might have failed or been interrupted
                // Only clear if this isn't a cast/crossbow animation (those have their own tracking)
                boolean isCastAnimation = false;
                for (int magicAnim : MAGIC_ANIMATIONS)
                {
                    if (animationId == magicAnim)
                    {
                        isCastAnimation = true;
                        break;
                    }
                }
                boolean isCrossbowAnimation = false;
                for (int crossbowAnim : CROSSBOW_ANIMATIONS)
                {
                    if (animationId == crossbowAnim)
                    {
                        isCrossbowAnimation = true;
                        break;
                    }
                }
                
                // If it's not a cast or crossbow animation (which have their own flags), clear melee wait flag
                // This prevents unknown animations from blocking melee attacks
                if (!isCastAnimation && !isCrossbowAnimation && !isIgnoredAnimation(animationId))
                {
                    bothUnfrozenHandler.onMeleeAnimationDetected(config);
                }
            }
            
            // Check for ice barrage cast animation (369, 7855, etc.) for combat automation
            // Only if combat automation is enabled, waiting for cast, AND varbit 8121 is true
            if (config.combatAutomation() && waitingForCastAnimation && VarAPI.getVar(8121) == 1)
            {
                // Increment tick counter
                waitingForCastAnimationTicks++;
                
                // Timeout after 1 tick - animation should happen immediately
                if (waitingForCastAnimationTicks > 1)
                {
                    Logger.norm("[Combat Automation] Timeout after " + waitingForCastAnimationTicks + " ticks - clearing cast animation flag and equipping tank gear");
                    waitingForCastAnimation = false;
                    waitingForCastAnimationTicks = 0;
                    equipGearFromConfig(config.tankGear());
                }
                else if (animationId == 369 || animationId == 7855 || animationId == 7854 || animationId == 7856)
                {
                    waitingForCastAnimation = false;
                    waitingForCastAnimationTicks = 0;
                    
                    // Check if we're in "both frozen" state with distance > 7 - equip only Karil's leathertop instead of full tank gear
                    boolean weFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
                    boolean targetFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);
                    boolean bothFrozen = weFrozen && targetFrozen;
                    
                    if (bothFrozen)
                    {
                        // Calculate distance to target
                        Player target = cachedTarget;
                        if (target == null)
                        {
                            Actor ourTarget = Static.invoke(localPlayer::getInteracting);
                            if (ourTarget instanceof Player)
                            {
                                target = (Player) ourTarget;
                            }
                        }
                        
                        if (target != null)
                        {
                            int distance = getManhattanDistance(localPlayer.getWorldLocation(), target.getWorldLocation());
                            if (distance > 7)
                            {
                                // Distance > 7 and both frozen - equip only Karil's leathertop* (using wildcard)
                                boolean karilEquipped = equipItemByName("Karil's leathertop*");
                                if (config.debug() || config.logHandlerActions())
                                {
                                    Logger.norm("[Combat Automation] Detected ice barrage animation (" + animationId + ") at distance > 7 (" + distance + ") in both frozen state - equipping only Karil's leathertop (result: " + karilEquipped + ")");
                                }
                                return; // Exit early - gear already equipped
                            }
                        }
                    }
                    
                    // Normal case: After animation: Equip tank gear (loadout 1)
                    equipGearFromConfig(config.tankGear());
                    if (config.debug())
                    {
                        Logger.norm("[Combat Automation] Detected ice barrage animation (" + animationId + ") - equipping tank gear (loadout 1)");
                    }
                }
            }
            
            // Check for crossbow/bolt animation for range attack (don't require config.rangeAttack() to still be true)
            if (waitingForCrossbowAnimation)
            {
                // Increment tick counter
                waitingForCrossbowTicks++;
                
                // Timeout after 1 tick - animation should happen immediately
                if (waitingForCrossbowTicks > 1)
                {
                    Logger.norm("[Range Attack] Timeout after " + waitingForCrossbowTicks + " ticks - clearing waiting flag and equipping tank gear");
                    waitingForCrossbowAnimation = false;
                    waitingForCrossbowTicks = 0;
                    equipTankGearAndPrayer();
                }
                else
                {
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Range Attack] Checking animation " + animationId + " against crossbow animations. Waiting flag: " + waitingForCrossbowAnimation + ", ticks: " + waitingForCrossbowTicks);
                    }
                    boolean found = false;
                    for (int crossbowAnim : CROSSBOW_ANIMATIONS)
                    {
                        if (animationId == crossbowAnim)
                        {
                            found = true;
                            waitingForCrossbowAnimation = false;
                            waitingForCrossbowTicks = 0;
                            // After animation: Equip tank gear (and activate Augury via equipTankGearAndPrayer)
                            if (config.combatAutomationLogging())
                            {
                                Logger.norm("[Range Attack] MATCH! Detected crossbow/bolt animation (" + animationId + ") - equipping tank gear and activating Augury");
                            }
                            equipTankGearAndPrayer();
                            break;
                        }
                    }
                    if (!found && animationId != -1 && animationId != 0)
                    {
                        if (config.combatAutomationLogging())
                        {
                            Logger.norm("[Range Attack] Animation " + animationId + " did not match any crossbow animation. Available: " + java.util.Arrays.toString(CROSSBOW_ANIMATIONS));
                        }
                    }
                }
            }
            
            if (detectedTimer != null)
            {
                playerTimer = detectedTimer;
                playerTimerNewThisTick = true;  // Mark as new so it doesn't decrement this tick
                
                // Log timer setting for melee attacks (especially for debugging target frozen we unfrozen state)
                if (detectedTimer.weaponName.equals("Tentacle") || detectedTimer.weaponName.equals("Claws") || detectedTimer.weaponName.equals("AGS") || detectedTimer.weaponName.equals("Staff Bash"))
                {
                    Logger.norm("[AttackTimer] Melee timer set: " + detectedTimer.weaponName + " (" + detectedTimer.ticksRemaining + " ticks) - Animation: " + animationId);
                }
                
                updatePanel();  // Force update immediately
            }
            else
            {
                // Log when we have a local player animation but no timer was detected
                // Skip ignored animations (movement, eating, etc.)
                if (animationId != -1 && animationId != 0 && animationId != 65535 && !isIgnoredAnimation(animationId))
                {
                    Logger.norm("[AttackTimer] WARNING: Local player animation " + animationId + " detected but no timer created (detectedTimer is null)");
                }
            }
            return;
        }
        
        // Check if it's the opponent - either:
        // 1. Actor we're attacking (localPlayer.getInteracting() == actor)
        // 2. Actor attacking us (actor.getInteracting() == localPlayer)
        // 3. Actor is our cached target (cachedTarget == actor) - important for varbit == 1 tracking
        Actor ourTarget = Static.invoke(localPlayer::getInteracting);
        Actor theirTarget = Static.invoke(actor::getInteracting);
        
        boolean isOurTarget = ourTarget != null && ourTarget == actor;
        boolean isAttackingUs = theirTarget != null && theirTarget == localPlayer;
        boolean isCachedTarget = cachedTarget != null && cachedTarget == actor;
        
        if (isOurTarget || isAttackingUs || isCachedTarget)
        {
            // Debug: Track opponent weapon animations if enabled
            if (config.debugOpponentWeapons() && animationId != -1 && animationId != 0)
            {
                boolean isTracked = isAnimationTracked(animationId);
                String detectedType = detectAttackType(animationId);
                String targetName = (actor instanceof Player) ? ((Player) actor).getName() : "Unknown";
                
                if (isTracked)
                {
                    // Animation is already tracked - log which array it's in
                    String arrayName = getArrayNameForAnimation(animationId);
                    Logger.norm("[Opponent Weapons] ✓ Tracked - Animation ID: " + animationId + " (Target: " + targetName + 
                               ", Type: " + detectedType + ", Array: " + arrayName + ")");
                }
                else
                {
                    // Animation is NOT tracked - suggest which array it should be added to
                    String suggestedArray = getSuggestedArrayForAnimation(animationId, detectedType);
                    Logger.norm("[Opponent Weapons] ✗ UNTRACKED - Animation ID: " + animationId + " (Target: " + targetName + 
                               ", Detected Type: " + (detectedType != null ? detectedType : "UNKNOWN") + 
                               ", Suggested Array: " + suggestedArray + ")");
                }
            }
            
            // Set attack timer if we detected a weapon
            if (detectedTimer != null)
            {
                opponentTimer = detectedTimer;
                opponentTimerNewThisTick = true;  // Mark as new so it doesn't decrement this tick
                updatePanel();  // Force update immediately
            }
            
            // Only log opponent attacks that we can identify as actual attack animations
            // DO NOT log unknown animations as they could be movement, eating, etc.
            if (combatLogger != null && actor instanceof Player)
            {
                // Get opponent's RSN (username)
                Player opponentPlayer = (Player) actor;
                String targetRSN = opponentPlayer.getName();
                
                // Fallback: If targetRSN is null but this is our cached target, use cachedTargetRSN
                if (targetRSN == null && isCachedTarget && cachedTargetRSN != null)
                {
                    targetRSN = cachedTargetRSN;
                }
                
                // Determine attack type (returns null for untracked/non-attack animations)
                String attackType = detectAttackType(animationId);
                
                // Only log if we have a valid attack type (melee, ranged, or magic)
                // DO NOT log "unknown" as it could be non-attack animations
                if (targetRSN != null && attackType != null && (attackType.equals("melee") || attackType.equals("ranged") || attackType.equals("magic")))
                {
                    // For melee attacks (whip, claws, etc.), always log if we detected a melee animation
                    // The animation ID itself is proof that it's a melee attack, so we trust the detection
                    // This is especially important for "target frozen we unfrozen" state where distance might be 0
                    if (attackType.equals("melee"))
                    {
                        // Always log melee animations - if we detected it as melee, it's a melee attack
                        // Determine freeze states
                        boolean playerFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
                        boolean opponentFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);
                        
                        // Log the melee attack with target RSN
                        combatLogger.logOpponentAttack(targetRSN, attackType, playerFrozen, opponentFrozen);
                        
                        if (config.debug())
                        {
                            WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                            WorldPoint opponentPos = Static.invoke(opponentPlayer::getWorldLocation);
                            int distance = Math.abs(playerPos.getX() - opponentPos.getX()) + Math.abs(playerPos.getY() - opponentPos.getY());
                            Logger.norm("[CombatLogger] Logged melee attack (animation: " + animationId + ") - distance: " + distance + " tiles");
                        }
                    }
                    else
                    {
                        // For ranged and magic attacks, log normally (no distance validation needed)
                        // Determine freeze states
                        boolean playerFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
                        boolean opponentFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);
                        
                        // Log the attack with target RSN
                        combatLogger.logOpponentAttack(targetRSN, attackType, playerFrozen, opponentFrozen);
                    }
                }
            }
        }
    }

    /**
     * Detect attack type (melee/ranged/magic) from animation ID
     */
    private String detectAttackType(int animationId)
    {
        // Check magic animations
        for (int magicAnim : MAGIC_ANIMATIONS)
        {
            if (animationId == magicAnim)
            {
                return "magic";
            }
        }

        // Check ranged animations (crossbow and bow)
        for (int crossbowAnim : CROSSBOW_ANIMATIONS)
        {
            if (animationId == crossbowAnim)
            {
                return "ranged";
            }
        }
        
        for (int bowAnim : BOW_ANIMATIONS)
        {
            if (animationId == bowAnim)
            {
                return "ranged";
            }
        }

        // Check melee animations (AGS, Claws, Tentacle, Staff Bash)
        for (int agsAnim : AGS_ANIMATIONS)
        {
            if (animationId == agsAnim)
            {
                return "melee";
            }
        }
        
        if (animationId == DRAGON_CLAWS_ATTACK || animationId == DRAGON_CLAWS_SPEC)
        {
            return "melee";
        }
        
        if (animationId == TENTACLE_ATTACK || animationId == TENTACLE_ATTACK_2)
        {
            return "melee";
        }
        
        for (int staffAnim : STAFF_BASH_ANIMATIONS)
        {
            if (animationId == staffAnim)
            {
                return "melee";
            }
        }

        // Default: assume melee if it's an attack animation but not recognized
        // (could be other melee weapons we haven't added yet)
        return null;  // Return null if we can't determine the type
    }

    /**
     * Check if an animation ID is already tracked in any of our arrays
     */
    /**
     * Check if an animation should be ignored (not logged as warning)
     * @param animationId Animation ID to check
     * @return true if animation should be ignored, false otherwise
     */
    private boolean isIgnoredAnimation(int animationId)
    {
        for (int ignored : IGNORED_ANIMATIONS)
        {
            if (animationId == ignored)
            {
                return true;
            }
        }
        return false;
    }
    
    private boolean isAnimationTracked(int animationId)
    {
        // Check all melee arrays
        for (int agsAnim : AGS_ANIMATIONS)
        {
            if (animationId == agsAnim) return true;
        }
        if (animationId == DRAGON_CLAWS_ATTACK || animationId == DRAGON_CLAWS_SPEC) return true;
        if (animationId == TENTACLE_ATTACK || animationId == TENTACLE_ATTACK_2) return true;
        for (int staffAnim : STAFF_BASH_ANIMATIONS)
        {
            if (animationId == staffAnim) return true;
        }
        
        // Check magic arrays
        for (int magicAnim : MAGIC_ANIMATIONS)
        {
            if (animationId == magicAnim) return true;
        }
        
        // Check ranged arrays
        for (int crossbowAnim : CROSSBOW_ANIMATIONS)
        {
            if (animationId == crossbowAnim) return true;
        }
        for (int bowAnim : BOW_ANIMATIONS)
        {
            if (animationId == bowAnim) return true;
        }
        
        return false;
    }

    /**
     * Get the name of the array that contains this animation ID
     */
    private String getArrayNameForAnimation(int animationId)
    {
        // Check all melee arrays
        for (int agsAnim : AGS_ANIMATIONS)
        {
            if (animationId == agsAnim) return "AGS_ANIMATIONS";
        }
        if (animationId == DRAGON_CLAWS_ATTACK || animationId == DRAGON_CLAWS_SPEC) return "DRAGON_CLAWS (constants)";
        if (animationId == TENTACLE_ATTACK || animationId == TENTACLE_ATTACK_2) return "TENTACLE (constants)";
        for (int staffAnim : STAFF_BASH_ANIMATIONS)
        {
            if (animationId == staffAnim) return "STAFF_BASH_ANIMATIONS";
        }
        
        // Check magic arrays
        for (int magicAnim : MAGIC_ANIMATIONS)
        {
            if (animationId == magicAnim) return "MAGIC_ANIMATIONS";
        }
        
        // Check ranged arrays
        for (int crossbowAnim : CROSSBOW_ANIMATIONS)
        {
            if (animationId == crossbowAnim) return "CROSSBOW_ANIMATIONS";
        }
        for (int bowAnim : BOW_ANIMATIONS)
        {
            if (animationId == bowAnim) return "BOW_ANIMATIONS";
        }
        
        return "UNKNOWN";
    }

    /**
     * Suggest which array an animation should be added to based on detected type
     */
    private String getSuggestedArrayForAnimation(int animationId, String detectedType)
    {
        if (detectedType != null)
        {
            switch (detectedType)
            {
                case "melee":
                    // Try to suggest more specific array based on animation pattern
                    if (animationId >= 7000 && animationId < 8000)
                    {
                        return "AGS_ANIMATIONS (if AGS) or DRAGON_CLAWS constants (if claws)";
                    }
                    else if (animationId >= 1600 && animationId < 1700)
                    {
                        return "TENTACLE constants (if whip/tentacle) or new melee array";
                    }
                    else
                    {
                        return "AGS_ANIMATIONS, DRAGON_CLAWS, TENTACLE constants, or STAFF_BASH_ANIMATIONS (check weapon type)";
                    }
                case "magic":
                    return "MAGIC_ANIMATIONS";
                case "ranged":
                    // Could be crossbow or bow
                    if (animationId >= 7600 && animationId < 7700)
                    {
                        return "CROSSBOW_ANIMATIONS or BOW_ANIMATIONS (check weapon type)";
                    }
                    else if (animationId >= 9100 && animationId < 9200)
                    {
                        return "CROSSBOW_ANIMATIONS";
                    }
                    else
                    {
                        return "CROSSBOW_ANIMATIONS or BOW_ANIMATIONS (check weapon type)";
                    }
                default:
                    return "UNKNOWN TYPE - manually inspect animation to determine category";
            }
        }
        else
        {
            // No type detected - try to infer from animation ID ranges
            if (animationId >= 7000 && animationId < 8000)
            {
                return "Possibly AGS_ANIMATIONS or DRAGON_CLAWS (melee) - manually check";
            }
            else if (animationId >= 7500 && animationId < 8000)
            {
                return "Possibly MAGIC_ANIMATIONS or CROSSBOW_ANIMATIONS - manually check";
            }
            else if (animationId >= 1600 && animationId < 1700)
            {
                return "Possibly TENTACLE constants (melee) - manually check";
            }
            else
            {
                return "UNKNOWN - manually inspect animation to determine category (melee/magic/ranged)";
            }
        }
    }

    private AttackTimer detectWeapon(int animationId)
    {
        // Armadyl Godsword - 6 ticks
        for (int agsAnim : AGS_ANIMATIONS)
        {
            if (animationId == agsAnim)
            {
                return new AttackTimer("AGS", 6);
            }
        }
        
        // Dragon Claws - 4 ticks
        if (animationId == DRAGON_CLAWS_ATTACK || animationId == DRAGON_CLAWS_SPEC)
        {
            return new AttackTimer("Claws", 4);
        }
        
        // Abyssal Tentacle - 4 ticks
        if (animationId == TENTACLE_ATTACK || animationId == TENTACLE_ATTACK_2)
        {
            return new AttackTimer("Tentacle", 4);
        }
        
        // Staff bash / melee - 4 ticks
        for (int staffAnim : STAFF_BASH_ANIMATIONS)
        {
            if (animationId == staffAnim)
            {
                return new AttackTimer("Staff Bash", 4);
            }
        }
        
        // Magic attacks (Ice Barrage, Ice Blitz, etc.) - 5 ticks
        for (int magicAnim : MAGIC_ANIMATIONS)
        {
            if (animationId == magicAnim)
            {
                return new AttackTimer("Magic", 5);
            }
        }
        
        // Range attacks - Crossbow - 5 ticks
        for (int crossbowAnim : CROSSBOW_ANIMATIONS)
        {
            if (animationId == crossbowAnim)
            {
                return new AttackTimer("Range", 5);
            }
        }
        
        // Range attacks - Bow - 5 ticks
        for (int bowAnim : BOW_ANIMATIONS)
        {
            if (animationId == bowAnim)
            {
                return new AttackTimer("Range", 5);
            }
        }

        return null;
    }

    /**
     * Calculate Manhattan distance between two WorldPoints
     */
    private int getManhattanDistance(WorldPoint p1, WorldPoint p2)
    {
        if (p1.getPlane() != p2.getPlane())
        {
            return Integer.MAX_VALUE;
        }
        return Math.abs(p1.getX() - p2.getX()) + Math.abs(p1.getY() - p2.getY());
    }
    
    /**
     * Find the nearest player (for combat automation)
     */
    private Player findNearestPlayer(Player localPlayer)
    {
        WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
        Player nearestPlayer = null;
        int nearestDistance = Integer.MAX_VALUE;
        
        // Find nearest player (excluding local player)
        List<PlayerEx> players = GameManager.playerList();
        for (PlayerEx pEx : players)
        {
            if (pEx == null) continue;
            Player p = pEx.getPlayer();
            if (p == null || p == localPlayer)
            {
                continue;
            }
            
            WorldPoint pPos = Static.invoke(p::getWorldLocation);
            int distance = getManhattanDistance(playerPos, pPos);
            
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                nearestPlayer = p;
            }
        }
        
        return nearestPlayer;
    }
    
    /**
     * Find the nearest player and cache their data for AI Prayers
     */
    private void findAndCacheNearestPlayer(Player localPlayer)
    {
        if (combatLogger == null)
        {
            combatLogger = new CombatLogger(config);
        }
        
        WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
        Player nearestPlayer = null;
        int nearestDistance = Integer.MAX_VALUE;
        
        // Find nearest player (excluding local player)
        List<PlayerEx> players = GameManager.playerList();
        for (PlayerEx pEx : players)
        {
            if (pEx == null) continue;
            Player p = pEx.getPlayer();
            if (p == null || p == localPlayer)
            {
                continue;
            }
            
            WorldPoint pPos = Static.invoke(p::getWorldLocation);
            int distance = getManhattanDistance(playerPos, pPos);
            
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                nearestPlayer = p;
            }
        }
        
        // This method is no longer needed - target caching is handled in main onGameTick
        // Keeping method signature for compatibility but it does nothing
        if (config.debug())
        {
            Logger.norm("[AI Prayers] findAndCacheNearestPlayer called but target is now managed in main target system");
        }
    }
    
    /**
     * Calculate and update AI Prayers display data for the infobox
     */
    private void updateAIPrayersDisplayData(Player localPlayer)
    {
        if (!config.aiPrayers())
        {
            aiPrayersData = null;
            return;
        }
        
        // Determine if we're in guessing mode (timer null or 0) or predicting mode (timer == 1)
        boolean isGuessing = (opponentTimer == null || opponentTimer.ticksRemaining == 0);
        
        // Initialize display data
        aiPrayersData = new AIPrayersDisplayData();
        aiPrayersData.modus = isGuessing ? "guessing" : "predicting";
        
        // Get target - use cached target (only exists when varbit 8121 == 1)
        Player opponent = cachedTarget;
        if (opponent == null)
        {
            Actor ourTarget = Static.invoke(localPlayer::getInteracting);
            if (ourTarget == null || !(ourTarget instanceof Player))
            {
                // No target - set to default values
                aiPrayersData.targetFrozen = false;
                aiPrayersData.weFrozen = false;
                aiPrayersData.canMelee = false;
                aiPrayersData.rangedPercent = 33.3;
                aiPrayersData.meleePercent = 33.3;
                aiPrayersData.magicPercent = 33.3;
                return;
            }
            opponent = (Player) ourTarget;
        }
        
        // Determine freeze states
        boolean playerFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
        boolean opponentFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);
        
        aiPrayersData.targetFrozen = opponentFrozen;
        aiPrayersData.weFrozen = playerFrozen;
        
        // Get combat log data - use cached data if available
        String targetRSN = cachedTargetRSN != null ? cachedTargetRSN : Static.invoke(opponent::getName);
        CombatLogData logData = cachedCombatData;
        
        // If no cached data, try to load it
        if (logData == null && targetRSN != null && !targetRSN.trim().isEmpty())
        {
            if (combatLogger == null)
            {
                combatLogger = new CombatLogger(config);
            }
            logData = combatLogger.getLogDataForTarget(targetRSN);
            // Cache it for future use
            if (logData != null && cachedTargetRSN != null)
            {
                cachedCombatData = logData;
            }
        }
        
        // Get the appropriate attack stats based on freeze states
        CombatAttackStats stats = null;
        String category = "";
        
        if (logData != null)
        {
            if (playerFrozen && opponentFrozen)
            {
                stats = logData.getBothFrozen();
                category = "bothFrozen";
            }
            else if (!playerFrozen && !opponentFrozen)
            {
                stats = logData.getBothUnfrozen();
                category = "bothUnfrozen";
            }
            else if (!playerFrozen && opponentFrozen)
            {
                stats = logData.getTargetFrozenWeUnfrozen();
                category = "targetFrozenWeUnfrozen";
            }
            else if (playerFrozen && !opponentFrozen)
            {
                stats = logData.getWeFrozenTargetUnfrozen();
                category = "weFrozenTargetUnfrozen";
            }
        }
        
        // Calculate Manhattan distance
        WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
        WorldPoint opponentPos = Static.invoke(opponent::getWorldLocation);
        int distance = getManhattanDistance(playerPos, opponentPos);
        
        // Calculate if opponent is diagonal
        int dx = Math.abs(playerPos.getX() - opponentPos.getX());
        int dy = Math.abs(playerPos.getY() - opponentPos.getY());
        boolean isDiagonal = (dx > 0 && dy > 0);
        
        // Determine if melee is allowed based on freeze states and distance
        boolean meleeAllowed = false;
        
        if (playerFrozen && opponentFrozen)
        {
            // bothFrozen: Only melee if target is 1 tile away and not diagonal
            meleeAllowed = (distance == 1 && !isDiagonal);
        }
        else if (!playerFrozen && !opponentFrozen)
        {
            // bothUnfrozen: Only melee if target is closer than 4 tiles
            meleeAllowed = (distance < 4);
        }
        else if (!playerFrozen && opponentFrozen)
        {
            // targetFrozenWeUnfrozen: Every prayer is allowed
            meleeAllowed = true;
        }
        else if (playerFrozen && !opponentFrozen)
        {
            // weFrozenTargetUnfrozen: Only melee if target is closer than 4 tiles
            meleeAllowed = (distance < 4);
        }
        
        aiPrayersData.canMelee = meleeAllowed;
        
        // Calculate percentages based on combat data (always use data if available)
        if (stats != null)
        {
            // Use actual data from combat log
            int meleeCount = meleeAllowed ? stats.getMelee() : 0;
            int rangedCount = stats.getRanged();
            int magicCount = stats.getMagic();
            
            int totalWeight = meleeCount + rangedCount + magicCount;
            
            if (totalWeight > 0)
            {
                // Calculate percentages from actual data
                aiPrayersData.meleePercent = (meleeCount * 100.0 / totalWeight);
                aiPrayersData.rangedPercent = (rangedCount * 100.0 / totalWeight);
                aiPrayersData.magicPercent = (magicCount * 100.0 / totalWeight);
            }
            else
            {
                // No data in this category - use equal percentages
                aiPrayersData.meleePercent = meleeAllowed ? 33.3 : 0;
                aiPrayersData.rangedPercent = meleeAllowed ? 33.3 : 50.0;
                aiPrayersData.magicPercent = meleeAllowed ? 33.3 : 50.0;
            }
        }
        else
        {
            // No combat data for this target/category - use equal percentages
            aiPrayersData.meleePercent = meleeAllowed ? 33.3 : 0;
            aiPrayersData.rangedPercent = meleeAllowed ? 33.3 : 50.0;
            aiPrayersData.magicPercent = meleeAllowed ? 33.3 : 50.0;
        }
    }

    /**
     * AI Prayers: Select and activate prayer based on opponent attack patterns and freeze states
     */
    private void handleAIPrayers(Player localPlayer)
    {
        if (combatLogger == null)
        {
            combatLogger = new CombatLogger(config);
        }

        // Get target - use cached target if available, otherwise use interacting target
        Player opponent = cachedTarget;
        if (opponent == null)
        {
            Actor ourTarget = Static.invoke(localPlayer::getInteracting);
            if (ourTarget == null || !(ourTarget instanceof Player))
            {
                // No target - pray random
                selectRandomPrayer();
                return;
            }
            opponent = (Player) ourTarget;
        }
        
        // Get target RSN - use cached RSN if available
        String targetRSN = cachedTargetRSN != null ? cachedTargetRSN : Static.invoke(opponent::getName);
        if (targetRSN == null || targetRSN.trim().isEmpty())
        {
            // No target RSN - pray random
            selectRandomPrayer();
            return;
        }

        // Get combat log data for this target - use cached data if available
        CombatLogData logData = cachedCombatData;
        if (logData == null)
        {
            logData = combatLogger.getLogDataForTarget(targetRSN);
            // Cache it for future use
            if (logData != null && cachedTargetRSN != null)
            {
                cachedCombatData = logData;
            }
        }
        
        // Determine freeze states
        boolean playerFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
        boolean opponentFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);

        // Get the appropriate attack stats based on freeze states
        CombatAttackStats stats = null;
        String category = "";
        
        if (logData != null)
        {
            if (playerFrozen && opponentFrozen)
            {
                stats = logData.getBothFrozen();
                category = "bothFrozen";
            }
            else if (!playerFrozen && !opponentFrozen)
            {
                stats = logData.getBothUnfrozen();
                category = "bothUnfrozen";
            }
            else if (!playerFrozen && opponentFrozen)
            {
                stats = logData.getTargetFrozenWeUnfrozen();
                category = "targetFrozenWeUnfrozen";
            }
            else if (playerFrozen && !opponentFrozen)
            {
                stats = logData.getWeFrozenTargetUnfrozen();
                category = "weFrozenTargetUnfrozen";
            }
        }

        // If no data or no stats in category, pray random
        if (stats == null)
        {
            Logger.norm("[AI Prayers] No combat data for target: " + targetRSN + " - praying random");
            selectRandomPrayer();
            return;
        }

        // Check if we have any data in this category
        int totalAttacks = stats.getMelee() + stats.getRanged() + stats.getMagic();
        if (totalAttacks == 0)
        {
            // No data in this category - pray random
            Logger.norm("[AI Prayers] No attack data in category: " + category + " - praying random");
            selectRandomPrayer();
            return;
        }

        // Calculate Manhattan distance between player and opponent
        WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
        WorldPoint opponentPos = Static.invoke(opponent::getWorldLocation);
        int distance = getManhattanDistance(playerPos, opponentPos);
        
        // Calculate if opponent is diagonal (both X and Y differences are non-zero)
        int dx = Math.abs(playerPos.getX() - opponentPos.getX());
        int dy = Math.abs(playerPos.getY() - opponentPos.getY());
        boolean isDiagonal = (dx > 0 && dy > 0);

        // Determine which prayers are allowed based on rules
        boolean meleeAllowed = false;
        
        if (category.equals("bothFrozen"))
        {
            // Only melee if target is 1 tile away and not diagonal
            meleeAllowed = (distance == 1 && !isDiagonal);
        }
        else if (category.equals("bothUnfrozen"))
        {
            // Only melee if target is closer than 4 tiles
            meleeAllowed = (distance < 4);
        }
        else if (category.equals("targetFrozenWeUnfrozen"))
        {
            // Every prayer is allowed
            meleeAllowed = true;
        }
        else if (category.equals("weFrozenTargetUnfrozen"))
        {
            // Only melee if target is closer than 4 tiles
            meleeAllowed = (distance < 4);
        }

        // Advanced logic: Check if target can melee us
        boolean targetCanMelee = false;
        
        // Condition 1: Target unfrozen AND within 4 tiles
        if (!opponentFrozen && distance < 4)
        {
            targetCanMelee = true;
        }
        // Condition 2: Both frozen AND distance < 2 tiles AND not diagonal
        else if (playerFrozen && opponentFrozen && distance < 2 && !isDiagonal)
        {
            targetCanMelee = true;
        }
        // Condition 3: Both unfrozen AND within 4 tiles
        else if (!playerFrozen && !opponentFrozen && distance < 4)
        {
            targetCanMelee = true;
        }
        
        // Check target spec percentage
        int targetSpecPercent = -1;
        if (targetSpec != null)
        {
            targetSpecPercent = targetSpec.getTargetSpecPercent();
        }
        boolean specBonusActive = (targetSpecPercent >= 50 && targetSpecPercent <= 90);
        
        // Apply advanced logic: override meleeAllowed if target can melee us
        if (targetCanMelee)
        {
            if (!meleeAllowed)
            {
                meleeAllowed = true;
                if (config.debug())
                {
                    Logger.norm("[AI Prayers] Overriding melee restriction - target can melee us");
                }
            }
        }
        
        // Build weighted list of prayers (excluding melee if not allowed)
        int meleeCount = meleeAllowed ? stats.getMelee() : 0;
        int rangedCount = stats.getRanged();
        int magicCount = stats.getMagic();
        
        int totalWeight = meleeCount + rangedCount + magicCount;
        
        if (totalWeight == 0)
        {
            // No valid prayers - pray random
            Logger.norm("[AI Prayers] No valid prayers (melee not allowed), praying random");
            selectRandomPrayer();
            return;
        }

        // Apply bonuses to melee probability
        // Convert percentage bonuses to weight bonuses
        // If totalWeight represents 100%, then 35% bonus = add 0.35 * totalWeight to melee
        int meleeBonus = 0;
        if (targetCanMelee)
        {
            // Add 35% bonus (0.35 of total weight)
            meleeBonus += (int)(totalWeight * 0.35);
            if (config.debug())
            {
                Logger.norm("[AI Prayers] Target can melee - adding 35% bonus to protect melee");
            }
        }
        if (specBonusActive)
        {
            // Add 15% bonus (0.15 of total weight)
            meleeBonus += (int)(totalWeight * 0.15);
            if (config.debug())
            {
                Logger.norm("[AI Prayers] Target spec " + targetSpecPercent + "% (50-90%) - adding 15% bonus to protect melee");
            }
        }
        
        // Apply bonus to melee count
        if (meleeBonus > 0)
        {
            meleeCount += meleeBonus;
            totalWeight += meleeBonus; // Update total weight
        }

        // Weighted random selection based on percentages
        // Example: melee=5, ranged=2, magic=1 means:
        // melee: 5/8 = 62.5%, ranged: 2/8 = 25%, magic: 1/8 = 12.5%
        int roll = random.nextInt(totalWeight);
        PrayerAPI selectedPrayer = null;
        
        if (roll < meleeCount)
        {
            selectedPrayer = PrayerAPI.PROTECT_FROM_MELEE;
        }
        else if (roll < meleeCount + rangedCount)
        {
            selectedPrayer = PrayerAPI.PROTECT_FROM_MISSILES;
        }
        else
        {
            selectedPrayer = PrayerAPI.PROTECT_FROM_MAGIC;
        }

        // Activate the selected prayer (turnOn() already checks if it's active and won't click again)
        if (selectedPrayer != null)
        {
            selectedPrayer.turnOn();
            
            double meleePercent = totalWeight > 0 ? (meleeCount * 100.0 / totalWeight) : 0;
            double rangedPercent = totalWeight > 0 ? (rangedCount * 100.0 / totalWeight) : 0;
            double magicPercent = totalWeight > 0 ? (magicCount * 100.0 / totalWeight) : 0;
            
            // Build bonus info string
            StringBuilder bonusInfo = new StringBuilder();
            if (targetCanMelee)
            {
                bonusInfo.append(" [Melee Bonus: +35%]");
            }
            if (specBonusActive)
            {
                bonusInfo.append(" [Spec Bonus: +15% (").append(targetSpecPercent).append("%)]");
            }
            
            if (config.aiPrayersLogging())
            {
                Logger.norm("[AI Prayers] Activated " + selectedPrayer.name() + " for " + targetRSN + 
                           " (Category: " + category + ", Distance: " + distance + 
                           ", Stats: M=" + stats.getMelee() + "(" + String.format("%.1f", meleePercent) + "%)" +
                           " R=" + stats.getRanged() + "(" + String.format("%.1f", rangedPercent) + "%)" +
                           " Ma=" + stats.getMagic() + "(" + String.format("%.1f", magicPercent) + "%)" +
                           bonusInfo.toString() + ")");
            }
        }
    }

    /**
     * Convert PidDetector.PidStatus to CombatStateContext.PidStatus
     */
    private CombatStateContext.PidStatus convertPidStatus(PidDetector.PidStatus detectorStatus)
    {
        if (detectorStatus == PidDetector.PidStatus.ON_PID)
        {
            return CombatStateContext.PidStatus.ON_PID;
        }
        else if (detectorStatus == PidDetector.PidStatus.OFF_PID)
        {
            return CombatStateContext.PidStatus.OFF_PID;
        }
        else
        {
            return CombatStateContext.PidStatus.UNKNOWN;
        }
    }
    
    /**
     * Select a random prayer (for when there's no data)
     */
    private void selectRandomPrayer()
    {
        PrayerAPI[] prayers = {
            PrayerAPI.PROTECT_FROM_MELEE,
            PrayerAPI.PROTECT_FROM_MISSILES,
            PrayerAPI.PROTECT_FROM_MAGIC
        };
        
        PrayerAPI randomPrayer = prayers[random.nextInt(prayers.length)];
        randomPrayer.turnOn();
        
        Logger.norm("[AI Prayers] Selected random prayer: " + randomPrayer.name());
    }

    /**
     * Update the config panel with current combat information
     * Overlay removed - only using panel now
     */
    private void updatePanel()
    {
        if (!config.enabled() || configPanel == null)
        {
            return;
        }
        
        updatePanelInfo(configPanel);
    }
    
    /**
     * Update the config panel with current combat information
     */
    public void updatePanelInfo(AttackTimerConfigPanel panel)
    {
        if (panel == null || !config.enabled())
        {
            return;
        }
        
        // Target username - same logic as overlay
        Player localPlayer = Static.invoke(client::getLocalPlayer);
        String targetName = "None";
        Color targetColor = Color.GRAY;
        
        if (localPlayer != null)
        {
            WorldPoint playerLoc = localPlayer.getWorldLocation();
            int regionId = ((playerLoc.getX() >> 6) << 8) | (playerLoc.getY() >> 6);
            if (cachedTargetRSN != null && !cachedTargetRSN.isEmpty())
            {
                targetName = cachedTargetRSN;
                targetColor = Color.YELLOW;
            }
            else
            {
                Actor target = Static.invoke(localPlayer::getInteracting);
                if (target instanceof Player)
                {
                    targetName = Static.invoke(target::getName);
                    if (targetName != null && !targetName.isEmpty())
                    {
                        targetColor = Color.YELLOW;
                    }
                    else
                    {
                        targetName = "Unknown";
                    }
                }
            }
        }
        panel.setTargetName(targetName, targetColor);
        
        // Player attack timer
        if (playerTimer != null)
        {
            String playerText = playerTimer.weaponName + " (" + playerTimer.ticksRemaining + ")";
            Color playerColor = playerTimer.ticksRemaining <= 1 ? Color.RED : Color.GREEN;
            panel.setPlayerTimer(playerText, playerColor);
        }
        else
        {
            panel.setPlayerTimer("---", Color.GRAY);
        }
        
        // Opponent attack timer
        if (opponentTimer != null)
        {
            String opponentText = opponentTimer.weaponName + " (" + opponentTimer.ticksRemaining + ")";
            Color opponentColor = opponentTimer.ticksRemaining <= 1 ? Color.RED : Color.YELLOW;
            panel.setOpponentTimer(opponentText, opponentColor);
        }
        else
        {
            panel.setOpponentTimer("---", Color.GRAY);
        }
        
        // Player freeze timer
        if (playerFreezeTimer != null && playerFreezeTimer.isActive())
        {
            String statusText = playerFreezeTimer.state == FreezeState.FROZEN ? "Frozen" : "Immune";
            String playerFreezeText = statusText + " (" + playerFreezeTimer.ticksRemaining + ")";
            Color playerFreezeColor = playerFreezeTimer.state == FreezeState.FROZEN ? Color.CYAN : Color.ORANGE;
            panel.setPlayerFreeze(playerFreezeText, playerFreezeColor);
        }
        else
        {
            panel.hidePlayerFreeze();
        }
        
        // Opponent freeze timer
        if (opponentFreezeTimer != null && opponentFreezeTimer.isActive())
        {
            String statusText = opponentFreezeTimer.state == FreezeState.FROZEN ? "Frozen" : "Immune";
            String opponentFreezeText = statusText + " (" + opponentFreezeTimer.ticksRemaining + ")";
            Color opponentFreezeColor = opponentFreezeTimer.state == FreezeState.FROZEN ? Color.CYAN : Color.ORANGE;
            panel.setOpponentFreeze(opponentFreezeText, opponentFreezeColor);
        }
        else
        {
            panel.hideOpponentFreeze();
        }
        
        // PID Status
        String pidText = "Unknown";
        Color pidColor = Color.YELLOW;
        if (pidDetector != null)
        {
            PidDetector.PidStatus detectorStatus = pidDetector.getCurrentPidStatus();
            switch (detectorStatus)
            {
                case ON_PID:
                    pidText = "ON";
                    pidColor = Color.GREEN;
                    break;
                case OFF_PID:
                    pidText = "OFF";
                    pidColor = Color.RED;
                    break;
                case UNKNOWN:
                    pidText = "Unknown";
                    pidColor = Color.YELLOW;
                    break;
            }
        }
        panel.setPidStatus(pidText, pidColor);
        
        // Target Spec
        if (targetSpec != null)
        {
            int specPercent = targetSpec.getTargetSpecPercent();
            String specText = specPercent + "%";
            Color specColor;
            if (specPercent >= 100)
            {
                specColor = Color.RED;
            }
            else if (specPercent >= 50)
            {
                specColor = Color.ORANGE;
            }
            else if (specPercent > 0)
            {
                specColor = Color.YELLOW;
            }
            else
            {
                specColor = Color.GREEN;
            }
            panel.setTargetSpec(specText, specColor);
        }
        else
        {
            panel.setTargetSpec("---", Color.GRAY);
        }
        
        // Distance to target (Euclidean distance)
        int distance = -1;
        if (localPlayer != null)
        {
            Player target = cachedTarget;
            if (target == null)
            {
                Actor interacting = Static.invoke(localPlayer::getInteracting);
                if (interacting instanceof Player)
                {
                    target = (Player) interacting;
                }
            }
            
            if (target != null)
            {
                WorldPoint playerPos = localPlayer.getWorldLocation();
                WorldPoint targetPos = target.getWorldLocation();
                
                // Calculate Euclidean distance: sqrt((x1-x2)^2 + (y1-y2)^2)
                if (playerPos.getPlane() == targetPos.getPlane())
                {
                    int dx = playerPos.getX() - targetPos.getX();
                    int dy = playerPos.getY() - targetPos.getY();
                    double distanceDouble = Math.sqrt(dx * dx + dy * dy);
                    distance = (int) Math.round(distanceDouble);
                }
            }
        }
        panel.setDistance(distance);
        
        // AI Prayers infobox
        if (config.aiPrayers() && aiPrayersData != null)
        {
            panel.setAIPrayersVisible(true);
            panel.setTargetFrozen(aiPrayersData.targetFrozen);
            panel.setWeFrozen(aiPrayersData.weFrozen);
            panel.setCanMelee(aiPrayersData.canMelee);
            panel.setModus(aiPrayersData.modus);
            panel.setRangedPercent(aiPrayersData.rangedPercent);
            panel.setMeleePercent(aiPrayersData.meleePercent);
            panel.setMagicPercent(aiPrayersData.magicPercent);
        }
        else
        {
            panel.setAIPrayersVisible(false);
        }
        
                 // Spec Modus info
         panel.setSpecModusTimer(ticksSinceGameStart);
         panel.setSpecModusStatus(specDumpModeActive);
         
         // Damage tracker info
         panel.setTotalDamage(totalDamageDealt);
     }

    /**
     * Handle combat automation using state-based handlers
     */
    private void handleCombatAutomation(Player localPlayer)
    {
        // Get our target - prioritize cached target if in arena
        Player opponent = null;
        WorldPoint playerLoc = localPlayer.getWorldLocation();
        int regionId = ((playerLoc.getX() >> 6) << 8) | (playerLoc.getY() >> 6);
        boolean inArenaCheck = (regionId == 13363 || regionId == 13362);
        
        // Use cached target (only exists when varbit 8121 == 1)
        if (cachedTarget != null)
        {
            opponent = cachedTarget;
        }
        else
        {
            // Fallback: Check current interacting target
            Actor target = Static.invoke(localPlayer::getInteracting);
            if (target instanceof Player)
            {
                opponent = (Player) target;
            }
        }
        
        if (opponent == null)
        {
            if (config.debug())
            {
                Logger.norm("[Combat Automation] No target found");
            }
            return;
        }
        
        // Determine freeze states
        boolean weFrozen = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN);
        boolean targetFrozen = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN);
        
        // Get timer ticks (-1 if null)
        int playerTimerTicks = (playerTimer != null) ? playerTimer.ticksRemaining : -1;
        int opponentTimerTicks = (opponentTimer != null) ? opponentTimer.ticksRemaining : -1;
        
        // Get freeze timer ticks (-1 if not frozen)
        int playerFreezeTimerTicks = (playerFreezeTimer != null && playerFreezeTimer.state == FreezeState.FROZEN) ? playerFreezeTimer.ticksRemaining : -1;
        int opponentFreezeTimerTicks = (opponentFreezeTimer != null && opponentFreezeTimer.state == FreezeState.FROZEN) ? opponentFreezeTimer.ticksRemaining : -1;
        
        // Spec Dump Mode: Takes priority over all handlers when unfrozen
        if (specDumpModeActive && !weFrozen)
        {
            // Check attack timer and execute spec dump sequence
            int attackTimerTicks = playerTimerTicks < 0 ? 0 : playerTimerTicks;
            
            if (attackTimerTicks == 4 || attackTimerTicks == 3 || attackTimerTicks == 2)
            {
                // Click under target at timer 4, 3, and 2
                clickUnderTarget(opponent);
                if (config.combatAutomationLogging())
                {
                    Logger.norm("[Spec Dump] Timer " + attackTimerTicks + " - clicking under target");
                }
                return; // Exit early - spec dump mode handled this tick
            }
            else if (attackTimerTicks == 1)
            {
                // Execute special attack at timer 1
                boolean specExecuted = AttackMethods.executeSpecialAttack(
                    new CombatStateContext(
                        config, localPlayer, opponent, playerTimerTicks, opponentTimerTicks,
                        weFrozen, targetFrozen, playerFreezeTimerTicks, opponentFreezeTimerTicks,
                        CombatStateContext.PidStatus.UNKNOWN,
                        new CombatStateContext.MutableBoolean(waitingForCastAnimation),
                        new CombatStateContext.MutableBoolean(waitingForCastXP),
                        new CombatStateContext.MutableBoolean(waitingForCrossbowAnimation),
                        new CombatStateContext.MutableInt(waitingForCrossbowTicks),
                        new CombatStateContext.MutableInt(lastEquipTick),
                        new CombatStateContext.HelperMethods() {
                            @Override public void equipGearFromConfig(String gearConfig) { AttackTimerPlugin.this.equipGearFromConfig(gearConfig, null); }
                            @Override public void equipGearFromConfig(String gearConfig, PrayerAPI prayer) { AttackTimerPlugin.this.equipGearFromConfig(gearConfig, prayer); }
                            @Override public void castIceBarrage(Player target) { AttackTimerPlugin.this.castIceBarrage(target); }
                            @Override public boolean castBloodSpell(Player target) { return AttackTimerPlugin.this.castBloodSpell(target); }
                            @Override public void attackPlayerWithFightOption(Player target) { AttackTimerPlugin.this.attackPlayerWithFightOption(target); }
                            @Override public void clickUnderTarget(Player target) { AttackTimerPlugin.this.clickUnderTarget(target); }
                            @Override public int getPlayerHealth() { return SkillAPI.getBoostedLevel(Skill.HITPOINTS); }
                            @Override public int getPlayerMagicLevel() { return SkillAPI.getBoostedLevel(Skill.MAGIC); }
                            @Override public int getPlayerRangeLevel() { return SkillAPI.getBoostedLevel(Skill.RANGED); }
                            @Override public int getPlayerStrengthLevel() { return SkillAPI.getBoostedLevel(Skill.STRENGTH); }
                            @Override public int getPlayerPrayerPoints() { return SkillAPI.getBoostedLevel(Skill.PRAYER); }
                            @Override public boolean hasBrews() { return InventoryAPI.count("Saradomin brew(4)", "Saradomin brew(3)", "Saradomin brew(2)", "Saradomin brew(1)") > 0; }
                            @Override public boolean eatAngler() { return false; }
                            @Override public boolean sipSaradominBrew() { return false; }
                            @Override public boolean drinkSanfewSerum() { return false; }
                            @Override public boolean drinkBastion() { return false; }
                            @Override public boolean drinkSuperCombat() { return false; }
                            @Override public boolean equipItemByName(String itemName) { return false; }
                            @Override public boolean isUnderTarget(Player target) { return false; }
                            @Override public void walkAwayFromTarget(Player target, int maxTiles) {
                                WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                                WorldPoint targetPos = Static.invoke(target::getWorldLocation);
                                int dx = playerPos.getX() - targetPos.getX();
                                int dy = playerPos.getY() - targetPos.getY();
                                // Normalize and scale by maxTiles
                                double distance = Math.sqrt(dx*dx + dy*dy);
                                if (distance > 0) {
                                    int moveX = (int)((dx / distance) * maxTiles);
                                    int moveY = (int)((dy / distance) * maxTiles);
                                    WorldPoint walkTo = new WorldPoint(playerPos.getX() + moveX, playerPos.getY() + moveY, playerPos.getPlane());
                                    MovementAPI.walkToWorldPoint(walkTo);
                                }
                            }
                            @Override public boolean isTargetDead(Player target) {
                                return Static.invoke(() -> target == null || target.isDead());
                            }
                            @Override public boolean castBloodBlitz(Player target) { return false; }
                            @Override public boolean castBloodBarrage(Player target) { return false; }
                            @Override public int getEatCooldownTicks() { return 0; }
                            @Override public int getTargetHPPercentage(Player target) { return 100; }
                            @Override public void setMindAction(String action) { }
                        }
                    ),
                    opponent,
                    "[Spec Dump]"
                );
                
                // Turn off spec dump mode immediately after executing (or attempting) a special attack
                // It will reactivate automatically if late-game conditions are met (low food + spec >= 50%)
                specDumpModeActive = false;
                
                if (specExecuted)
                {
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Spec Dump] Timer 1 - special attack executed, turning off spec dump mode (will reactivate if low food + spec >= 50%)");
                    }
                }
                else
                {
                    if (config.combatAutomationLogging())
                    {
                        Logger.norm("[Spec Dump] Timer 1 - special attack failed, turning off spec dump mode");
                    }
                }
                return; // Exit early - spec dump mode handled this tick
            }
            // If timer is not 4/3/2/1, do nothing (wait for timer to reach these values)
        }
        
        // Get PID status from detector
        CombatStateContext.PidStatus pidStatus;
        if (pidDetector != null)
        {
            PidDetector.PidStatus detectorStatus = pidDetector.getCurrentPidStatus();
            pidStatus = convertPidStatus(detectorStatus);
        }
        else
        {
            pidStatus = CombatStateContext.PidStatus.UNKNOWN;
        }
        
        if (config.debug())
        {
            Logger.norm("[Combat Automation] WeFrozen: " + weFrozen + ", TargetFrozen: " + targetFrozen + ", PID: " + pidStatus);
        }
        
        // Create mutable wrappers for waiting flags
        CombatStateContext.MutableBoolean mutableWaitingCastAnim = new CombatStateContext.MutableBoolean(waitingForCastAnimation);
        CombatStateContext.MutableBoolean mutableWaitingCastXP = new CombatStateContext.MutableBoolean(waitingForCastXP);
        CombatStateContext.MutableBoolean mutableWaitingCrossbow = new CombatStateContext.MutableBoolean(waitingForCrossbowAnimation);
        CombatStateContext.MutableInt mutableWaitingCrossbowTicks = new CombatStateContext.MutableInt(waitingForCrossbowTicks);
        CombatStateContext.MutableInt mutableLastEquipTick = new CombatStateContext.MutableInt(lastEquipTick);
        
        // Create helper methods implementation
        CombatStateContext.HelperMethods helpers = new CombatStateContext.HelperMethods()
        {
            @Override
            public void equipGearFromConfig(String gearConfig)
            {
                AttackTimerPlugin.this.equipGearFromConfig(gearConfig, null);
            }
            
            @Override
            public void equipGearFromConfig(String gearConfig, PrayerAPI prayer)
            {
                AttackTimerPlugin.this.equipGearFromConfig(gearConfig, prayer);
            }
            
            @Override
            public void castIceBarrage(Player target)
            {
                AttackTimerPlugin.this.castIceBarrage(target);
            }
            
            @Override
            public boolean castBloodSpell(Player target)
            {
                return AttackTimerPlugin.this.castBloodSpell(target);
            }
            
            @Override
            public void attackPlayerWithFightOption(Player target)
            {
                AttackTimerPlugin.this.attackPlayerWithFightOption(target);
            }
            
            @Override
            public void clickUnderTarget(Player target)
            {
                AttackTimerPlugin.this.clickUnderTarget(target);
            }
            
            @Override
            public int getPlayerHealth()
            {
                return SkillAPI.getBoostedLevel(Skill.HITPOINTS);
            }
            
            @Override
            public int getPlayerMagicLevel()
            {
                return SkillAPI.getBoostedLevel(Skill.MAGIC);
            }
            
            @Override
            public int getPlayerRangeLevel()
            {
                return SkillAPI.getBoostedLevel(Skill.RANGED);
            }
            
            @Override
            public int getPlayerStrengthLevel()
            {
                return SkillAPI.getBoostedLevel(Skill.STRENGTH);
            }
            
            @Override
            public int getPlayerPrayerPoints()
            {
                return SkillAPI.getBoostedLevel(Skill.PRAYER);
            }
            
            @Override
            public boolean hasBrews()
            {
                return InventoryAPI.count("Saradomin brew(4)", "Saradomin brew(3)", "Saradomin brew(2)", "Saradomin brew(1)") > 0;
            }
            
            @Override
            public boolean eatAngler()
            {
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                for (ItemEx item : inventoryItems)
                {
                    if (item != null && item.getName() != null && item.getName().toLowerCase().contains("angler"))
                    {
                        String[] actions = item.getActions();
                        for (String action : actions)
                        {
                            if (action != null && action.equalsIgnoreCase("Eat"))
                            {
                                InventoryAPI.interact(item, "Eat");
                                // Set flag to indicate angler was eaten - this will trigger +3 ticks to timer
                                anglerEatenThisTick = true;
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            
            @Override
            public boolean sipSaradominBrew()
            {
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                for (ItemEx item : inventoryItems)
                {
                    if (item != null && item.getName() != null)
                    {
                        String itemName = item.getName();
                        // Match "Saradomin brew" with any dose (e.g., "Saradomin brew(4)", "Saradomin brew(3)", etc.)
                        if (itemName.toLowerCase().startsWith("saradomin brew"))
                        {
                            String[] actions = item.getActions();
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase("Drink"))
                                {
                                    InventoryAPI.interact(item, "Drink");
                                    if (config.debug())
                                    {
                                        Logger.norm("[Both Unfrozen] Drank Saradomin brew: " + itemName);
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            
            @Override
            public boolean drinkSanfewSerum()
            {
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                for (ItemEx item : inventoryItems)
                {
                    if (item != null && item.getName() != null)
                    {
                        String itemName = item.getName();
                        // Match "Sanfew serum" with any dose (e.g., "Sanfew serum(4)", "Sanfew serum(3)", etc.)
                        if (itemName.toLowerCase().startsWith("sanfew serum"))
                        {
                            String[] actions = item.getActions();
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase("Drink"))
                                {
                                    InventoryAPI.interact(item, "Drink");
                                    if (config.debug())
                                    {
                                        Logger.norm("[Both Unfrozen] Drank Sanfew serum: " + itemName);
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            
            @Override
            public boolean drinkSuperCombat()
            {
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                for (ItemEx item : inventoryItems)
                {
                    if (item != null && item.getName() != null)
                    {
                        String itemName = item.getName();
                        // Match "Super combat" with any dose (e.g., "Super combat potion(4)", "Super combat potion(3)", etc.)
                        if (itemName.toLowerCase().startsWith("super combat"))
                        {
                            String[] actions = item.getActions();
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase("Drink"))
                                {
                                    InventoryAPI.interact(item, "Drink");
                                    if (config.debug())
                                    {
                                        Logger.norm("[Combat Automation] Drank Super combat potion: " + itemName);
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            
            @Override
            public boolean drinkBastion()
            {
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                for (ItemEx item : inventoryItems)
                {
                    if (item != null && item.getName() != null)
                    {
                        String itemName = item.getName();
                        // Match "Bastion" with any dose (e.g., "Bastion potion(4)", "Bastion potion(3)", etc.)
                        if (itemName.toLowerCase().startsWith("bastion"))
                        {
                            String[] actions = item.getActions();
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase("Drink"))
                                {
                                    InventoryAPI.interact(item, "Drink");
                                    if (config.debug())
                                    {
                                        Logger.norm("[Combat Automation] Drank Bastion potion: " + itemName);
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
            
            @Override
            public boolean isUnderTarget(Player target)
            {
                WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                WorldPoint targetPos = Static.invoke(target::getWorldLocation);
                // Must be on the exact same tile
                return playerPos.getX() == targetPos.getX() && playerPos.getY() == targetPos.getY();
            }
            
            @Override
            public boolean isTargetDead(Player target)
            {
                if (target == null)
                {
                    return true; // Consider null as dead/missing
                }
                
                return Static.invoke(() -> {
                    // Check if player is dead using isDead() method
                    boolean dead = target.isDead();
                    
                    // Also check health ratio as fallback (0 means dead, -1 means health hidden/unknown)
                    int healthRatio = target.getHealthRatio();
                    if (healthRatio == 0)
                    {
                        dead = true;
                    }
                    
                    if (config.debug() && dead)
                    {
                        Logger.norm("[AttackTimer] Target is dead: " + target.getName() + " (healthRatio: " + healthRatio + ")");
                    }
                    
                    return dead;
                });
            }
            
            @Override
            public void walkAwayFromTarget(Player target, int maxTiles)
            {
                WorldPoint playerPos = Static.invoke(localPlayer::getWorldLocation);
                WorldPoint targetPos = Static.invoke(target::getWorldLocation);
                
                // Calculate direction away from target
                int dx = playerPos.getX() - targetPos.getX();
                int dy = playerPos.getY() - targetPos.getY();
                
                // Generate random distance (1 to maxTiles)
                int distance = AttackTimerPlugin.this.random.nextInt(maxTiles) + 1;
                
                // If directly on target (dx=0, dy=0), pick a completely random cardinal direction
                if (dx == 0 && dy == 0)
                {
                    // Pick random cardinal direction (N, S, E, W)
                    int direction = AttackTimerPlugin.this.random.nextInt(4);
                    int dirX = 0;
                    int dirY = 0;
                    switch (direction)
                    {
                        case 0: dirY = 1; break;  // North
                        case 1: dirY = -1; break; // South
                        case 2: dirX = 1; break;  // East
                        case 3: dirX = -1; break; // West
                    }
                    int targetX = playerPos.getX() + (dirX * distance);
                    int targetY = playerPos.getY() + (dirY * distance);
                    WorldPoint walkTile = new WorldPoint(targetX, targetY, playerPos.getPlane());
                    MovementAPI.walkToWorldPoint(walkTile);
                    return;
                }
                
                // Calculate the primary direction away from target (normalized)
                int primaryDirX = dx > 0 ? 1 : (dx < 0 ? -1 : 0);
                int primaryDirY = dy > 0 ? 1 : (dy < 0 ? -1 : 0);
                
                // Add randomness: 70% chance to use primary direction, 30% chance to use perpendicular direction
                // This prevents always moving in the same direction
                int dirX = primaryDirX;
                int dirY = primaryDirY;
                
                if (AttackTimerPlugin.this.random.nextInt(100) < 30) // 30% chance to vary direction
                {
                    // Pick a perpendicular direction (rotate 90 degrees)
                    if (primaryDirX != 0 && primaryDirY != 0)
                    {
                        // Diagonal: pick one of the two perpendicular cardinal directions
                        if (AttackTimerPlugin.this.random.nextBoolean())
                        {
                            dirX = primaryDirX;
                            dirY = 0; // Keep horizontal, remove vertical
                        }
                        else
                        {
                            dirX = 0; // Remove horizontal, keep vertical
                            dirY = primaryDirY;
                        }
                    }
                    else if (primaryDirX != 0)
                    {
                        // Moving horizontally - try vertical direction instead
                        dirX = 0;
                        dirY = AttackTimerPlugin.this.random.nextBoolean() ? 1 : -1;
                    }
                    else if (primaryDirY != 0)
                    {
                        // Moving vertically - try horizontal direction instead
                        dirX = AttackTimerPlugin.this.random.nextBoolean() ? 1 : -1;
                        dirY = 0;
                    }
                }
                
                // Add small random variation to distance (not always max distance)
                // This prevents always walking exactly maxTiles away
                int actualDistance = distance;
                if (AttackTimerPlugin.this.random.nextInt(100) < 50) // 50% chance to reduce distance slightly
                {
                    actualDistance = Math.max(1, distance - AttackTimerPlugin.this.random.nextInt(2)); // Reduce by 0-1 tiles
                }
                
                // Calculate target tile
                int targetX = playerPos.getX() + (dirX * actualDistance);
                int targetY = playerPos.getY() + (dirY * actualDistance);
                
                WorldPoint walkTile = new WorldPoint(targetX, targetY, playerPos.getPlane());
                MovementAPI.walkToWorldPoint(walkTile);
            }
            
            @Override
            public boolean equipItemByName(String itemName)
            {
                if (itemName == null || itemName.trim().isEmpty())
                {
                    return false;
                }
                
                List<ItemEx> inventoryItems = InventoryAPI.getItems();
                
                // Find matching item in inventory (supports wildcards)
                for (ItemEx item : inventoryItems)
                {
                    if (item == null)
                    {
                        continue;
                    }
                    
                    String actualItemName = item.getName();
                    if (actualItemName == null || !matchesGearPattern(actualItemName, itemName))
                    {
                        continue;
                    }
                    
                    // Check if already equipped
                    boolean alreadyEquipped = EquipmentAPI.isEquipped(i -> {
                        if (i == null || i.getName() == null) return false;
                        return matchesGearPattern(i.getName(), itemName);
                    });
                    
                    if (!alreadyEquipped)
                    {
                        // Try to equip using "Wear", "Equip", or "Wield" action
                        String[] actions = item.getActions();
                        
                        for (String actionName : new String[]{"Wear", "Equip", "Wield"})
                        {
                            for (String action : actions)
                            {
                                if (action != null && action.equalsIgnoreCase(actionName))
                                {
                                    InventoryAPI.interact(item, actionName);
                                    if (config.debug())
                                    {
                                        Logger.norm("[Fakie] Equipped: " + actualItemName + " (matched pattern: " + itemName + ")");
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        // Already equipped
                        if (config.debug())
                        {
                            Logger.norm("[Fakie] Already equipped: " + actualItemName);
                        }
                        return true; // Consider it a success if already equipped
                    }
                }
                
                if (config.debug())
                {
                    Logger.norm("[Fakie] Item not found in inventory: " + itemName);
                }
                return false;
            }
            
            @Override
            public boolean castBloodBlitz(Player target) { return false; }
            
            @Override
            public boolean castBloodBarrage(Player target) { return false; }
            
            @Override
            public int getEatCooldownTicks() { return 0; }
            
            @Override
            public int getTargetHPPercentage(Player target) { return 100; }
            
            @Override
            public void setMindAction(String action) { }
        };
        
        // Create context
        CombatStateContext ctx = new CombatStateContext(
            config,
            localPlayer,
            opponent,
            playerTimerTicks,
            opponentTimerTicks,
            weFrozen,
            targetFrozen,
            playerFreezeTimerTicks,
            opponentFreezeTimerTicks,
            pidStatus,
            mutableWaitingCastAnim,
            mutableWaitingCastXP,
            mutableWaitingCrossbow,
            mutableWaitingCrossbowTicks,
            mutableLastEquipTick,
            helpers
        );
        
        // Select and call appropriate handler based on state
        CombatStateHandler handler = null;
        
        if (targetFrozen && !weFrozen)
        {
            // Target frozen, we unfrozen - use PID-based handler
            if (pidStatus == CombatStateContext.PidStatus.ON_PID)
            {
                handler = targetFrozenWeUnfrozenOnPidHandler;
            }
            else if (pidStatus == CombatStateContext.PidStatus.OFF_PID)
            {
                handler = targetFrozenWeUnfrozenOffPidHandler;
            }
            else
            {
                // PID unknown - treat as ON_PID for now
                handler = targetFrozenWeUnfrozenOnPidHandler;
            }
        }
        else if (weFrozen && !targetFrozen)
        {
            // We frozen, target unfrozen - use PID-based handler
            if (pidStatus == CombatStateContext.PidStatus.ON_PID)
            {
                handler = weFrozenTargetUnfrozenOnPidHandler;
            }
            else if (pidStatus == CombatStateContext.PidStatus.OFF_PID)
            {
                handler = weFrozenTargetUnfrozenOffPidHandler;
            }
            else
            {
                // PID unknown - treat as ON_PID for now
                handler = weFrozenTargetUnfrozenOnPidHandler;
            }
        }
        else if (weFrozen && targetFrozen)
        {
            // Both frozen
            handler = bothFrozenHandler;
        }
        else
        {
            // Both unfrozen
            handler = bothUnfrozenHandler;
        }
        
        // Call handler
        if (handler != null)
        {
            handler.handle(ctx);
            
            // Update mutable values back to plugin fields
            waitingForCastAnimation = mutableWaitingCastAnim.value;
            waitingForCastXP = mutableWaitingCastXP.value;
            waitingForCrossbowAnimation = mutableWaitingCrossbow.value;
            waitingForCrossbowTicks = mutableWaitingCrossbowTicks.value;
            lastEquipTick = mutableLastEquipTick.value;
        }
    }
    
    /**
     * Cast blood spell on the target
     * If boosted magic level is >= 94, cast blood barrage
     * If boosted magic level is >= 82 and < 94, cast blood blitz
     * If boosted magic level is < 82, returns false (should fallback to range)
     * @return true if spell was cast, false if magic level too low or cannot cast
     */
    private boolean castBloodSpell(Player target)
    {
        // Check boosted magic level
        int boostedMagic = SkillAPI.getBoostedLevel(Skill.MAGIC);
        
        // If magic level is < 82, cannot cast blood spells - fallback to range
        if (boostedMagic < 82)
        {
            if (config.debug())
            {
                Logger.norm("[Combat Automation] Cannot cast blood spell - magic level too low (boosted magic: " + boostedMagic + " < 82), should fallback to range");
            }
            return false;
        }
        
        // If magic level is >= 94, cast Blood Barrage
        if (boostedMagic >= 94)
        {
            if (!Ancient.BLOOD_BARRAGE.canCast())
            {
                if (config.debug())
                {
                    Logger.norm("[Combat Automation] Cannot cast blood barrage - missing runes or wrong spellbook (boosted magic: " + boostedMagic + ")");
                }
                return false;
            }
            
            // Get spell widget and cast on target
            int spellWidgetId = Ancient.BLOOD_BARRAGE.getWidget();
            
            // Cast spell on target player
            Static.invoke(() -> {
                WidgetAPI.onPlayer(spellWidgetId, -1, -1, target.getId(), false);
            });
            
            // Set waiting flags
            waitingForCastAnimation = true;
            waitingForCastAnimationTicks = 0; // Reset tick counter
            waitingForCastXP = true;
            waitingForCastXPTicks = 0; // Reset tick counter
            
            if (config.debug())
            {
                Logger.norm("[Combat Automation] Casting blood barrage on target (boosted magic: " + boostedMagic + " >= 94)");
            }
            return true;
        }
        
        // Magic level is >= 82 and < 94 (82-93) - cast Blood Blitz
        if (!Ancient.BLOOD_BLITZ.canCast())
        {
            if (config.debug())
            {
                Logger.norm("[Combat Automation] Cannot cast blood blitz - missing runes or wrong spellbook (boosted magic: " + boostedMagic + ")");
            }
            return false;
        }
        
        // Get spell widget and cast on target
        int spellWidgetId = Ancient.BLOOD_BLITZ.getWidget();
        
        // Cast spell on target player
        Static.invoke(() -> {
            WidgetAPI.onPlayer(spellWidgetId, -1, -1, target.getId(), false);
        });
        
        // Set waiting flags
        waitingForCastAnimation = true;
        waitingForCastAnimationTicks = 0; // Reset tick counter
        waitingForCastXP = true;
        waitingForCastXPTicks = 0; // Reset tick counter
        
        if (config.debug())
        {
            Logger.norm("[Combat Automation] Casting blood blitz on target (boosted magic: " + boostedMagic + " >= 82 and < 94)");
        }
        return true;
    }
    
    /**
     * Cast ice barrage on the target
     * If boosted magic level is less than 94, cast ice blitz instead
     */
    private void castIceBarrage(Player target)
    {
        // Check boosted magic level
        int boostedMagic = SkillAPI.getBoostedLevel(Skill.MAGIC);
        
        // If magic level is less than 94, try to cast Ice Blitz instead
        if (boostedMagic < 94)
        {
            if (Ancient.ICE_BLITZ.canCast())
            {
                // Get spell widget and cast on target
                int spellWidgetId = Ancient.ICE_BLITZ.getWidget();
                
                // Cast spell on target player
                Static.invoke(() -> {
                    WidgetAPI.onPlayer(spellWidgetId, -1, -1, target.getId(), false);
                });
                
                // Set waiting flags
                waitingForCastAnimation = true;
                waitingForCastAnimationTicks = 0; // Reset tick counter
                waitingForCastXP = true;
                waitingForCastXPTicks = 0; // Reset tick counter
                
                if (config.debug())
                {
                    Logger.norm("[Combat Automation] Casting ice blitz on target (boosted magic: " + boostedMagic + " < 94)");
                }
                return;
            }
            else
            {
                if (config.debug())
                {
                    Logger.norm("[Combat Automation] Cannot cast ice blitz - missing runes or wrong spellbook (boosted magic: " + boostedMagic + ")");
                }
                return;
            }
        }
        
        // Magic level is 94 or higher - cast Ice Barrage
        if (!Ancient.ICE_BARRAGE.canCast())
        {
            if (config.debug())
            {
                Logger.norm("[Combat Automation] Cannot cast ice barrage - missing runes or wrong spellbook");
            }
            return;
        }
        
        // Get spell widget and cast on target
        int spellWidgetId = Ancient.ICE_BARRAGE.getWidget();
        
        // Cast spell on target player
        Static.invoke(() -> {
            WidgetAPI.onPlayer(spellWidgetId, -1, -1, target.getId(), false);
        });
        
        // Set waiting flags
        waitingForCastAnimation = true;
        waitingForCastAnimationTicks = 0; // Reset tick counter
        waitingForCastXP = true;
        waitingForCastXPTicks = 0; // Reset tick counter
        
        if (config.debug())
        {
            Logger.norm("[Combat Automation] Casting ice barrage on target (boosted magic: " + boostedMagic + ")");
        }
    }
    
    /**
     * Handle gear test: equip tank gear directly from inventory (no unequipping needed)
     */
    private void handleGearTest()
    {
        if (config.debug())
        {
            Logger.norm("[Gear Test] Starting gear test - equipping tank gear from inventory");
            String tankGearConfig = config.tankGear();
            Logger.norm("[Gear Test] Tank gear config: " + (tankGearConfig != null && !tankGearConfig.isEmpty() ? tankGearConfig : "EMPTY"));
        }
        
        // Just equip tank gear directly from inventory
        // If items aren't in inventory, they're simply ignored
        equipGearFromConfig(config.tankGear());
        
        if (config.debug())
        {
            Logger.norm("[Gear Test] Finished gear test attempt");
        }
    }
    
    /**
     * Equip tank gear and activate Augury prayer
     */
    private void equipTankGearAndPrayer()
    {
        // Equip tank gear from config
        equipGearFromConfig(config.tankGear());
        
        // Activate Augury prayer
        if (!PrayerAPI.AUGURY.isActive())
        {
            PrayerAPI.AUGURY.turnOn();
            if (config.debug())
            {
                Logger.norm("[Tank] Activated Augury prayer");
            }
        }
    }
    
    /**
     * Attack player using direct packet (bypasses player options menu)
     * Uses option 1 which is typically the primary action (Fight/Attack)
     */
    private void attackPlayerWithFightOption(Player target)
    {
        if (target == null)
        {
            Logger.norm("[Attack] ERROR: Target is null!");
            return;
        }
        
        String targetName = Static.invoke(target::getName);
        int targetId = target.getId();
        if (config.combatAutomationLogging())
        {
            Logger.norm("[Attack] Attacking target: " + targetName + " (ID: " + targetId + ")");
        }
        
        // Use direct packet - option 1 is typically the primary action (Fight/Attack)
        // This bypasses the player options menu entirely
        TClient client = Static.getClient();
        Static.invoke(() ->
        {
            // ClickManager.click(PacketInteractionType.PLAYER_INTERACT); // Not available in current API
            // Use option 1 (primary action - usually Fight/Attack)
            client.getPacketWriter().playerActionPacket(1, targetId, false);
            if (config.combatAutomationLogging())
            {
                Logger.norm("[Attack] Sent playerActionPacket(option=1, playerIndex=" + targetId + ", ctrl=false)");
            }
        });
    }
    
    /**
     * Handle ranged attack: equip ranged gear and attack target on same tick
     */
    private void handleRangeAttack(Player localPlayer)
    {
        if (config.combatAutomationLogging())
        {
            Logger.norm("[Range Attack] handleRangeAttack CALLED");
        }
        // Find target - prioritize cached target name first, then try to find the player object
        Player target = null;
        String targetNameToUse = null;
        WorldPoint playerLoc = localPlayer.getWorldLocation();
        int regionId = ((playerLoc.getX() >> 6) << 8) | (playerLoc.getY() >> 6);
        boolean inArenaCheck = (regionId == 13363 || regionId == 13362);
        
        if (cachedTargetRSN != null && !cachedTargetRSN.isEmpty())
        {
            // Use cached target name - try to find the player object
            targetNameToUse = cachedTargetRSN;
            
            // First try cached player object
            if (cachedTarget != null)
            {
                try
                {
                    String name = Static.invoke(cachedTarget::getName);
                    if (name != null && name.equals(cachedTargetRSN))
                    {
                        target = cachedTarget;
                    }
                }
                catch (Exception e)
                {
                    // Cached player object is invalid, will search below
                }
            }
            
            // If cached object is invalid, find player by name
            if (target == null)
            {
                List<PlayerEx> players = GameManager.playerList();
                for (PlayerEx pEx : players)
                {
                    if (pEx == null) continue;
                    Player p = pEx.getPlayer();
                    if (p != null && p != localPlayer)
                    {
                        String name = Static.invoke(p::getName);
                        if (name != null && name.equals(cachedTargetRSN))
                        {
                            target = p;
                            cachedTarget = p; // Update cache
                            break;
                        }
                    }
                }
            }
        }
        
        // Fallback: check current interacting target
        if (target == null)
        {
            Actor ourTarget = Static.invoke(localPlayer::getInteracting);
            if (ourTarget instanceof Player)
            {
                target = (Player) ourTarget;
            }
        }
        
        // Final fallback: find nearest player
        if (target == null)
        {
            target = findNearestPlayer(localPlayer);
        }
        
        if (target == null)
        {
            if (config.debug())
            {
                if (config.combatAutomationLogging())
                {
                    Logger.norm("[Range Attack] No target found - cannot execute range attack");
                }
            }
            return;
        }
        
        // Equip ranged gear (loadout 2) and attack target on same tick
        // Do equip first, then attack immediately after
        equipGearFromConfig(config.rangedGear());
        
        // Set flag to wait for crossbow/bolt animation BEFORE attacking (so we don't miss the animation)
        waitingForCrossbowAnimation = true;
        waitingForCrossbowTicks = 0; // Reset tick counter
        
        // Attack target immediately on same tick (after equipping)
        // Find "Fight" option in player menu (handles fight arena)
        if (config.combatAutomationLogging())
        {
            Logger.norm("[Range Attack] START - About to attack target");
            String targetName = Static.invoke(target::getName);
            Logger.norm("[Range Attack] Target name: " + targetName + ", Target ID: " + target.getId());
        }
        String targetName = Static.invoke(target::getName);
        
        attackPlayerWithFightOption(target);
        
        if (config.combatAutomationLogging())
        {
            Logger.norm("[Range Attack] END - Attack function completed");
        }
    }
    
    /**
     * Unequip gear from config string (supports wildcards)
     */
    private void unequipGearFromConfig(String gearConfig)
    {
        if (gearConfig == null || gearConfig.trim().isEmpty())
        {
            return;
        }
        
        // Parse gear config (handles both comma and newline separated)
        String[] gearItems = parseGearConfig(gearConfig);
        List<ItemEx> equippedItems = EquipmentAPI.getAll();
        
        if (config.debug())
        {
            Logger.norm("[Gear Test] Unequipping gear. Equipped items: " + equippedItems.size());
        }
        
        for (String gearPatternRaw : gearItems)
        {
            final String gearPattern = gearPatternRaw.trim();
            if (gearPattern.isEmpty())
            {
                continue;
            }
            
            // Find matching equipped item
            for (ItemEx equippedItem : equippedItems)
            {
                String itemName = equippedItem.getName();
                if (matchesGearPattern(itemName, gearPattern))
                {
                    // Unequip the item
                    EquipmentAPI.unEquip(equippedItem);
                    if (config.debug())
                    {
                        Logger.norm("[Gear Test] Unequipped: " + itemName + " (matched pattern: " + gearPattern + ")");
                    }
                    break; // Only unequip first match per pattern
                }
            }
        }
    }
    
    /**
     * Equip gear from config string (supports wildcards)
     * Handles both comma-separated and newline-separated items
     */
    private void equipGearFromConfig(String gearConfig)
    {
        equipGearFromConfig(gearConfig, null);
    }
    
    private void equipGearFromConfig(String gearConfig, PrayerAPI prayer)
    {
        if (gearConfig == null || gearConfig.trim().isEmpty())
        {
            if (config.debug())
            {
                Logger.norm("[Combat Automation] No gear config set");
            }
            return;
        }
        
        // Determine which prayer to use based on gear config if prayer not specified
        PrayerAPI prayerToUse = prayer;
        if (prayerToUse == null)
        {
            // Auto-detect prayer based on which config this is
            String tankGear = config.tankGear();
            String meleeGear = config.meleeGear();
            String rangedGear = config.rangedGear();
            String magicGear = config.magicGear();
            String tankMageGear = config.tankMageGear();
            
            // Compare gearConfig to each config to determine type
            if (gearConfig.equals(tankGear) || gearConfig.equals(tankMageGear))
            {
                prayerToUse = PrayerAPI.AUGURY;
            }
            else if (gearConfig.equals(meleeGear))
            {
                prayerToUse = PrayerAPI.PIETY;
            }
            else if (gearConfig.equals(rangedGear))
            {
                prayerToUse = PrayerAPI.RIGOUR;
            }
            else if (gearConfig.equals(magicGear))
            {
                // Regular magic gear doesn't need a prayer, but if user wants one, could use Augury
                // For now, no prayer for regular magic gear (only tank mage gets Augury)
                prayerToUse = null;
            }
        }
        
        // Parse gear config (handles both comma and newline separated)
        String[] gearItems = parseGearConfig(gearConfig);
        List<ItemEx> inventoryItems = InventoryAPI.getItems();
        
        if (config.debug())
        {
            Logger.norm("[Combat Automation] Trying to equip gear from config. Patterns: " + gearItems.length + ", Inventory items: " + inventoryItems.size() + 
                       (prayerToUse != null ? ", Prayer: " + prayerToUse.name() : ""));
        }
        
        for (String gearPatternRaw : gearItems)
        {
            final String gearPattern = gearPatternRaw.trim();
            if (gearPattern.isEmpty())
            {
                continue;
            }
            
            // Find matching item in inventory
            for (ItemEx item : inventoryItems)
            {
                if (item == null)
                {
                    continue;
                }
                
                String itemName = item.getName();
                if (itemName == null || !matchesGearPattern(itemName, gearPattern))
                {
                    continue;
                }
                
                // Check if already equipped
                boolean alreadyEquipped = EquipmentAPI.isEquipped(i -> {
                    if (i == null || i.getName() == null) return false;
                    return matchesGearPattern(i.getName(), gearPattern);
                });
                
                if (!alreadyEquipped)
                {
                    // Try to equip using "Wear", "Equip", or "Wield" action
                    // Use the action name - InventoryAPI will handle the index lookup
                    boolean equipped = false;
                    String[] actions = item.getActions();
                    
                    for (String actionName : new String[]{"Wear", "Equip", "Wield"})
                    {
                        for (String action : actions)
                        {
                            if (action != null && action.equalsIgnoreCase(actionName))
                            {
                                InventoryAPI.interact(item, actionName);
                                equipped = true;
                                if (config.debug())
                                {
                                    Logger.norm("[Gear Test] Equipping: " + itemName + " (matched pattern: " + gearPattern + ", using action: " + actionName + ")");
                                }
                                break;
                            }
                        }
                        if (equipped) break;
                    }
                    
                    if (!equipped && config.debug())
                    {
                        Logger.norm("[Gear Test] Failed to equip: " + itemName + " - no Wear/Equip/Wield action found (actions: " + java.util.Arrays.toString(actions) + ")");
                    }
                }
                else if (config.debug())
                {
                    Logger.norm("[Gear Test] Already equipped: " + itemName);
                }
                break; // Only equip first match per pattern
            }
        }
        
        // Activate prayer after equipping gear (same tick)
        if (prayerToUse != null)
        {
            if (!prayerToUse.isActive())
            {
                prayerToUse.turnOn();
                if (config.debug())
                {
                    Logger.norm("[Combat Automation] Activated prayer: " + prayerToUse.name());
                }
            }
            else if (config.debug())
            {
                Logger.norm("[Combat Automation] Prayer already active: " + prayerToUse.name());
            }
        }
    }
    
    /**
     * Parse gear config string - handles both comma-separated and newline-separated items
     */
    private String[] parseGearConfig(String gearConfig)
    {
        if (gearConfig == null || gearConfig.trim().isEmpty())
        {
            return new String[0];
        }
        
        // First try splitting by newline
        String[] byNewline = gearConfig.split("[\r\n]+");
        if (byNewline.length > 1)
        {
            // Has newlines - return newline-separated items
            return byNewline;
        }
        
        // No newlines - split by comma
        return gearConfig.split(",");
    }
    
    /**
     * Equip an item from inventory by name (supports wildcards)
     * @param itemName Item name or pattern (e.g., "Karil's leathertop*")
     * @return true if item was equipped, false otherwise
     */
    private boolean equipItemByName(String itemName)
    {
        if (itemName == null || itemName.trim().isEmpty())
        {
            return false;
        }
        
        List<ItemEx> inventoryItems = InventoryAPI.getItems();
        
        // Find matching item in inventory (supports wildcards)
        for (ItemEx item : inventoryItems)
        {
            if (item == null)
            {
                continue;
            }
            
            String actualItemName = item.getName();
            if (actualItemName == null || !matchesGearPattern(actualItemName, itemName))
            {
                continue;
            }
            
            // Check if already equipped
            boolean alreadyEquipped = EquipmentAPI.isEquipped(i -> {
                if (i == null || i.getName() == null) return false;
                return matchesGearPattern(i.getName(), itemName);
            });
            
            if (!alreadyEquipped)
            {
                // Try to equip using "Wear", "Equip", or "Wield" action
                String[] actions = item.getActions();
                
                for (String actionName : new String[]{"Wear", "Equip", "Wield"})
                {
                    for (String action : actions)
                    {
                        if (action != null && action.equalsIgnoreCase(actionName))
                        {
                            InventoryAPI.interact(item, actionName);
                            if (config.debug())
                            {
                                Logger.norm("[Equip Item] Equipped: " + actualItemName + " (matched pattern: " + itemName + ")");
                            }
                            return true;
                        }
                    }
                }
            }
            else
            {
                // Already equipped
                if (config.debug())
                {
                    Logger.norm("[Equip Item] Already equipped: " + actualItemName);
                }
                return true; // Consider it a success if already equipped
            }
        }
        
        if (config.debug())
        {
            Logger.norm("[Equip Item] Item not found in inventory: " + itemName);
        }
        return false;
    }
    
    /**
     * Click under the target (walk to their tile)
     */
    private void clickUnderTarget(Player target)
    {
        WorldPoint targetLocation = Static.invoke(target::getWorldLocation);
        if (targetLocation == null)
        {
            return;
        }
        
        // Click/walk to the tile under the target
        MovementAPI.walkToWorldPoint(targetLocation.getX(), targetLocation.getY());
        
        if (config.debug())
        {
            Logger.norm("[Combat Automation] Clicking under frozen target at " + targetLocation);
        }
    }

    /**
     * Check if an item name matches a gear pattern (supports wildcards)
     * Examples:
     *   - "Karil's leathertop*" matches "Karil's leathertop" and "Karil's leathertop100"
     *   - "*defender*" matches "avernic defender" and "dragon defender"
     *   - "Exact name" matches only "Exact name"
     * 
     * @param itemName The actual item name to check
     * @param pattern The pattern from config (may contain * wildcards)
     * @return true if the item name matches the pattern
     */
    public static boolean matchesGearPattern(String itemName, String pattern)
    {
        if (itemName == null || pattern == null || itemName.isEmpty() || pattern.isEmpty())
        {
            return false;
        }
        
        // Convert pattern to regex (escape special chars, replace * with .*)
        String regex = pattern
            .replace("\\", "\\\\")  // Escape backslashes first
            .replace(".", "\\.")   // Escape dots
            .replace("^", "\\^")    // Escape caret
            .replace("$", "\\$")    // Escape dollar
            .replace("[", "\\[")    // Escape brackets
            .replace("]", "\\]")
            .replace("(", "\\(")
            .replace(")", "\\)")
            .replace("{", "\\{")
            .replace("}", "\\}")
            .replace("+", "\\+")
            .replace("?", "\\?")
            .replace("|", "\\|")
            .replace("*", ".*");   // Replace * with .* for wildcard
        
        return itemName.matches("(?i)" + regex); // Case-insensitive match
    }
    
    /**
     * Parse a gear config string and check if an item name matches any pattern
     * 
     * @param gearConfig The config string (comma-separated patterns, e.g., "Karil's leathertop*,*defender*")
     * @param itemName The item name to check
     * @return true if the item matches any pattern in the config
     */
    public static boolean itemMatchesGearConfig(String gearConfig, String itemName)
    {
        if (gearConfig == null || gearConfig.trim().isEmpty() || itemName == null || itemName.isEmpty())
        {
            return false;
        }
        
        // Split by comma and trim each pattern
        String[] patterns = gearConfig.split(",");
        for (String pattern : patterns)
        {
            pattern = pattern.trim();
            if (pattern.isEmpty())
            {
                continue;
            }
            
            if (matchesGearPattern(itemName, pattern))
            {
                return true;
            }
        }
        
        return false;
    }
    
    // Track if we've already tried to accept this trade to prevent spam
    private boolean attemptedAcceptThisTrade = false;
    private boolean lastTradeOpenState = false;
    
    /**
     * Recursively search for a child widget with specific text
     * @param widget The widget to search in
     * @param searchText The text to search for (case-insensitive)
     * @return The widget if found, null otherwise
     */
    private Widget findChildWidgetRecursive(Widget widget, String searchText)
    {
        if (widget == null) return null;
        
        String widgetText = widget.getText();
        if (widgetText != null && widgetText.toLowerCase().contains(searchText.toLowerCase()))
        {
            Logger.norm("[Auto Accept Duel] Found widget with text '" + searchText + "' - ID: " + widget.getId() + 
                     ", Text: " + widgetText + ", Visible: " + WidgetAPI.isVisible(widget));
            return widget;
        }
        
        // Check children recursively
        if (widget.getChildren() != null)
        {
            for (Widget child : widget.getChildren())
            {
                if (child != null && !child.isHidden())
                {
                    Widget found = findChildWidgetRecursive(child, searchText);
                    if (found != null) return found;
                }
            }
        }
        
        return null;
    }


    /**
     * Auto-accept duel requests in PvP arena
     * Detects incoming trades (challenges) using TradeAPI and automatically accepts them
     */
    private void autoAcceptDuelRequest()
    {
        // Only accept if we detected a challenge message (pendingDuelConfirmation must be true)
        // This prevents accepting random trade windows from other players
        if (duelChallengeHandler == null || !duelChallengeHandler.isPendingDuelConfirmation())
        {
            return;
        }
        
        // Use TradeAPI to detect if a trade window is open (incoming trade = challenge in PvP arena)
        boolean tradeOpen = TradeAPI.isOpen();
        boolean isMainScreen = TradeAPI.isOnMainScreen();
        boolean isConfirmedScreen = TradeAPI.isOnConfirmationScreen();
        
        // Reset flags when trade window closes
        if (!tradeOpen && lastTradeOpenState)
        {
            attemptedAcceptThisTrade = false;
            // Reset challenge flags when trade window closes
            if (duelChallengeHandler != null)
            {
                duelChallengeHandler.resetChallengeFlags();
            }
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Trade window closed - resetting all flags");
            }
        }
        
        // If we've already clicked accept for this trade window, don't click again
        if (duelChallengeHandler != null && duelChallengeHandler.hasClickedAccept())
        {
            return;
        }
        
        if (config.debug())
        {
            Logger.norm("[Auto Accept Duel] Trade check - Open: " + tradeOpen + ", MainScreen: " + isMainScreen + 
                     ", ConfirmScreen: " + isConfirmedScreen + ", Attempted: " + attemptedAcceptThisTrade);
        }
        
        if (!tradeOpen)
        {
            lastTradeOpenState = false;
            return;
        }
        
        lastTradeOpenState = true;
        
        // Find the accept button widget
        Widget acceptWidget = null;
        
        // Check main screen accept button first
        if (isMainScreen)
        {
            acceptWidget = WidgetAPI.get(InterfaceID.Trademain.ACCEPT);
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Main screen - Accept widget: " + 
                         (acceptWidget != null ? "exists, visible: " + WidgetAPI.isVisible(acceptWidget) : "null"));
            }
        }
        // Check confirmation screen accept button
        else if (isConfirmedScreen)
        {
            acceptWidget = WidgetAPI.get(InterfaceID.Tradeconfirm.TRADE2ACCEPT);
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Confirm screen - Accept widget: " + 
                         (acceptWidget != null ? "exists, visible: " + WidgetAPI.isVisible(acceptWidget) : "null"));
            }
        }
        
        // If standard trade accept button not found, search for accept/confirm buttons in widgets
        if (acceptWidget == null || !WidgetAPI.isVisible(acceptWidget))
        {
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Standard accept button not found, searching all widgets...");
            }
            
            Client client = Static.getClient();
            if (client != null)
            {
                acceptWidget = findAcceptOrConfirmButton(client);
            }
        }
        
        // Check if accept button exists and is visible
        if (acceptWidget == null || !WidgetAPI.isVisible(acceptWidget))
        {
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Accept button not found or not visible");
            }
            return;
        }
        
        // Check if we've already attempted (to avoid spam)
        if (attemptedAcceptThisTrade)
        {
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Already attempted to accept this trade, skipping");
            }
            return;
        }
        
        // Check if already accepted (by checking status)
        if (TradeAPI.isAcceptedByPlayer())
        {
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] Already accepted by player, skipping");
            }
            attemptedAcceptThisTrade = true;
            return;
        }
        
        // Auto-accept the trade/challenge by clicking the accept widget
        // Get expected sender RSN for logging
        String expectedRSN = duelChallengeHandler != null ? duelChallengeHandler.getExpectedSenderRSN() : "unknown";
        
        Logger.norm("[Auto Accept Duel] ✓ Found accept button - clicking to accept challenge from: '" + expectedRSN + "' (Widget ID: " + acceptWidget.getId() + ")");
        
        // Mark that we've clicked accept - prevents double clicks
        attemptedAcceptThisTrade = true;
        if (duelChallengeHandler != null)
        {
            duelChallengeHandler.setHasClickedAccept(true);
        }
        
        // Click the accept button ONCE
        WidgetAPI.interact(acceptWidget, 1);
        
        Logger.norm("[Auto Accept Duel] ✓ Clicked accept button ONCE - challenge from: '" + expectedRSN + "' should be accepted!");
    }
    
    /**
     * Find accept or confirm button in PvP Arena challenge interface
     * Uses WidgetQuery to efficiently search for buttons with "Accept" or "Confirm" text
     * NOTE: Do NOT search for "Challenge" - that would send challenges, not accept them!
     */
    private Widget findAcceptOrConfirmButton(Client client)
    {
        return Static.invoke(() -> {
            // Use WidgetQuery to search for visible widgets containing "Accept" or "Confirm" text only
            // DO NOT search for "Challenge" - that button SENDS challenges, not accepts them!
            List<Widget> matchingWidgets = WidgetAPI.search()
                    .isVisible()
                    .isSelfVisible()
                    .withTextContains("Accept", "Confirm")
                    .collect();
            
            if (config.debug() && !matchingWidgets.isEmpty())
            {
                Logger.norm("[Auto Accept Duel] Found " + matchingWidgets.size() + " widgets with Accept/Confirm text");
            }
            
            // Find the first widget with actions (clickable button)
            for (Widget widget : matchingWidgets)
            {
                if (widget == null)
                {
                    continue;
                }
                
                String text = widget.getText();
                String[] actions = widget.getActions();
                
                // Must have actions to be clickable
                if (actions != null && actions.length > 0)
                {
                    if (config.debug())
                    {
                        Logger.norm("[Auto Accept Duel] Found clickable button - ID: " + widget.getId() + 
                                 ", Text: " + text + ", Actions: " + java.util.Arrays.toString(actions));
                    }
                    return widget;
                }
                else if (config.debug())
                {
                    Logger.norm("[Auto Accept Duel] Found widget but no actions - ID: " + widget.getId() + ", Text: " + text);
                }
            }
            
            if (config.debug())
            {
                Logger.norm("[Auto Accept Duel] No clickable Accept/Confirm button found");
            }
            
            return null;
        });
    }

    private void safeUnregister(Object listener)
    {
        try
        {
            if (listener == null) return;
            Object rawBus = Static.getRuneLite().getEventBus().getEventBus();
            try
            {
                ReflectUtil.getMethod(rawBus, "unregister", new Class[]{Object.class}, new Object[]{listener});
            }
            catch (Exception e1)
            {
                try
                {
                    ReflectUtil.getMethod(rawBus, "unregister", new Class[]{listener.getClass()}, new Object[]{listener});
                }
                catch (Exception e2)
                {
                    // Swallow to avoid noisy logs on shutdown
                }
            }
        }
        catch (Exception ignored)
        {
        }
    }

}

