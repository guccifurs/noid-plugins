/*    */ package com.tonic.plugins.attacktimer;
/*    */ 
/*    */ import com.google.gson.annotations.SerializedName;
/*    */ 
/*    */ public class ChatMessage {
/*    */   @SerializedName("timestamp")
/*    */   private String timestamp;
/*    */   @SerializedName("role")
/*    */   private String role;
/*    */   @SerializedName("content")
/*    */   private String content;
/*    */   
/* 11 */   public void setTimestamp(String timestamp) { this.timestamp = timestamp; } public void setRole(String role) { this.role = role; } public void setContent(String content) { this.content = content; }
/*    */ 
/*    */   
/*    */   public String getTimestamp() {
/* 15 */     return this.timestamp;
/*    */   }
/*    */   public String getRole() {
/* 18 */     return this.role;
/*    */   }
/*    */   public String getContent() {
/* 21 */     return this.content;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ChatMessage() {}
/*    */ 
/*    */   
/*    */   public ChatMessage(String timestamp, String role, String content) {
/* 30 */     this.timestamp = timestamp;
/* 31 */     this.role = role;
/* 32 */     this.content = content;
/*    */   }
/*    */ }


/* Location:              /home/guccifur/Bureaublad/AttackTimerPlugin.jar!/com/tonic/plugins/attacktimer/ChatMessage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */