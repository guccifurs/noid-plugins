package com.tonic.plugins.attacktimer;

public interface CombatStateHandler {
  boolean handle(CombatStateContext paramCombatStateContext);
}


/* Location:              /home/guccifur/Bureaublad/AttackTimerPlugin.jar!/com/tonic/plugins/attacktimer/CombatStateHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */