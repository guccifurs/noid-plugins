/*     */ package com.tonic.plugins.attacktimer;
/*     */ 
/*     */ import com.tonic.Logger;
/*     */ import com.tonic.api.game.CombatAPI;
/*     */ import com.tonic.api.widgets.InventoryAPI;
/*     */ import com.tonic.api.widgets.PrayerAPI;
/*     */ import com.tonic.data.AttackStyle;
/*     */ import com.tonic.data.wrappers.ItemEx;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BothFrozenHandler
/*     */   implements CombatStateHandler
/*     */ {
/*  17 */   private final Random random = new Random();
/*     */   
/*     */   private boolean needToBrewAfterLowHPAngler = false;
/*     */   
/*  21 */   private int ticksSinceLowHPAngler = 0;
/*     */ 
/*     */   
/*  24 */   private int brewCountThisCycle = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handle(CombatStateContext ctx) {
/*  29 */     if (!ctx.weFrozen || !ctx.targetFrozen)
/*     */     {
/*  31 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  35 */     ctx.helpers.setMindAction("Both Frozen");
/*     */ 
/*     */     
/*  38 */     int distance = AttackMethods.getDistance(ctx, ctx.opponent);
/*     */ 
/*     */     
/*  41 */     if (distance == 8 || distance == 9)
/*     */     {
/*  43 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  47 */     int attackTimerTicks = (ctx.playerTimerTicks < 0) ? 0 : ctx.playerTimerTicks;
/*  48 */     int opponentTimerTicks = (ctx.opponentTimerTicks < 0) ? 0 : ctx.opponentTimerTicks;
/*     */ 
/*     */     
/*  51 */     boolean shouldSwitchToRapid = ((ctx.playerFreezeTimerTicks >= 0 && ctx.playerFreezeTimerTicks < 3) || (ctx.opponentFreezeTimerTicks >= 0 && ctx.opponentFreezeTimerTicks < 3));
/*     */ 
/*     */ 
/*     */     
/*  55 */     if (shouldSwitchToRapid) {
/*     */ 
/*     */       
/*  58 */       AttackStyle currentStyle = CombatAPI.getAttackStyle();
/*  59 */       if (currentStyle == AttackStyle.THIRD) {
/*     */         
/*  61 */         CombatAPI.setAttackStyle(AttackStyle.SECOND);
/*  62 */         if (ctx.config.logHandlerActions())
/*     */         {
/*  64 */           Logger.norm("[Both Frozen] Freeze timer < 3 ticks (player: " + ctx.playerFreezeTimerTicks + ", opponent: " + ctx.opponentFreezeTimerTicks + ") - switching crossbow back to rapid");
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  70 */     if (attackTimerTicks == 2 || attackTimerTicks == 3) {
/*     */       
/*  72 */       int fakieChance = ctx.config.fakieChance();
/*  73 */       if (fakieChance > 0 && fakieChance <= 100) {
/*     */         
/*  75 */         int roll = this.random.nextInt(100);
/*  76 */         if (roll < fakieChance) {
/*     */ 
/*     */           
/*  79 */           String itemToEquip = this.random.nextBoolean() ? "Abyssal tentacle" : "Dragon crossbow";
/*  80 */           boolean equipped = ctx.helpers.equipItemByName(itemToEquip);
/*  81 */           if (ctx.config.logHandlerActions())
/*     */           {
/*  83 */             Logger.norm("[Both Frozen] Fakie triggered (" + fakieChance + "% chance, roll: " + roll + ") - Attempting to equip: " + itemToEquip + " - Result: " + (equipped ? "Success" : "Failed (not in inventory or already equipped)"));
/*     */           }
/*     */         }
/*  86 */         else if (ctx.config.logHandlerActions()) {
/*     */           
/*  88 */           Logger.norm("[Both Frozen] Fakie roll failed (" + fakieChance + "% chance, roll: " + roll + ")");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  94 */     boolean attacksSynced = (attackTimerTicks == opponentTimerTicks);
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (attackTimerTicks > 1 && attackTimerTicks <= 5)
/*     */     {
/*     */       
/* 101 */       ctx.helpers.equipGearFromConfig(ctx.config.tankGear());
/*     */     }
/*     */ 
/*     */     
/* 105 */     int health = ctx.helpers.getPlayerHealth();
/* 106 */     int magicLevel = ctx.helpers.getPlayerMagicLevel();
/* 107 */     int prayerPoints = ctx.helpers.getPlayerPrayerPoints();
/* 108 */     boolean hasBrews = ctx.helpers.hasBrews();
/* 109 */     int eatCooldownTicks = ctx.helpers.getEatCooldownTicks();
/*     */ 
/*     */     
/* 112 */     int oppTimerTicks = (ctx.opponentTimerTicks < 0) ? 0 : ctx.opponentTimerTicks;
/* 113 */     if (oppTimerTicks > 1 && health < 45 && !hasBrews) {
/*     */ 
/*     */       
/* 116 */       int anglerCount = 0;
/* 117 */       for (ItemEx item : InventoryAPI.getItems()) {
/*     */         
/* 119 */         if (item != null && item.getName() != null && item.getName().toLowerCase().contains("angler"))
/*     */         {
/* 121 */           anglerCount += item.getQuantity();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 126 */       if (anglerCount == 0)
/*     */       {
/* 128 */         if (!PrayerAPI.REDEMPTION.isActive()) {
/*     */           
/* 130 */           PrayerAPI.REDEMPTION.turnOn();
/* 131 */           if (ctx.config.aiPrayersLogging())
/*     */           {
/* 133 */             Logger.norm("[Both Frozen] Redemption activated - HP: " + health + ", No food (anglers: 0, brews: 0), Opponent timer: " + oppTimerTicks);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 140 */     if (prayerPoints < 25)
/*     */     {
/* 142 */       if (ctx.helpers.drinkSanfewSerum())
/*     */       {
/* 144 */         if (ctx.config.logHandlerActions())
/*     */         {
/* 146 */           Logger.norm("[Both Frozen] Prayer < 25 (" + prayerPoints + "), drank Sanfew serum");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (!hasBrews && health < 55)
/*     */     {
/* 155 */       if (ctx.helpers.eatAngler())
/*     */       {
/* 157 */         if (ctx.config.logHandlerActions())
/*     */         {
/* 159 */           Logger.norm("[Both Frozen] Out of brews and HP < 55 (" + health + "), eating angler");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 166 */     if (health < 35) {
/*     */ 
/*     */       
/* 169 */       if (!this.needToBrewAfterLowHPAngler)
/*     */       {
/* 171 */         if (ctx.helpers.eatAngler())
/*     */         {
/* 173 */           if (ctx.config.logHandlerActions())
/*     */           {
/* 175 */             Logger.norm("[Both Frozen] HP < 35 (" + health + "), eating anglerfish first, will brew on next tick");
/*     */           }
/* 177 */           this.needToBrewAfterLowHPAngler = true;
/* 178 */           this.ticksSinceLowHPAngler = 0;
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 185 */       else if (ctx.helpers.sipSaradominBrew())
/*     */       {
/* 187 */         if (ctx.config.logHandlerActions())
/*     */         {
/* 189 */           Logger.norm("[Both Frozen] Drank brew after low HP anglerfish (next tick)");
/*     */         }
/* 191 */         this.needToBrewAfterLowHPAngler = false;
/* 192 */         this.ticksSinceLowHPAngler = 0;
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 198 */         this.needToBrewAfterLowHPAngler = false;
/* 199 */         this.ticksSinceLowHPAngler = 0;
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 206 */     else if (this.needToBrewAfterLowHPAngler) {
/*     */       
/* 208 */       this.needToBrewAfterLowHPAngler = false;
/* 209 */       this.ticksSinceLowHPAngler = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 214 */     if (attackTimerTicks <= 1)
/*     */     {
/* 216 */       this.brewCountThisCycle = 0;
/*     */     }
/*     */ 
/*     */     
/* 220 */     boolean justBrewed = false;
/* 221 */     if (attackTimerTicks > 3)
/*     */     {
/*     */       
/* 224 */       if (health < 100)
/*     */       {
/* 226 */         if (ctx.helpers.sipSaradominBrew()) {
/*     */           
/* 228 */           justBrewed = true;
/* 229 */           this.brewCountThisCycle++;
/*     */ 
/*     */           
/* 232 */           if (ctx.config.logHandlerActions())
/*     */           {
/* 234 */             Logger.norm("[Both Frozen] HP below 100 (" + health + "), drank Saradomin brew (brew count: " + this.brewCountThisCycle + ")");
/*     */ 
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 240 */         else if (ctx.config.logHandlerActions()) {
/*     */           
/* 242 */           Logger.norm("[Both Frozen] HP below 100 (" + health + ") but no Saradomin brew found");
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     boolean shouldSanfew = (health >= 60 && magicLevel < 94 && !justBrewed && (health >= 100 || this.brewCountThisCycle >= 2));
/*     */ 
/*     */     
/* 255 */     if (shouldSanfew) {
/*     */       
/* 257 */       if (ctx.helpers.drinkSanfewSerum())
/*     */       {
/* 259 */         if (ctx.config.logHandlerActions()) {
/*     */           
/* 261 */           String reason = (health >= 100) ? "HP >= 100" : "brewed twice";
/* 262 */           Logger.norm("[Both Frozen] HP >= 60 (" + health + ") but magic < 94 (" + magicLevel + "), drank Sanfew serum immediately (brew count: " + this.brewCountThisCycle + ", reason: " + reason + ")");
/*     */         } 
/*     */         
/* 265 */         this.brewCountThisCycle = 0;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 270 */       else if (ctx.config.logHandlerActions())
/*     */       {
/* 272 */         Logger.norm("[Both Frozen] HP >= 60 (" + health + ") but magic < 94 (" + magicLevel + ") - no Sanfew serum found");
/*     */       }
/*     */     
/*     */     }
/* 276 */     else if (health >= 60 && magicLevel < 94 && !justBrewed) {
/*     */       
/* 278 */       if (ctx.config.logHandlerActions()) {
/*     */ 
/*     */ 
/*     */         
/* 282 */         String reason = justBrewed ? "just brewed, will sanfew next tick" : ((this.brewCountThisCycle < 2 && health < 100) ? ("only brewed " + this.brewCountThisCycle + " time(s), need 2 brews (or HP >= 100)") : "unknown reason");
/* 283 */         Logger.norm("[Both Frozen] HP >= 60 (" + health + ") but magic < 94 (" + magicLevel + ") - skipped sanfew (" + reason + ")");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 288 */     boolean targetCanMeleeUs = AttackMethods.canTargetMeleeUs(ctx, ctx.opponent);
/*     */     
/* 290 */     boolean isDiagonal = AttackMethods.isTargetDiagonal(ctx, ctx.opponent);
/*     */ 
/*     */     
/* 293 */     boolean canUseMelee = (targetCanMeleeUs && !isDiagonal);
/*     */     
/* 295 */     if (ctx.config.combatAutomationLogging())
/*     */     {
/* 297 */       Logger.norm("[Both Frozen] Target can melee us: " + targetCanMeleeUs + ", is diagonal: " + isDiagonal + ", can use melee: " + canUseMelee + ", playerTimer: " + attackTimerTicks + ", oppTimer: " + opponentTimerTicks + ", synced: " + attacksSynced);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     if (targetCanMeleeUs && !isDiagonal) {
/*     */ 
/*     */ 
/*     */       
/* 310 */       if (attackTimerTicks <= 1 || (attackTimerTicks == 0 && ctx.ticksAtZero >= 3)) {
/*     */ 
/*     */         
/* 313 */         int roll = this.random.nextInt(100);
/*     */         
/* 315 */         boolean canMelee = AttackMethods.canMeleeAttack(ctx, ctx.opponent);
/*     */         
/* 317 */         if (canMelee && roll < 33) {
/*     */ 
/*     */           
/* 320 */           AttackMethods.executeMeleeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         }
/* 322 */         else if (roll < 66) {
/*     */ 
/*     */           
/* 325 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 331 */           boolean useTankMage = attacksSynced;
/* 332 */           AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/*     */         } 
/* 334 */         return true;
/*     */       } 
/*     */       
/* 337 */       ctx.helpers.equipGearFromConfig(ctx.config.tankGear());
/* 338 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     if (attackTimerTicks <= 1 || (attackTimerTicks == 0 && ctx.ticksAtZero >= 3)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       if (attackTimerTicks == 1 && attacksSynced && opponentTimerTicks <= 1) {
/*     */         
/* 356 */         int syncRoll = this.random.nextInt(100);
/* 357 */         if (syncRoll < 40) {
/*     */ 
/*     */           
/* 360 */           ctx.helpers.equipGearFromConfig(ctx.config.tankGear());
/* 361 */           if (ctx.config.logHandlerActions())
/*     */           {
/* 363 */             Logger.norm("[Both Frozen] Attacks synced (playerTimer: " + attackTimerTicks + ", oppTimer: " + opponentTimerTicks + "), 40% wait roll succeeded (" + syncRoll + ") - waiting until timer 0");
/*     */           }
/* 365 */           return true;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 370 */         if (ctx.config.logHandlerActions())
/*     */         {
/* 372 */           Logger.norm("[Both Frozen] Attacks synced (playerTimer: " + attackTimerTicks + ", oppTimer: " + opponentTimerTicks + "), 40% wait roll failed (" + syncRoll + ") - proceeding with attack");
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 377 */       else if (attackTimerTicks == 0) {
/*     */       
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 384 */       if (opponentTimerTicks <= 1) {
/*     */ 
/*     */         
/* 387 */         int roll = this.random.nextInt(100);
/* 388 */         if (roll < 80) {
/*     */ 
/*     */           
/* 391 */           if (ctx.config.logHandlerActions())
/*     */           {
/* 393 */             Logger.norm("[Both Frozen] Opponent timer <= 1 (" + opponentTimerTicks + "), using ranged (80% roll: " + roll + ")");
/*     */           }
/* 395 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 400 */           ctx.helpers.equipGearFromConfig(ctx.config.magicGear());
/* 401 */           boolean useTankMage = true;
/* 402 */           boolean barrageCast = AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/* 403 */           if (barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 405 */             Logger.norm("[Both Frozen] Opponent timer <= 1 (" + opponentTimerTicks + "), using tank mage (20% roll: " + roll + ")");
/*     */           }
/* 407 */           else if (!barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 409 */             Logger.norm("[Both Frozen] Failed to cast tank mage - falling back to ranged");
/* 410 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           } 
/*     */         } 
/* 413 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       if (magicLevel >= 94 && health < 100 && eatCooldownTicks <= 1) {
/*     */ 
/*     */         
/* 424 */         if (hasBrews) {
/*     */ 
/*     */ 
/*     */           
/* 428 */           boolean useTankMage = attacksSynced;
/* 429 */           if (useTankMage) {
/*     */             
/* 431 */             ctx.helpers.equipGearFromConfig(ctx.config.tankMageGear());
/*     */           }
/*     */           else {
/*     */             
/* 435 */             ctx.helpers.equipGearFromConfig(ctx.config.magicGear());
/*     */           } 
/*     */ 
/*     */           
/* 439 */           boolean brewDrank = ctx.helpers.sipSaradominBrew();
/* 440 */           if (brewDrank && ctx.config.logHandlerActions()) {
/*     */             
/* 442 */             String gearType = useTankMage ? "tank mage gear" : "magic gear";
/* 443 */             Logger.norm("[Both Frozen] Magic >= 94 (" + magicLevel + "), HP < 100 (" + health + "), oppTimer > 1 (" + opponentTimerTicks + "), eat cooldown <= 1 (" + eatCooldownTicks + "), has brews - equipped " + gearType + ", drank brew, casting blood blitz (same tick)");
/*     */           } 
/*     */ 
/*     */           
/* 447 */           boolean blitzCast = ctx.helpers.castBloodBlitz(ctx.opponent);
/* 448 */           if (!blitzCast && ctx.config.logHandlerActions())
/*     */           {
/* 450 */             Logger.norm("[Both Frozen] Failed to cast blood blitz - falling back to range/melee");
/*     */             
/* 452 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 459 */           boolean useTankMage = attacksSynced;
/* 460 */           boolean barrageCast = AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/* 461 */           if (barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 463 */             Logger.norm("[Both Frozen] Magic >= 94 (" + magicLevel + "), HP < 100 (" + health + "), eat cooldown <= 1 (" + eatCooldownTicks + "), NO BREWS - equipped magic gear, casting blood barrage");
/*     */           }
/* 465 */           else if (!barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 467 */             Logger.norm("[Both Frozen] Failed to cast blood barrage - falling back to range/melee");
/*     */             
/* 469 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           } 
/*     */         } 
/* 472 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 477 */       if (eatCooldownTicks > 1 && magicLevel >= 80 && magicLevel < 94 && health <= 99) {
/*     */ 
/*     */         
/* 480 */         boolean useTankMage = attacksSynced;
/* 481 */         if (useTankMage) {
/*     */           
/* 483 */           ctx.helpers.equipGearFromConfig(ctx.config.tankMageGear());
/*     */         }
/*     */         else {
/*     */           
/* 487 */           ctx.helpers.equipGearFromConfig(ctx.config.magicGear());
/*     */         } 
/*     */ 
/*     */         
/* 491 */         boolean blitzCast = ctx.helpers.castBloodBlitz(ctx.opponent);
/* 492 */         if (blitzCast && ctx.config.logHandlerActions()) {
/*     */           
/* 494 */           String gearType = useTankMage ? "tank mage gear" : "magic gear";
/* 495 */           Logger.norm("[Both Frozen] Attack timer 1, eat cooldown > 1 (" + eatCooldownTicks + "), magic 80-93 (" + magicLevel + "), HP <= 99 (" + health + "), oppTimer > 1 (" + opponentTimerTicks + ") - equipped " + gearType + ", cast blood blitz");
/*     */         }
/* 497 */         else if (!blitzCast && ctx.config.logHandlerActions()) {
/*     */           
/* 499 */           Logger.norm("[Both Frozen] Failed to cast blood blitz - falling back to range/melee");
/*     */           
/* 501 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         } 
/* 503 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 508 */       if (eatCooldownTicks <= 1 && magicLevel >= 80 && magicLevel < 94 && health <= 99) {
/*     */ 
/*     */         
/* 511 */         boolean useTankMage = attacksSynced;
/* 512 */         if (useTankMage) {
/*     */           
/* 514 */           ctx.helpers.equipGearFromConfig(ctx.config.tankMageGear());
/*     */         }
/*     */         else {
/*     */           
/* 518 */           ctx.helpers.equipGearFromConfig(ctx.config.magicGear());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 523 */         boolean sanfewDrank = ctx.helpers.drinkSanfewSerum();
/* 524 */         if (sanfewDrank && ctx.config.logHandlerActions()) {
/*     */           
/* 526 */           String gearType = useTankMage ? "tank mage gear" : "magic gear";
/* 527 */           Logger.norm("[Both Frozen] Attack timer 1, eat cooldown <= 1 (" + eatCooldownTicks + "), magic 80-93 (" + magicLevel + "), HP <= 99 (" + health + "), oppTimer > 1 (" + opponentTimerTicks + ") - equipped " + gearType + ", drank sanfew, casting blood blitz (same tick)");
/*     */         } 
/*     */ 
/*     */         
/* 531 */         boolean blitzCast = ctx.helpers.castBloodBlitz(ctx.opponent);
/* 532 */         if (!blitzCast && ctx.config.logHandlerActions()) {
/*     */           
/* 534 */           Logger.norm("[Both Frozen] Failed to cast blood blitz - falling back to range/melee");
/*     */           
/* 536 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         } 
/* 538 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 542 */       if (eatCooldownTicks > 1 && magicLevel < 80) {
/*     */ 
/*     */         
/* 545 */         if (ctx.config.logHandlerActions())
/*     */         {
/* 547 */           Logger.norm("[Both Frozen] Attack timer 1, eat cooldown > 1 (" + eatCooldownTicks + "), magic < 80 (" + magicLevel + ") - fallback to bolt/whip");
/*     */         }
/*     */         
/* 550 */         int roll = this.random.nextInt(100);
/* 551 */         boolean canMelee = AttackMethods.canMeleeAttack(ctx, ctx.opponent);
/*     */         
/* 553 */         if (canMelee && roll < 50) {
/*     */ 
/*     */           
/* 556 */           AttackMethods.executeMeleeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 561 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         } 
/* 563 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 569 */       if (!hasBrews && health >= 100 && magicLevel >= 94) {
/*     */ 
/*     */         
/* 572 */         boolean useTankMage = attacksSynced;
/* 573 */         boolean barrageCast = AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/* 574 */         if (barrageCast && ctx.config.logHandlerActions()) {
/*     */           
/* 576 */           Logger.norm("[Both Frozen] Out of brews, HP >= 100 (" + health + "), Magic >= 94 (" + magicLevel + "), oppTimer > 1 (" + opponentTimerTicks + ") - equipped magic gear, casting blood barrage");
/*     */         }
/* 578 */         else if (!barrageCast && ctx.config.logHandlerActions()) {
/*     */           
/* 580 */           Logger.norm("[Both Frozen] Failed to cast blood barrage - falling back to ranged");
/* 581 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         } 
/* 583 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 589 */       if (magicLevel >= 94) {
/*     */ 
/*     */         
/* 592 */         if (!hasBrews) {
/*     */ 
/*     */           
/* 595 */           boolean useTankMage = attacksSynced;
/* 596 */           boolean barrageCast = AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/* 597 */           if (barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 599 */             Logger.norm("[Both Frozen] Magic >= 94 (" + magicLevel + "), NO BREWS, oppTimer > 1 (" + opponentTimerTicks + ") - equipped magic gear, casting blood barrage (HP: " + health + ")");
/*     */           }
/* 601 */           else if (!barrageCast && ctx.config.logHandlerActions()) {
/*     */             
/* 603 */             Logger.norm("[Both Frozen] Failed to cast blood barrage - falling back to ranged");
/* 604 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           } 
/* 606 */           return true;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 611 */         if (health > 99) {
/*     */ 
/*     */           
/* 614 */           int roll = this.random.nextInt(100);
/* 615 */           if (roll < 50)
/*     */           {
/*     */             
/* 618 */             boolean useTankMage = attacksSynced;
/* 619 */             AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 624 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 630 */           boolean useTankMage = attacksSynced;
/* 631 */           AttackMethods.executeMagicAttack(ctx, ctx.opponent, "[Both Frozen]", true, useTankMage, true, false);
/*     */         } 
/* 633 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 639 */       if (magicLevel >= 80 && magicLevel < 94 && health > 99) {
/*     */ 
/*     */         
/* 642 */         int roll = this.random.nextInt(100);
/* 643 */         if (roll < 50) {
/*     */ 
/*     */           
/* 646 */           boolean useTankMage = attacksSynced;
/* 647 */           if (useTankMage) {
/*     */             
/* 649 */             ctx.helpers.equipGearFromConfig(ctx.config.tankMageGear());
/*     */           }
/*     */           else {
/*     */             
/* 653 */             ctx.helpers.equipGearFromConfig(ctx.config.magicGear());
/*     */           } 
/* 655 */           boolean blitzCast = ctx.helpers.castBloodBlitz(ctx.opponent);
/* 656 */           if (!blitzCast && ctx.config.logHandlerActions())
/*     */           {
/* 658 */             Logger.norm("[Both Frozen] Failed to cast blood blitz - falling back to ranged");
/* 659 */             AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 665 */           AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/*     */         } 
/* 667 */         return true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 672 */       if (ctx.config.logHandlerActions())
/*     */       {
/* 674 */         Logger.norm("[Both Frozen] Magic < 80 (" + magicLevel + "), oppTimer > 1 (" + opponentTimerTicks + ") - using ranged attack");
/*     */       }
/* 676 */       AttackMethods.executeRangeAttack(ctx, ctx.opponent, "[Both Frozen]");
/* 677 */       return true;
/*     */     } 
/*     */     
/* 680 */     ctx.helpers.equipGearFromConfig(ctx.config.tankGear());
/* 681 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/guccifur/Bureaublad/AttackTimerPlugin.jar!/com/tonic/plugins/attacktimer/BothFrozenHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */